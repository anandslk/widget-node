import express from "express";
import { jdiBomController } from "./jdiBom.controller";
import { bomCommonController } from "./bomCommon/bomCommon.controller";

const router = express.Router();

router
  .route("/")
  .get((req, res, next) => jdiBomController.fetchJdiBoms(req, res).catch(next))
  .patch((req, res, next) =>
    bomCommonController.updateBomStatus(req, res).catch(next)
  )
  .post((req, res, next) => jdiBomController.createJDI(req, res).catch(next))
  .delete((req, res, next) => jdiBomController.deleteAll(req, res).catch(next));

router
  .route("/:id")
  .get((req, res, next) => jdiBomController.getJDI(req, res).catch(next))
  .patch((req, res, next) => jdiBomController.updateJDI(req, res).catch(next))
  .delete((req, res, next) => jdiBomController.deleteJDI(req, res).catch(next));

export { router as jdiBomRouter };
