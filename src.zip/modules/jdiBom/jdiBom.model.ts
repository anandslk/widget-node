import { CONTAINER, PARTITIONKEY } from "@/appconfig/config";
import dayjs from "dayjs";
import { BaseCosmosModel } from "@/src/utils/baseModel";

export class JdiBomModel extends BaseCosmosModel {
  constructor() {
    super(CONTAINER.JDI_BOM, PARTITIONKEY.JDI_BOM);
  }

  async queryData(options: QueryOptions = {}) {
    this.ensureContainer();

    const {
      userEmail,
      status: sV,
      timestampFrom,
      timestampTo,
      search,
      sortField = "timestamp",
      sortOrder = "DESC",
      pageSize: PS = 10,
      pageNumber: PN = 1,
    } = options;

    const status = sV !== "All" ? sV : undefined;

    const parsedPS = Number(PS);
    const parsedPN = Number(PN);

    const pageSize = Number.isNaN(parsedPS) ? 10 : parsedPS;
    const pageNumber = Number.isNaN(parsedPN) ? 1 : parsedPN;

    const filters: string[] = [];
    const parameters: any[] = [];

    if (userEmail) {
      filters.push("c.userEmail = @userEmail");
      parameters.push({ name: "@userEmail", value: userEmail });
    }

    if (status && status !== "All") {
      filters.push("c.status = @status");
      parameters.push({ name: "@status", value: status });
    }

    if (timestampFrom) {
      filters.push("c.timestamp >= @timestampFrom");
      parameters.push({ name: "@timestampFrom", value: timestampFrom });
    }

    if (timestampTo) {
      filters.push("c.timestamp <= @timestampTo");
      parameters.push({ name: "@timestampTo", value: timestampTo });
    }

    if (search) {
      filters.push(`
    (
      CONTAINS(LOWER(c.id), @search) OR
      EXISTS(
        SELECT VALUE item
        FROM item IN c.processedItems
        WHERE CONTAINS(LOWER(item["Collaborative Space"]), @search)
      )
    )
  `);

      parameters.push({ name: "@search", value: search.toLowerCase() });
    }

    const whereClause =
      filters.length > 0 ? `WHERE ${filters.join(" AND ")}` : "";

    // Count query
    const countQuery = `SELECT VALUE COUNT(1) FROM c ${whereClause}`;
    const countResult = await this.container.items
      .query({ query: countQuery, parameters })
      .fetchAll();

    const total = countResult.resources[0] || 0;

    // Data query with pagination
    const offset = (pageNumber - 1) * pageSize;
    const dataQuery = `
        SELECT * FROM c
        ${whereClause}
        ORDER BY c.${sortField} ${sortOrder}
        OFFSET ${offset} LIMIT ${pageSize}
      `;

    const result = await this.container.items
      .query({ query: dataQuery, parameters })
      .fetchAll();

    return {
      data: result.resources,
      total,
    };
  }

  async getItemById(id: string): Promise<{
    success: boolean;
    message: string;
    data?: JdiBomItem;
  }> {
    this.ensureContainer();

    // Step 1: Query the item to find its partition key value
    const query = `SELECT * FROM c WHERE c.id = @id`;

    const { resources } = await this.container.items
      .query({
        query,
        parameters: [{ name: "@id", value: id }],
      })
      .fetchAll();

    const item = resources?.[0];

    if (!item) {
      return {
        success: false,
        message: `Item with id "${id}" not found`,
      };
    }

    return {
      success: true,
      message: "Bom details found successfully",
      data: item,
    };
  }

  async getNextId(): Promise<string> {
    const query = {
      query:
        "SELECT TOP 1 c.id FROM c WHERE STARTSWITH(c.id, 'REQ') ORDER BY c.timestamp DESC",
    };

    const { resources } = await this.container.items.query(query).fetchAll();

    if (resources.length > 0) {
      const lastId = resources[0].id;
      const lastNum = parseInt(lastId.replace("REQ", ""), 10);
      return `REQ${lastNum + 1}`;
    } else {
      return "REQ11917";
    }
  }

  async createItem(
    data: Omit<JdiBomItem, "timestamp" | "status"> & {
      status?: JdiBomItem["status"];
    }
  ): Promise<JdiBomItem> {
    this.ensureContainer();

    const newItem: JdiBomItem = {
      ...data,
      status: "In Process",
      timestamp: dayjs().format("YYYY-MM-DD"),
    };

    const { resource } = await this.container.items.create(newItem);
    return resource as JdiBomItem;
  }

  async updateItem(
    id: string,
    updates: Partial<Omit<JdiBomItem, "id" | "timestamp">>
  ): Promise<{
    success: boolean;
    message: string;
    data?: JdiBomItem;
  }> {
    this.ensureContainer();

    // Step 1: Query the item to get its partition key value
    const query = `SELECT * FROM c WHERE c.id = @id`;
    const { resources } = await this.container.items
      .query({
        query,
        parameters: [{ name: "@id", value: id }],
      })
      .fetchAll();

    const existingItem = resources?.[0];

    if (!existingItem) {
      return {
        success: false,
        message: `Item with id "${id}" not found`,
      };
    }

    const partitionKeyValue = existingItem[this.partitionKeyPath];
    if (!partitionKeyValue) {
      return {
        success: false,
        message: `Partition key "${this.partitionKeyPath}" missing in item`,
      };
    }

    // Step 2: Create updated item
    const updatedItem: JdiBomItem = {
      ...existingItem,
      ...updates,
      timestamp: dayjs().format("YYYY-MM-DD"),
    };

    // Step 3: Replace the item
    const updated = await this.container
      .item(id, partitionKeyValue)
      .replace(updatedItem);

    return {
      success: true,
      message: `Item updated successfully`,
      data: updated?.resource as JdiBomItem,
    };
  }

  async deleteItem(id: string): Promise<{ success: boolean; message: string }> {
    this.ensureContainer();

    // Step 1: Query to find the item (cross-partition query)
    const query = `SELECT * FROM c WHERE c.id = @id`;
    const { resources } = await this.container.items
      .query({
        query,
        parameters: [{ name: "@id", value: id }],
      })
      .fetchAll();

    const item = resources?.[0];

    if (!item) {
      return {
        success: false,
        message: `Item with id "${id}" not found`,
      };
    }

    // Step 2: Get the partition key value using the known field name
    const partitionKeyValue = item[this.partitionKeyPath];

    if (!partitionKeyValue) {
      return {
        success: false,
        message: `Partition key value "${this.partitionKeyPath}" missing in item`,
      };
    }

    // Step 3: Delete using id + partition key value
    await this.container.item(id, partitionKeyValue).delete();

    return {
      success: true,
      message: `Item deleted successfully`,
    };
  }

  async deleteAll(): Promise<void> {
    this.ensureContainer();

    try {
      const query = `SELECT c.id FROM c`;
      const result = await this.container.items.query({ query }).fetchAll();
      const items = result.resources;

      for (const item of items) {
        await this.container.item(item.id, item?.userEmail).delete();
      }
    } catch (error) {
      console.error("Failed to delete all items:", error);
      throw error;
    }
  }

  async getInProcessIds(): Promise<
    {
      id: string;
      userEmail: string;
    }[]
  > {
    this.ensureContainer();

    const query = {
      query: `SELECT c.id, c.userEmail FROM c WHERE c.status = @status`,
      parameters: [{ name: "@status", value: "In Process" }],
    };

    const result = await this.container.items.query(query).fetchAll();

    return result.resources;
  }
}

export const jdiBomModel = new JdiBomModel();
