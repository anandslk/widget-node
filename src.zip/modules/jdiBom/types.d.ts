declare global {
  interface QueryOptions {
    userEmail?: string;
    status?: string;
    timestampFrom?: string;
    timestampTo?: string;
    search?: string;
    sortField?: string;
    sortOrder?: "ASC" | "DESC";
    pageSize?: number;
    pageNumber?: number;
  }

  interface IProductInfo {
    Title?: string;
    Type?: string;
    "Maturity State"?: string;
    Owner?: string;
    "Collaborative Space"?: string;
    "Collaborative Space Title"?: string;
    Description?: string;
    "Dropped Revision"?: string;
    "Dropped Revision ID"?: string;
    "Latest Released Revision"?: string;
    "Latest Released Revision ID"?: string;
    EIN?: string;
    "CAD Format"?: string;
    imageURL?: string;
    relativePath?: string;
    Name?: string;
    organization?: string;
    "Latest Revision"?: string;
    MFGCA?: boolean;
  }

  interface IStatusDetail {
    requestId: string;
    status: "FAILED" | "SUCCESS";
    message: string;
    processedItem: string;
    sourceOrg: string;
    targetOrg: string;
    creationDate: string;
  }

  type IJdiBomStatus = "In Process" | "Completed" | "Failed";

  interface JdiBomItem {
    id: string;
    status: IJdiBomStatus;
    statusDetails?: IStatusDetail[];
    timestamp: string;
    sourceOrg: string;
    processedItems: IProductInfo[];
    targetOrgs: string[];
    // userId: string;
    userEmail: string;
  }

  interface IEmailReport {
    requestId: string;
    processedItems: string[];
    parts: {
      part: string;
      failedOrgs: string[];
      successfulOrgs: string[];
    }[];
  }

  interface IUserMap {
    requestId: string;
    status: string;
    message: string;
    processedItem: string;
    sourceOrg: string;
    targetOrg: string;
    creationDate: string;
  }

  interface ICreateBomEmail {
    requestId: string;
    sourceOrg: string;
    processedItems: string[];
    targetOrgs: string[];
    status: string;
    submittedAt: string;
    submittedBy: string;
  }
}

export {};
