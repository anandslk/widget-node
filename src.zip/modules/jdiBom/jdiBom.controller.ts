import fs from "fs/promises";
import handlebars from "handlebars";
import { JdiBomModel, jdiBomModel } from "@/modules/jdiBom/jdiBom.model";
import { Request, Response } from "express";
import { queryOptionsSchema, jdiBomCreateSchema } from "./jdiBom.schema";
import { BaseController } from "@/src/utils/baseController";
import { v4 as uuidv4 } from "uuid";
import { bomCommonController } from "./bomCommon/bomCommon.controller";
import { emailController } from "../mailer/mailer.controller";
import { sendZodError } from "@/src/utils/validation";

handlebars.registerHelper("eq", (a, b) => a === b);

class JdiBomController extends BaseController {
  private dao: JdiBomModel;
  private bomReportTemplate?: HandlebarsTemplateDelegate;
  private bomCreatedTemplate?: HandlebarsTemplateDelegate;

  constructor() {
    super();
    this.dao = jdiBomModel;
  }

  async init() {
    // await this.dao.initContainer();
    // await this.dao.deleteContainer();

    const data = "rats";

    const [reportHtml, createdHtml] = await Promise.all([
      fs.readFile("src/templates/jdiBom/bomReportTemplate.html", "utf8"),
      fs.readFile("src/templates/jdiBom/bomCreated.html", "utf8"),
    ]);

    this.bomReportTemplate = handlebars.compile(reportHtml);
    this.bomCreatedTemplate = handlebars.compile(createdHtml);
  }

  async updateBomStatuses() {
    try {
      const template = this.bomReportTemplate!;
      const ids = await jdiBomModel.getInProcessIds();

      const userMap = new Map<string, IUserMap[]>();

      const statusPromises = ids.map(async ({ id, userEmail }) => {
        try {
          const result = await bomCommonController.bomStatus(id);
          const statuses = result?.data;

          if (Array.isArray(statuses) && statuses.length > 0) {
            if (!userMap.has(userEmail)) userMap.set(userEmail, []);

            statuses.forEach((item) => {
              userMap.get(userEmail)!.push({
                requestId: id,
                status: item?.STATUS,
                message: item?.MESSAGE,
                processedItem: item?.PROCESSED_ITEM,
                sourceOrg: item?.SOURCE_ORG,
                targetOrg: item?.TARGET_ORG,
                creationDate: item?.CREATION_DATE,
              });
            });
          }

          const hasFailed = statuses.some((item) => item?.STATUS === "FAILED");

          const statusDetails: IStatusDetail[] = statuses?.map((item) => ({
            status: item?.STATUS,
            message: item?.MESSAGE,
            processedItem: item?.PROCESSED_ITEM,
            sourceOrg: item?.SOURCE_ORG,
            targetOrg: item?.TARGET_ORG,
            creationDate: item?.CREATION_DATE,
            requestId: item?.REQUEST_ID,
          }));

          const updatePayload: {
            status: IJdiBomStatus;
            statusDetails: IStatusDetail[];
          } = {
            status: hasFailed ? "Failed" : "Completed",
            statusDetails,
          };

          await jdiBomModel.updateItem(id, updatePayload);

          return { status: "fulfilled" as const, id };
        } catch (err) {
          console.error(`Failed to process BOM ${id}:`, err);
          return { status: "rejected" as const, id, reason: err };
        }
      });

      const results = await Promise.allSettled(statusPromises);

      results.forEach((r) => {
        if (r.status === "rejected") {
          console.error("One of the statusPromises was rejected:", r.reason);
        }
      });

      for (const [userEmail, reports] of userMap.entries()) {
        const htmlContent = template({ total: reports.length, reports });

        await emailController.sendEmail({
          to: userEmail,
          subject: "Your BOM Report(s)",
          html: htmlContent,
        });
      }

      console.log("Status update completed.");
    } catch (err) {
      console.error("Status update failed:", err);
    }
  }

  async fetchJdiBoms(req: Request, res: Response) {
    const parsed = queryOptionsSchema.safeParse(req.query);

    if (!parsed.success) return sendZodError({ res, error: parsed.error });

    const data = await this.dao.queryData(parsed?.data);

    this.sendSuccess({
      res,
      message: "BOM found successfully",
      data: data.data,
      total: data.total,
    });
  }

  async createJDI(req: Request, res: Response) {
    const parsed = jdiBomCreateSchema.safeParse(req.body);

    const id = `REQ-${uuidv4().replace(/\D/g, "").substring(0, 8)}`;
    const payload = { ...parsed?.data, id };

    if (!parsed.success) return sendZodError({ res, error: parsed.error });

    const response = await bomCommonController.bomCommon(payload);

    if (response.status !== 200) {
      this.sendError({
        res,
        status: response.status,
        message: "Failed to create BOM",
      });
      return;
    }

    const created = await this.dao.createItem(payload);

    const template = this.bomCreatedTemplate!;

    const data: ICreateBomEmail = {
      requestId: created?.id,
      sourceOrg: created?.sourceOrg,
      processedItems: created?.processedItems?.map((item) => item?.Title),
      targetOrgs: created?.targetOrgs,
      status: created?.status,
      submittedAt: created?.timestamp,
      submittedBy: created?.userEmail,
    };

    const emailHtml = template(data);

    emailController.sendEmail({
      to: created?.userEmail,
      subject: "BOM Initiated",
      html: emailHtml,
    });

    this.sendSuccess({
      res,
      status: 201,
      message: "BOM created successfully",
      data: created,
    });
  }

  async getJDI(req: Request, res: Response) {
    const { id } = req.params;

    if (!id) {
      return this.sendError({ res, status: 400, message: "ID is required" });
    }

    const result = await this.dao.getItemById(id);

    if (!result?.success) {
      return this.sendError({ res, status: 404, message: result?.message });
    }

    return this.sendSuccess({
      res,
      status: 200,
      message: result?.message,
      data: result?.data,
    });
  }

  async updateJDI(req: Request, res: Response) {
    const { id } = req.params;
    const updates = req.body;

    if (!id) {
      return this.sendError({ res, status: 400, message: "ID is required" });
    }

    const result = await this.dao.updateItem(id, updates);

    if (!result?.success) {
      return this.sendError({ res, status: 404, message: result?.message });
    }

    return this.sendSuccess({
      res,
      status: 200,
      message: result?.message,
      data: result?.data,
    });
  }

  async deleteJDI(req: Request, res: Response) {
    const { id } = req.params;

    if (!id) {
      return this.sendError({ res, status: 400, message: "ID is required" });
    }

    const deleted = await this.dao.deleteItem(id);

    if (!deleted.success) {
      return this.sendError({ res, status: 404, message: deleted.message });
    }

    return this.sendSuccess({
      res,
      status: 200,
      message: deleted.message,
      data: null,
    });
  }

  async deleteAll(_req: Request, res: Response) {
    const deleted = await this.dao.deleteAll();

    this.sendSuccess({
      res,
      status: 200,
      message: "All deleted successfully",
      data: deleted,
    });
  }

  async getJdiBomStatus(_req: Request, res: Response) {
    const ids = await this.dao.getInProcessIds();

    this.sendSuccess({
      res,
      status: 200,
      message: "IDs found successfully",
      data: ids,
    });
  }
}

export const jdiBomController = new JdiBomController();
