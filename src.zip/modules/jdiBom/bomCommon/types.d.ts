declare global {
  interface IBomStatus {
    REQUEST_ID: string;
    STATUS: "FAILED" | "SUCCESS";
    MESSAGE: string;
    PROCESSED_ITEM: string;
    SOURCE_ORG: string;
    TARGET_ORG: string;
    CREATION_DATE: string;
  }

  interface IBomStatusCheck {
    id: string;
    status: number;
    message: string;
    data: IBomStatus[] | null;
  }
}

export {};
