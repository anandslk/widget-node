import { z } from "zod";

export const bomStatusEnum = z.enum(["FAILED", "SUCCESS"], {
  errorMap: () => ({
    message: "STATUS must be either 'FAILED' or 'SUCCESS'",
  }),
});

export const bomResponseSchema = z.array(
  z.object({
    STATUS: bomStatusEnum,

    MESSAGE: z
      .string({
        invalid_type_error: "MESSAGE must be a string",
      })
      .optional(),

    PROCESSED_ITEM: z
      .string({
        invalid_type_error: "PROCESSED_ITEM must be a string",
      })
      .optional(),

    SOURCE_ORG: z
      .string({
        invalid_type_error: "SOURCE_ORG must be a string",
      })
      .optional(),

    TARGET_ORG: z
      .string({
        invalid_type_error: "TARGET_ORG must be a string",
      })
      .optional(),

    CREATION_DATE: z
      .string({
        invalid_type_error: "CREATION_DATE must be a string",
      })
      //   .datetime("CREATION_DATE must be a valid ISO datetime string")
      .optional(),

    REQUEST_ID: z
      .string({
        required_error: "REQUEST_ID is required",
        invalid_type_error: "REQUEST_ID must be a string",
      })
      .min(1, { message: "REQUEST_ID cannot be empty" }),
  })
) as z.ZodType<IBomStatus[]>;

export type BomStatus = z.infer<typeof bomStatusEnum>;
