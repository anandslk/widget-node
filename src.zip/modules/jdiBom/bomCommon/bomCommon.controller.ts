import { BaseController } from "@/src/utils/baseController";
import { env } from "@/src/utils/env";
import axios from "axios";
import { jdiBomModel } from "../jdiBom.model";
import { Request, Response } from "express";
import { bomResponseSchema } from "./bomCommon.schema";
import { sendZodError } from "@/src/utils/validation";

class BomCommonController extends BaseController {
  constructor() {
    super();
  }

  bomCommon = async (payload: Omit<JdiBomItem, "status" | "timestamp">) => {
    const requestData = {
      RequestData: [
        {
          source_org: payload.sourceOrg,
          dest_org: payload.targetOrgs,
          parent_item: payload.processedItems.map((item) => item.Title),
          request_id: payload.id,

          // targetInfo: {
          //   system: "ORACLE",
          //   businessUnit: "",
          // },

          // systemInfo: {
          //   url: env.bomCommon.JDI_BOM_SYSTEM_INFO_URL,
          //   instance: "ENOVIA",
          // },
        },
      ],
    };

    try {
      const res = await axios.post(
        env.bomCommon.JDI_BOM_BASE_URL +
          "/d-emrplm-e-bomcommon-emrpdh-v1/api/bomcommon",
        requestData,
        {
          headers: {
            client_id: env.bomCommon.JDI_BOM_CLIENT_ID,
            Client_secret: env.bomCommon.JDI_BOM_CLIENT_SECRET,
            SenderID: env.bomCommon.JDI_BOM_SENDER_ID,
            TargetID: env.bomCommon.JDI_BOM_COMMON_TARGET_ID,
            BusinessGroup: env.bomCommon.JDI_BOM_BUSINESS_GROUP,
          },
        }
      );

      return {
        status: res?.status,
        data: res?.data?.Response,
      };
    } catch (error) {
      console.error("Error creating BOM:", error?.response?.data);

      return {
        status: error?.response?.status || 400,
      };
    }
  };

  bomStatus = async (id: string): Promise<IBomStatusCheck> => {
    try {
      const res = await axios.post(
        `${env.bomCommon.JDI_BOM_BASE_URL}/d-emrplm-e-orderstatus-emrpdh-v1/api/orderstatus`,
        { p_req_id: id },
        {
          headers: {
            client_id: env.bomCommon.JDI_BOM_CLIENT_ID,
            Client_secret: env.bomCommon.JDI_BOM_CLIENT_SECRET,
            SenderID: env.bomCommon.JDI_BOM_SENDER_ID,
            TargetID: env.bomCommon.JDI_BOM_STATUS_TARGET_ID,
            BusinessGroup: env.bomCommon.JDI_BOM_BUSINESS_GROUP,
          },
        }
      );

      const response = Array.isArray(res?.data);

      if (!response) {
        return {
          id,
          status: 404,
          message: "Bom Details not found",
          data: null,
        };
      }

      return {
        id,
        status: res?.status || 200,
        message: "Bom Details found",
        data: res?.data,
      };
    } catch (error) {
      console.error("Error fetching BOM status:", error?.response?.data);

      return {
        id,
        status: error?.response?.status || 400,
        message: "Error fetching Bom Details",
        data: null,
      };
    }
  };

  async updateBomStatus(req: Request, res: Response) {
    const parsed = bomResponseSchema.safeParse(req.body);

    if (!parsed.success) return sendZodError({ res, error: parsed.error });

    // const payload = req.body as IBomStatus[];

    const payload = parsed.data;

    const id = payload?.[0]?.STATUS;

    const result = await jdiBomModel.getItemById(id);

    const hasFailed = payload?.some((item) => item?.STATUS === "FAILED");

    const statusDetails: IStatusDetail[] = payload?.map((item) => ({
      status: item?.STATUS,
      message: item?.MESSAGE,
      processedItem: item?.PROCESSED_ITEM,
      sourceOrg: item?.SOURCE_ORG,
      targetOrg: item?.TARGET_ORG,
      creationDate: item?.CREATION_DATE,
      requestId: item?.REQUEST_ID,
    }));

    const updatePayload: {
      status: IJdiBomStatus;
      statusDetails: IStatusDetail[];
    } = {
      status: hasFailed ? "Failed" : "Completed",
      statusDetails,
    };

    if (!result?.success) {
      return this.sendError({ res, status: 404, message: result?.message });
    }

    await jdiBomModel.updateItem(id, updatePayload);

    return this.sendSuccess({
      res,
      status: 200,
      message: "Bom status updated successfully",
      data: updatePayload,
    });
  }
}

export const bomCommonController = new BomCommonController();
