import { env } from "@/src/utils/env";
import { logger } from "@/src/utils/logger";

import axios from "axios";

export class EmailController {
  constructor() {}

  async sendEmail(payload: {
    to: string;
    subject: string;
    html: string;
  }): Promise<void> {
    try {
      const payloadData = {
        fromMailAddress: env.email.EMAIL_SENDER,
        toMailAddress: payload.to,
        subject: payload.subject,
        contentType: "text/html",
        encoding: "UTF-8",
        mailbody: payload.html,
      };

      const headers = {
        "Ocp-Apim-Subscription-Key": env.email.EMAIL_SUBSCRPTION_KEY,
        "Content-Type": "application/json",
      };

      const response = await axios.post(
        env.email.EMAIL_API_GATEWAY,
        payloadData,
        { headers }
      );

      logger.info(`✅ Email sent. Status:`, { mailRes: response?.data });
      logger.info(`✅ Email sent. Status: ${response?.status}`);
    } catch (error) {
      logger.error("❌ Failed to send email:", { error });
      return error;
    }
  }
}

export const emailController: EmailController = new EmailController();
