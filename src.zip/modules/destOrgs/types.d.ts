declare global {
  interface QueryOptions {
    search?: string;
    sortField?: string;
    sortOrder?: "ASC" | "DESC";
    pageSize?: number;
    pageNumber?: number;
  }

  interface IRDO_ORGS {
    Daniel: string[];
    "Micro Motion": string[];
    "Rosmount Leve": string[];
    Roxar: string[];
    Ultrasonic: string[];
    availOrgs: string[];
  }
}

export {};
