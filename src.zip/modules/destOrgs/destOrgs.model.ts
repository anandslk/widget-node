import { CONTAINER, PARTITIONKEY } from "@/appconfig/config";
import dayjs from "dayjs";
import { BaseCosmosModel } from "@/src/utils/baseModel";

export class DestOrgsModel extends BaseCosmosModel {
  constructor() {
    super(CONTAINER.DEST_ORGS, PARTITIONKEY.DEST_ORGS);
  }

  async createOrgs(options: IRDO_ORGS) {
    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    const now = dayjs().format("YYYY-MM-DD");

    const record = {
      id: "RDO_ORGS",
      ...options,
      createdAt: now,
      updatedAt: now,
    };

    const result = await this.container.items.upsert(record);

    return result.resource;
  }

  async queryData(options: QueryOptions = {}) {
    const {
      search,
      sortField = "createdAt",
      sortOrder = "DESC",
      pageSize: PS = 10,
      pageNumber: PN = 1,
    } = options;

    // const status = sV !== "All" ? sV : undefined;

    const parsedPS = Number(PS);
    const parsedPN = Number(PN);

    const pageSize = Number.isNaN(parsedPS) ? 1000 : parsedPS;
    const pageNumber = Number.isNaN(parsedPN) ? 1 : parsedPN;

    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    const filters: string[] = [];
    const parameters: any[] = [];

    if (search) {
      filters.push(`
    (
      CONTAINS(LOWER(c.id), @search)
    )
  `);

      parameters.push({ name: "@search", value: search.toLowerCase() });
    }

    const whereClause =
      filters.length > 0 ? `WHERE ${filters.join(" AND ")}` : "";

    // Count query
    const countQuery = `SELECT VALUE COUNT(1) FROM c ${whereClause}`;
    const countResult = await this.container.items
      .query({ query: countQuery, parameters })
      .fetchAll();

    const total = countResult.resources[0] || 0;

    // Data query with pagination
    const offset = (pageNumber - 1) * pageSize;
    const dataQuery = `
        SELECT * FROM c
        ${whereClause}
        ORDER BY c.${sortField} ${sortOrder}
        OFFSET ${offset} LIMIT ${pageSize}
        `;

    const result = await this.container.items
      .query({ query: dataQuery, parameters })
      .fetchAll();

    const orgData = result.resources[0] as IRDO_ORGS;

    return {
      data: {
        Daniel: orgData?.Daniel || [],
        "Micro Motion": orgData?.["Micro Motion"] || [],
        "Rosmount Level": orgData?.["Rosmount Level"] || [],
        Roxar: orgData?.Roxar || [],
        Ultrasonic: orgData?.Ultrasonic || [],
        availOrgs: orgData?.availOrgs || [],
      },
      total,
    };
  }

  async deleteAll(): Promise<{
    success: boolean;
    deletedCount: number;
    errors?: any[];
  }> {
    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    const errors: any[] = [];

    const query = "SELECT * FROM c";
    const { resources } = await this.container.items.query(query).fetchAll();

    for (const item of resources) {
      try {
        await this.container.item(item.id, item.id).delete();
        console.log(`Deleted item with id: ${item.id}`);
      } catch (error) {
        console.error(`Failed to delete document with id: ${item.id}`, error);
        errors.push({ id: item.id, error });
      }
    }

    return {
      success: errors.length === 0,
      deletedCount: resources.length - errors.length,
      ...(errors.length > 0 && { errors }),
    };
  }
}

export const destOrgsModel = new DestOrgsModel();
