import express from "express";
import { destOrgsController } from "./destOrgs.controller";

const router = express.Router();

router
  .route("/")
  .get((req, res, next) =>
    destOrgsController.fetchDestOrgs(req, res).catch(next)
  )
  .post((req, res, next) =>
    destOrgsController.createDestOrgs(req, res).catch(next)
  );

export { router as destOrgsRouter };
