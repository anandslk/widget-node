import { Request, Response } from "express";

import { BaseController } from "@/src/utils/baseController";
import { destOrgsModel, DestOrgsModel } from "./destOrgs.model";

class DestOrgsController extends BaseController {
  private dao: DestOrgsModel;

  constructor() {
    super();
    this.dao = destOrgsModel;
  }

  async init() {
    await this.dao.initContainer();
  }

  async fetchDestOrgs(req: Request, res: Response) {
    // const parsed = queryOptionsSchema.safeParse(req.query);
    const data = await this.dao.queryData(req.query);

    this.sendSuccess({
      res,
      message: "Destination Orgs found successfully",
      data: data.data,
      total: data.total,
    });
  }

  async createDestOrgs(req: Request, res: Response) {
    // const parsed = queryOptionsSchema.safeParse(req.query);
    const data = await this.dao.createOrgs(req.body);

    this.sendSuccess({
      res,
      message: "Destination Orgs found successfully",
      data: data,
    });
  }

  async deleteAll(req: Request, res: Response) {
    // const parsed = queryOptionsSchema.safeParse(req.query);
    const data = await this.dao.deleteAll();

    this.sendSuccess({
      res,
      message: "Destination Orgs deleted successfully",
      data: data,
    });
  }
}

export const destOrgsController = new DestOrgsController();
