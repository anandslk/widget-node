import express from "express";
import { usersController } from "./users.controller";

const router = express.Router();

router.get("/", (req, res, next) =>
  usersController.getUsers(req, res).catch(next)
);

router
  .route("/:email")
  .get((req, res, next) =>
    usersController.getUserByEmail(req, res).catch(next)
  );

export { router as usersRouter };
