import { Request, Response } from "express";

import { UsersModel, usersModel } from "./users.model";
import { BaseController } from "@/src/utils/baseController";

class UsersController extends BaseController {
  private dao: UsersModel;

  constructor() {
    super();

    this.dao = usersModel;
  }

  async init() {
    await this.dao.initContainer();
  }

  async getUsers(_request: Request, res: Response) {
    const data = await this.dao.queryData();

    this.sendSuccess({
      res,
      message: "Users found successfully",
      data,
    });
  }

  async getUserByEmail(request: Request, res: Response) {
    const { email } = request.params;

    if (!email) {
      res.status(400).json({
        status: 400,
        message: "Email is required",
      });
      return;
    }

    const user = await this.dao.getUserByEmail(email);

    if (!user) {
      res.status(404).json({
        status: 404,
        message: "User not found",
      });
      return;
    }

    this.sendSuccess({
      res,
      message: "User details found successfully",
      data: user,
    });
  }
}

export const usersController = new UsersController();
