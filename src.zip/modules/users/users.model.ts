import { CONTAINER, PARTITIONKEY } from "@/appconfig/config";
import { BaseCosmosModel } from "@/src/utils/baseModel";

export class UsersModel extends BaseCosmosModel {
  constructor() {
    super(CONTAINER.USERS, PARTITIONKEY.USERS);
  }

  protected ensureContainer() {
    if (!this.container)
      throw new Error(
        "Container is not initialized. Call `initContainer()` first."
      );
  }

  async queryData() {
    this.ensureContainer();

    const query = "SELECT * FROM root";
    const result = await this.container.items.query(query).fetchAll();
    return result.resources;
  }

  async getUserByEmail(email: string) {
    this.ensureContainer();

    const querySpec = {
      query: "SELECT * FROM root r WHERE r.email = @email",
      parameters: [{ name: "@email", value: email?.toLowerCase() }],
    };

    const result = await this.container.items.query(querySpec).fetchAll();
    return result.resources.length > 0 ? result.resources[0] : null;
  }
}

export const usersModel = new UsersModel();
