import { configDotenv } from "dotenv";

configDotenv();

const serverMode = process.env.SERVER_MODE_ENV ?? "dev";

let appConfig: AppConfigType;
let CONTAINER: ContainerType;
let PARTITIONKEY: PartitionType;

const partitionKeys: PartitionType = Object.freeze({
  USERS: "userId",
  JDI_BOM: "userEmail",
  DEST_ORGS: "id",
} as const);

if (serverMode === "dev") {
  appConfig = {
    // uri: "https://emr-product-datahub-stage-sap.documents.azure.com:443/",
    // authKey:
    //   "Zi4ZmMrE2AEFZIB6BMdIBaOfrSBuby2slMWWhYztAi7fbuTlaS4JGuyXkStan3sXtwPdfDBQuWwIACDbjC5NVg==",
    // databaseId: "emrproducthubstg",
    uri: "https://emr-product-datahub.documents.azure.com:443/",
    authKey:
      "G1WrlsSPG4RdOvvQTyNxa3LWbc5Lz8vrImThsJ25JJFV76CY0XjAcVxKjtUzVQZftsdsXHSP6ChUACDbVPMJ3Q==",
    databaseId: "emrproducthubdev",
  };

  CONTAINER = {
    // USERS: "usersDev",
    JDI_BOM: "plantsDeve",
    // DEST_ORGS: "destOrgsDev",

    // BOS_ATTRIBUTES: "BOS_AttributesDev",
  };

  PARTITIONKEY = {
    ...partitionKeys,
    // BOS_ATTRIBUTES: "ItemName",
  };
}

export { appConfig, CONTAINER, PARTITIONKEY, serverMode };
