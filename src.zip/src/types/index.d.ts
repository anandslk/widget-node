import type { Router, RequestHandler } from "express";

declare global {
  interface IHeaders {
    [key: string]: string;
    Cookie: string;
    SecurityContext: string;
    ENO_CSRF_TOKEN: string;
    "Content-Type": string;
  }

  interface IRouter {
    path: string;
    router: Router;
    middlewares?: RequestHandler[];
    rateLimit?: number;
  }
}

export {};
