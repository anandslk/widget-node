import { ZodError } from "zod";
import type { Response } from "express";

const DEFAULT_ERROR_MESSAGE =
  "Validation failed. Please correct the highlighted fields and try again.";

/**
 * Given a ZodError, generate a JSON response body
 * with each field’s messages joined into a single string.
 */
export function formatZodErrorResponse(error: ZodError) {
  const { fieldErrors, formErrors } = error.flatten();

  // Join each field’s array of messages into one string
  const joinedFieldErrors: Record<string, string> = Object.fromEntries(
    Object.entries(fieldErrors).map(([field, msgs]) => [field, msgs.join(" ")])
  );

  // Optionally join top-level formErrors into one string
  const joinedFormError = formErrors.length ? formErrors.join(" ") : undefined;

  return {
    ...joinedFieldErrors,
    ...(joinedFormError ? { _form: joinedFormError } : {}),
  };
}

/**
 * Shortcut: send a 400 validation error response on a ZodError.
 */
export function sendZodError(payload: {
  res: Response;
  error: ZodError;
  message?: string;
}) {
  const body = formatZodErrorResponse(payload.error);

  return payload.res.status(400).json({
    status: 400,
    message: payload.message || DEFAULT_ERROR_MESSAGE,
    data: body,
  });
}
