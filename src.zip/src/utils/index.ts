import fs from "fs";
import rateLimit from "express-rate-limit";

// import { destOrgsController } from "@/modules/destOrgs/destOrgs.controller";
import { jdiBomController } from "@/modules/jdiBom/jdiBom.controller";
// import { usersController } from "@/modules/users/users.controller";

export const initContainers = async () => {
  try {
    const controllers = [
      // usersController.init(),
      jdiBomController.init(),
      // destOrgsController.init(),
    ];

    const results = await Promise.allSettled(controllers);

    results.forEach((result, index) => {
      if (result.status !== "fulfilled") {
        // console.error(`Controller ${index + 1} failed:`, result.reason);
      }
    });
  } catch (error) {
    console.error("Error initializing controllers:", error);
  }
};

const customRateLimitHandler = (_req, res, _next, options) => {
  res.status(options.statusCode).json({
    status: options.statusCode,
    message:
      "You have exceeded the maximum number of requests. Please try again later.",
    limit: options.max,
    retryAfter: Math.ceil(options.windowMs / 1000) + " seconds",
  });
};

// Rate limiter with custom response
export const rateLimiter = (maxRequests?: number) =>
  rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: maxRequests || 20, // limit each IP requests per windowMs
    standardHeaders: true,
    legacyHeaders: false,
    handler: customRateLimitHandler,
  });

// Initialize log files if not present
export const initLogfiles = (path: string) => {
  fs.stat(path, (err) => {
    if (err?.code === "ENOENT") {
      fs.writeFile(path, "", () => {});
    }
  });
};
