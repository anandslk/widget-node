const resss = [
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.30007357Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.339504366Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.377349681Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.390942572Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.783302852Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.290622341Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.298085899Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.34256157Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.336296123Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.322511528Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.290715469Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.320020268Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  {
    Response: {
      DateTime: "2025-06-06T10:54:19.32252535Z",
      ResponseCode: 200,
      ResponseStatus: "Error",
      RequestId: "",
      ErrorFlag: null,
      ErrorCode: "EXPRESSION",
      ErrorMessage:
        '"Unable to parse empty input, while reading `inboundPayload` as Json.\n' +
        " \n" +
        "1| \n" +
        '   ^" evaluating expression: "%dw 2.0 \n' +
        'output application/json skipNullOn="everywhere" \n' +
        "\n" +
        "---\n" +
        "{    \n" +
        "      appName: Mule::p('app.name'),\n" +
        "      environment: Mule::p('env'),\n" +
        `      appVersion: if (vars.systemProperties.version != null and vars.systemProperties.version != "" )(vars.systemProperties.version)else(Mule::p('secure::app.version')) default null,\n` +
        "      domain: Mule::p('domain'),\n" +
        `      businessInterfaceName: if (vars.systemProperties.businessName != null and vars.systemProperties.businessName != "" )(vars.systemProperties.businessName)else(Mule::p('secure::businessName')) default null,\n` +
        "      businessInterfaceId: Mule::p('secure::businessId'), \n" +
        `      sourceSystem : if (vars.systemProperties.sourceSystem != null and vars.systemProperties.sourceSystem != "")(vars.systemProperties.sourceSystem)else(Mule::p('secure::errorProperties.sourceSystem')) default null,\n` +
        `  \t  targetSystem : if (vars.systemProperties.targetSystem != null and vars.systemProperties.targetSystem != "")(vars.systemProperties.targetSystem)else(Mule::p('secure::errorProperties.targetSystem')) default null,\n` +
        "      tracePoint : vars.tracePoint.tracePoint,\n" +
        "      tracePointDescription: vars.tracePointDescription.tracePointDescription,\n" +
        "\t  externalReferenceId: vars.externalReferenceId.externalReferenceId,\n" +
        "\t  correaltionId: vars.correlationId.correlationId,\n" +
        "\t  transactionId : vars.transactionId.transactionId,\n" +
        "\t  inboundPayload: vars.inboundPayload as String default null,\n" +
        `\t  timestamp : (now() >> "UTC") as String{format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"},\n` +
        '\t  cumulativeTime: (now() - vars.cumulativeTime) as String {format: "HH:mm:ss.SSS"},\n' +
        `\t  deploymentRuntime: if(server.systemProperties.'application.aws.region' != null) (server.systemProperties.'application.aws.region') else("OnPrem"),\n` +
        `\t  portfolio: if (vars.portfolio != null and vars.portfolio != "")(vars.portfolio)else(Mule::p('secure::portfolio')) default null,\n` +
        "\t businessObject: \n" +
        "\t      {\n" +
        '\t\t\t businessObjectName: if (vars.businessObject.businessObjectName != null and vars.businessObject.businessObjectName != "")(vars.businessObject.businessObjectName) else vars.businessObjectName default null,\n' +
        '    \t\t businessIdentifier1: if (vars.businessObject.businessIdentifier1 != null and vars.businessObject.businessIdentifier1 != "")(vars.businessObject.businessIdentifier1) else vars.businessIdentifier1 default null,\n' +
        '    \t\t businessIdentifier1Value: if (vars.businessObject.businessIdentifier1Value != null and vars.businessObject.businessIdentifier1Value != "")(vars.businessObject.businessIdentifier1Value) else vars.businessIdentifier1Value default null,\n' +
        '    \t\t businessIdentifier2: if (vars.businessObject.businessIdentifier2 != null and vars.businessObject.businessIdentifier2 != "")(vars.businessObject.businessIdentifier2) else vars.businessIdentifier2 default null,\n' +
        '    \t\t businessIdentifier2Value: if (vars.businessObject.businessIdentifier2Value != null and vars.businessObject.businessIdentifier2Value != "")(vars.businessObject.businessIdentifier2Value) else vars.businessIdentifier2Value default null\n' +
        "    \t\t},\n" +
        "\t  additionalBusinessData : \n" +
        "\t  \t{\n" +
        "\t  \tmethod : attributes.method default null,\n" +
        "      \trequestPath : attributes.requestPath default null,\n" +
        "      \tfileName: attributes.fileName default null,\n" +
        "      \tdirectory : attributes.directory default null\n" +
        "      } \n" +
        "\t\n" +
        '}".',
      ErrorTrace: null,
      ActionRecommended: "Check with MuleSoft Team",
    },
  },
  [
    {
      REQUEST_ID: "REQ-36509784",
      STATUS: "BOM Successfully Created.",
      PROCESSED_ITEM: "MSOL14PL0",
      SOURCE_ORG: "MVO",
      TARGET_ORG: "DE1",
      CREATION_DATE: "2025-05-30T08:19:47",
    },
  ],
  [
    {
      REQUEST_ID: "REQ-35367564",
      STATUS: "BOM Successfully Created.",
      PROCESSED_ITEM: "MSOL14PL0",
      SOURCE_ORG: "MVO",
      TARGET_ORG: "AD1",
      CREATION_DATE: "2025-05-30T08:24:54",
    },
  ],
  [
    {
      REQUEST_ID: "REQ-37745438",
      STATUS: "Source org and source BOM is not valid. ",
      PROCESSED_ITEM: "98485",
      SOURCE_ORG: "MVO",
      TARGET_ORG: "AO1",
      CREATION_DATE: "2025-06-06T10:36:28",
    },
  ],
];
