let dotenv = require("dotenv");
dotenv.config();

const { EMRPDH_OKTA_CLIENT_ID, EMRPDH_OKTA_ISSUER, EMRPDH_OKTA_DOMAIN }: any =
  process.env;

const OktaJwtVerifier = require("@okta/jwt-verifier");
const jsonwebtoken = require("jsonwebtoken");
let jwt = require("jwt-simple");
const jwksClient = require("jwks-rsa");

// Function to retrieve and cache public keys from Okta's JWKS endpoint
const client = jwksClient({
  jwksUri: `${EMRPDH_OKTA_ISSUER}/v1/keys`,
});

const audience = "api://default";
const oktaJwtVerifier = new OktaJwtVerifier({
  clientId: `${EMRPDH_OKTA_CLIENT_ID}`,
  issuer: `${EMRPDH_OKTA_ISSUER}`,
  audience: audience,
});

const getKey = async (header, callback) => {
  return await client.getSigningKey(header.kid, (err, key) => {
    if (err) {
      return callback(err);
    }
    const signingKey = key.publicKey || key.rsaPublicKey;
    if (!signingKey) {
      return callback(
        new Error("No publicKey or rsaPublicKey found in key object")
      );
    }
    callback(null, signingKey);
  });
};

// Verify access token
const verifyAccessTokenFunc = async (accessToken) => {
  return await new Promise(async (resolve, reject) => {
    await jsonwebtoken.verify(
      accessToken,
      getKey,
      { algorithms: ["RS256"] },
      (err, decoded) => {
        if (err) {
          reject(err);
        } else {
          resolve(decoded);
        }
      }
    );
  });
};

const authenticationRequired = async (req, res, next) => {
  try {
      // If it's not, perform authentication logic here
      // For demonstration purposes, let's just log a message
      const { authorization } = req.headers;
      if (!authorization) throw new Error('You must send an Authorization header');

      const [authType, token] = authorization.split(' ');
      if (authType !== 'Bearer') throw new Error('Expected a Bearer token');

      const authHeader = req.headers.authorization || '';
      const match = authHeader.match(/Bearer (.+)/);
      if (!match) {
          return res.status(401).send();
      }

      let accessToken = match[1];
      if (!accessToken) {
          return res.status(401, 'Not authorized').send();
      }

      const secret = 'EMRPRoDucTDaTa';
      let decoded = jwt.decode(token, secret, false, 'HS512');

      accessToken = decoded.data.accessToken;
      let userinfo = decoded.data.userinfo;

      req.jwt = await oktaJwtVerifier.verifyAccessToken(accessToken, audience).then(jwt => {
          return jwt.claims;
      }).catch(err => {
          return err.message;
      });

      // console.log(req.jwt, "===================req.jwt 111111")
      // console.log(accessToken, "===================accessToken");

      // req.jwt = await verifyAccessTokenFunc(accessToken).then(claims => {
      //     console.log('Access token verified:', claims);
      //     return claims;
      // }).catch(err => {
      //     console.error('Error verifying access token:', err);
      //     return err.message;
      // });

      if (req['jwt'] !== undefined || req['jwt'] !== null) {
          if (typeof req['jwt'] === 'string' || req['jwt'] instanceof String) {
              return res.status(401).json(req['jwt']);
          }
      }

      const jwtDetails: any = req['jwt'];
      if (req['jwt'] !== undefined || req['jwt'] !== null) {
          req.body.userId = jwtDetails.uid;
          req.body.userName = jwtDetails.sub;
          req.body.email = jwtDetails.sub; //for user validation
      }

      // get userinfo from frontend
      if (userinfo !== null && userinfo !== undefined) {
          req.body.userinfo = userinfo;

          // req.body.userId = userinfo.uid;
          // req.body.userName = userinfo.email;
          // req.body.email = userinfo.email;
      }

      // Proceed to the next middleware
      next();
  } catch (err) {
      return res.status(401).json(err.message);
  }
};

export { authenticationRequired };
