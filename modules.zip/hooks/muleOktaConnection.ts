import axios from "axios";

let dotenv = require("dotenv");
dotenv.config();

const {
  MULE_OKTA_DOMAIN,
  MULE_OKTA_ISSUER,
  MULE_OKTA_CLIENT_ID,
  MULE_OKTA_CLIENT_SECRET,
  MULE_OKTA_DEFAULT_SCOPE,
}: any = process.env;

let jwt = require("jwt-simple");
const OktaJwtVerifier = require("@okta/jwt-verifier");

const oktaJwtVerifier = new OktaJwtVerifier({
  clientId: `${MULE_OKTA_CLIENT_ID}`,
  issuer: `${MULE_OKTA_ISSUER}`,
});
const audience = "api://default";

const muleTokenGenerator = async () => {
  const keys = `${MULE_OKTA_CLIENT_ID}:${MULE_OKTA_CLIENT_SECRET}`;
  console.log('MULE_OKTA_CLIENT_ID', MULE_OKTA_CLIENT_ID, MULE_OKTA_CLIENT_SECRET)
  const token = Buffer.from(keys, "utf8").toString("base64");

  try {
    let formData = new URLSearchParams();
    formData.append("grant_type", "client_credentials");
    formData.append("scope", MULE_OKTA_DEFAULT_SCOPE);
    const { token_type, access_token } = await axios
      .post(`${MULE_OKTA_ISSUER}/v1/token`, formData, {
        headers: {
          authorization: `Basic ${token}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
      })
      .then(function (response) {
        return response.data;
      })
      .catch(function (error) {
        return error.userMessage;
      });

    return {
      token_type,
      access_token,
    };
  } catch (error) {
    return {
      err: error.message,
    };
  }
};

const getUserDetails = async (userId, accessToken) => {
  try {
    // Make a request to another API to get user details based on the userId
    const response = await axios.get(`${MULE_OKTA_DOMAIN}/users/${userId}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    const userDetails = response.data;
    return userDetails;
  } catch (error) {
    console.error("Error fetching user details:", error.message);
    return null;
  }
};

const verifyToken = async (accessToken) => {
  try {
    const response = await axios.post(
      `${MULE_OKTA_ISSUER}/v1/introspect`,
      `token=${accessToken}&client_id=${MULE_OKTA_CLIENT_ID}&client_secret=${MULE_OKTA_CLIENT_SECRET}`,
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      }
    );

    const introspectionResponse = response.data;

    console.log(introspectionResponse, "introspectionResponse");

    if (introspectionResponse.active) {
      // Token is active, extract user details from token claims
      return introspectionResponse.active;
    } else {
      // Token is not active, return null or handle accordingly
      return null;
    }
  } catch (error) {
    // Error occurred during token introspection, handle accordingly
    return null;
  }
};

const ackAuthenticationRequired = async (req, res, next) => {
  try {
    // If it's not, perform authentication logic here
    // For demonstration purposes, let's just log a message
    // console.log('Authentication logic executed for route:', req.path);

    const { authorization } = req.headers;
    if (!authorization)
      throw new Error("You must send an Authorization header");

    const [authType, token] = authorization.split(" ");
    if (authType !== "Bearer") throw new Error("Expected a Bearer token");

    const authHeader = req.headers.authorization || "";
    const match = authHeader.match(/Bearer (.+)/);
    if (!match) {
      return res.status(401).send();
    }

    let accessToken = match[1];
    if (!accessToken) {
      return res.status(401, "Not authorized").send();
    }

    const userDetails = await verifyToken(accessToken);
    if (userDetails) {
      // User details retrieved successfully, use them as needed
      // console.log('User ID:', userDetails.sub);
      // console.log('User Email:', userDetails.email);
      console.log(userDetails, "======mule user detail");
      // Add more user details as needed
    } else {
      // Token is not valid or user details couldn't be retrieved, handle accordingly
      return res
        .status(401)
        .send(`Token is not valid or user details couldn't be retrieved`);
    }

    // Proceed to the next middleware
    next();
  } catch (err) {
    //changed to json
    return res.status(401).json(err.message);
  }
};

export { muleTokenGenerator, ackAuthenticationRequired };
