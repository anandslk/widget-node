import { appConfig } from '../appconfig/config';
import { DBController } from './dbcontroller'

const dbController = new DBController();

const database  = dbController.init()

console.log('DB URI:', appConfig.uri);
console.log('DB Auth Key:', appConfig.authKey);
console.log('DB Database ID:', appConfig.databaseId);

 export { database }

