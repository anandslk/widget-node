import dotenv from "dotenv";

dotenv.config();

type AppConfigType = {
  uri: string;
  authKey: string;
  databaseId: string;
};

type ContainerType = {
  ATTRIBUTES?: string;
  MAPPINGS?: string;
  TEMPLATE?: string;
  PLANT?: string;
  ITEM_ACKNOWLEDGEMENT?: string;
  BOM_ACKNOWLEDGEMENT?: string;
  BOS_ACKNOWLEDGEMENT?: string;
  SOURCE_LIST?: string;
  BUSINESS_UNIT?: string;
  NEW_TEMPLATE_MAPPING?: string;
  DRAFT_CHANGES?: string;
  HISTORY_VERSION?: string;
  MAPPING_HISTORY?: string;
  MRRELATEDDETAILS?: string;
  USERS?: string;
  LIFECYCLESTATUS?: string;
  SPECIFICATION_CREATION?: string;
  OBSOLTE_PART?: string;
  MASS_DES_UPDATE?: string;
  SYSTEMSETTINGS?: string;
  MCOHISTORY?: string;
  JDI_BOM?: string;
  BOS_ATTRIBUTES?: string;
};

let appConfig: AppConfigType = {
  uri: "",
  authKey: "",
  databaseId: "",
};
let CONTAINER: ContainerType = {};
let PARTITIONKEY: ContainerType = {};

let serverMode = process.env.SERVER_MODE_ENV ?? "dev";

// appConfig = {
//   uri: process.env.EMRPDH_SERVER_DB_URI,
//   authKey: process.env.EMRPDH_SERVER_DB_AUTHKEY,
//   databaseId: process.env.EMRPDH_SERVER_DB_DATABASEID,
// };

if (serverMode === "dev") {
  appConfig = {
    uri: "https://emr-product-datahub.documents.azure.com:443/",
    authKey:
      "G1WrlsSPG4RdOvvQTyNxa3LWbc5Lz8vrImThsJ25JJFV76CY0XjAcVxKjtUzVQZftsdsXHSP6ChUACDbVPMJ3Q==",
    databaseId: "emrproducthubdev",
  };

  CONTAINER = {
    USERS: "usersDev",
    JDI_BOM: "jdiBom",
    BOS_ATTRIBUTES: "BOS_AttributesDev"
  };
  PARTITIONKEY = {
    BOS_ATTRIBUTES: "ItemName",
  };
}
console.log("Server Mode:", serverMode);
console.log("DB URI from ENV:", process.env.EMRPDH_SERVER_DB_URI);
console.log("DB Auth Key from ENV:", process.env.EMRPDH_SERVER_DB_AUTHKEY);
console.log(
  "DB Database ID from ENV:",
  process.env.EMRPDH_SERVER_DB_DATABASEID
);

if (serverMode === "qa") {
  appConfig = {
    uri: "https://emr-product-datahub.documents.azure.com:443/",
    authKey:
      "G1WrlsSPG4RdOvvQTyNxa3LWbc5Lz8vrImThsJ25JJFV76CY0XjAcVxKjtUzVQZftsdsXHSP6ChUACDbVPMJ3Q==",
    databaseId: "emrproducthubdev",
  };

  CONTAINER = {
    BOS_ATTRIBUTES: "BOS_AttributesDev"
  };
  PARTITIONKEY = {
    BOS_ATTRIBUTES: "ItemName",
  };
}


if (serverMode === "stage") {
  appConfig = {
    uri: "https://emr-product-datahub-stg.documents.azure.com:443/",
    authKey: process.env.STAGE_AUTH_KEY!,
    databaseId: "emrproducthubstg",
  };

  CONTAINER = {
    ATTRIBUTES: "mcoItemsStg",
    // MAPPINGS: "mappingsStg",
    TEMPLATE: "templatesStg",
    PLANT: "plantsStg",
    ITEM_ACKNOWLEDGEMENT: "ItemAckStg",
    BOS_ACKNOWLEDGEMENT: "bosAckStg",
    BOM_ACKNOWLEDGEMENT: "bomAckStg",
    SOURCE_LIST: "sourceStg",
    BUSINESS_UNIT: "businessUnitStg",
    NEW_TEMPLATE_MAPPING: "mvoTemplateCompatibilityStg",
    DRAFT_CHANGES: "draftChangesStg",
    HISTORY_VERSION: "historyVersionStg",
    MAPPING_HISTORY: "mappingHistoryStg",
    MRRELATEDDETAILS: "mrRelDetailsStg",
    USERS: "usersDevStg",
    LIFECYCLESTATUS: "lifeCycleStatusDevStg",
    SPECIFICATION_CREATION: "specificationCreationStg",
    OBSOLTE_PART: "obsoletePartStg",
    MASS_DES_UPDATE: "massDesUpdateStg",
    SYSTEMSETTINGS: "systemSettingsStg",
    MCOHISTORY: "mcoHistoryStg",
    BOS_ATTRIBUTES: "BOS_AttributesStg"
  };
  PARTITIONKEY = {
    ATTRIBUTES: "/mcoItems",
    // MAPPINGS: "/mappings",
    TEMPLATE: "/templates",
    PLANT: "/plants",
    ITEM_ACKNOWLEDGEMENT: "/ItemAck",
    BOS_ACKNOWLEDGEMENT: "/bosAck",
    BOM_ACKNOWLEDGEMENT: "/bomAck",
    SOURCE_LIST: "/sourceList",
    BUSINESS_UNIT: "/businessUnit",
    NEW_TEMPLATE_MAPPING: "templateMappings",
    DRAFT_CHANGES: "draftId",
    HISTORY_VERSION: "versionId",
    MAPPING_HISTORY: "historyId",
    MRRELATEDDETAILS: "MRRelDetails",
    USERS: "userId",
    LIFECYCLESTATUS: "mcoId",
    SPECIFICATION_CREATION: "specificationCreation",
    OBSOLTE_PART: "obsoletePart",
    MASS_DES_UPDATE: "id",
    SYSTEMSETTINGS: "systemId",
    MCOHISTORY: "historyId",
    BOS_ATTRIBUTES: "ItemName",
  };
}

if (serverMode === "prod") {
  appConfig = {
    uri: "https://emr-product-datahub-prod.documents.azure.com:443/",
    authKey:
      "PWma26dLkMegBJ95GCdXqVQrDxI4QfzMRjSfnel8ckRyCWwDEUQN3AbrXKPSnJ1aVlnvBhBro9XAACDbc04czg==",
    databaseId: "emrproducthubprod",
  };
  CONTAINER = {
    ATTRIBUTES: "mcoItemsProd",
    MAPPINGS: "mappingsProd",
    TEMPLATE: "templatesProd",
    PLANT: "plantsProd",
    ITEM_ACKNOWLEDGEMENT: "ItemAckProd",
    BOM_ACKNOWLEDGEMENT: "bomAckProd",
    SOURCE_LIST: "sourceProd",
  };
  PARTITIONKEY = {
    ATTRIBUTES: "/mcoItems",
    MAPPINGS: "/mappings",
    TEMPLATE: "/templates",
    PLANT: "/plants",
    ITEM_ACKNOWLEDGEMENT: "/ItemAck",
    BOM_ACKNOWLEDGEMENT: "/bomAck",
    SOURCE_LIST: "/sourceList",
  };
}

export { appConfig, CONTAINER, PARTITIONKEY, serverMode };