export const emrPDHData = {
    "activeMR": {
        "MMI-20102553": [
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MMB",
                "revision": "AB",
                "mcoId": "8.46112.27486.45349",
                "mcoName": "1225876MMB",
                "sequence": "2",
                "additionalSequence": "0",
                "status": "2",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": ""
            }
        ]
    },
    "previousSeqMR": {
        "MMI-20102553": [
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MMB",
                "revision": "AA",
                "mcoId": "8.46112.27486.36734",
                "mcoName": "1225872MMB",
                "sequence": "1",
                "additionalSequence": "0",
                "status": "1",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": "8.46112.27486.34710"
            }
        ]
    },
    "getHighestSeqCurrentPendingOrActiveMR": {
        "MMI-20102553": [
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MMB",
                "revision": "AB",
                "mcoId": "8.46112.27486.45349",
                "mcoName": "1225876MMB",
                "sequence": "2",
                "additionalSequence": "0",
                "status": "2",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": ""
            },
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MMC",
                "revision": "AB",
                "mcoId": "8.46112.27486.45408",
                "mcoName": "1225876MVO",
                "sequence": "2",
                "additionalSequence": "0",
                "status": "2",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": ""
            }
        ]
    },
    "getHighestSeqCurrentOrActiveMR": {
        "MMI-20102553": [
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MMC",
                "revision": "AB",
                "mcoId": "8.46112.27486.45349",
                "mcoName": "1225876MMB",
                "sequence": "2",
                "additionalSequence": "0",
                "status": "2",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": ""
            }
        ]
    }
}
export const enoviaData ={
    "activeMR": {
        "MMI-20102553": [
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MMB",
                "revision": "AB",
                "mcoId": "8.46112.27486.45349",
                "mcoName": "1225876MMB",
                "sequence": "2",
                "additionalSequence": "0",
                "status": "2",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": ""
            }
        ]
    },
    "previousSeqMR": {
        "MMI-20102553": [
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MMB",
                "revision": "AA",
                "mcoId": "8.46112.27486.36734",
                "mcoName": "1225872MMB",
                "sequence": "1",
                "additionalSequence": "0",
                "status": "1",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": "8.46112.27486.34710"
            }
        ]
    },
    "getHighestSeqCurrentPendingOrActiveMR": {
        "MMI-20102553": [
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MMB",
                "revision": "AB",
                "mcoId": "8.46112.27486.45349",
                "mcoName": "1225876MMB",
                "sequence": "2",
                "additionalSequence": "0",
                "status": "2",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": ""
            },
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MVO",
                "revision": "AB",
                "mcoId": "8.46112.27486.45408",
                "mcoName": "1225876MVO",
                "sequence": "2",
                "additionalSequence": "0",
                "status": "2",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": ""
            }
        ]
    },
    "getHighestSeqCurrentOrActiveMR": {
        "MMI-20102553": [
            {
                "partAndPlant": "MMI-20102553_MMB",
                "partName": "MMI-20102553",
                "plantName": "MMB",
                "revision": "AB",
                "mcoId": "8.46112.27486.45349",
                "mcoName": "1225876MMB",
                "sequence": "2",
                "additionalSequence": "0",
                "status": "2",
                "erpStatus": "Active",
                "makeOrBuy": "Buy",
                "template": "EMR BUY ITEM FLOW",
                "previousSeqMR": ""
            }
        ]
    }
}