import cron from "node-cron";
import axios from "axios";
import { config } from "dotenv";
import { JdiBom } from "@/modules/jdiBom/jdiBom.model";
import nodemailer from "nodemailer";
import fs from "fs";
import handlebars from "handlebars";
import { logger } from "../utils/logger";

config();

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

const sendEmailReport = async ({
  requestId,
  processedItems,
  parts,
}: {
  requestId: string;
  processedItems: string[];
  parts: {
    part: string;
    failedOrgs: string[];
    successfulOrgs: string[];
  }[];
}) => {
  const templateHtml = fs.readFileSync(
    "templates/bomReportTemplate.html",
    "utf8"
  );
  const template = handlebars.compile(templateHtml);

  const htmlContent = template({ requestId, processedItems, parts });

  await transporter.sendMail({
    from: `"BOM Report" <${process.env.SMTP_USER}>`,
    to: process.env.REPORT_EMAIL_TO,
    subject: `BOM Processing Report - Request ${requestId}`,
    html: htmlContent,
  });
};

cron.schedule("59 23 * * *", async () => {
  logger.info(`Running end-of-day job: ${new Date().toLocaleString()}`);

  try {
    const jdiBom = new JdiBom();
    await jdiBom.initContainer();

    const response = await axios.get(`${process.env.UPDATE_STATUS_API_URL}`);
    const externalUpdates = response.data;

    if (!Array.isArray(externalUpdates)) {
      throw new Error("API response format is invalid.");
    }

    const processedItems: string[] = [];
    const parts: {
      part: string;
      failedOrgs: string[];
      successfulOrgs: string[];
    }[] = [];

    for (const item of externalUpdates) {
      if (!item.id || !item.status) continue;

      try {
        await jdiBom.updateItem(item.id, { status: item.status });
        processedItems.push(item.id);

        parts.push({
          part: item.id,
          failedOrgs: item.failedOrgs || [],
          successfulOrgs: item.successfulOrgs || [],
        });

        console.log(`Updated item ${item.id} to status ${item.status}`);
      } catch (updateError) {
        console.error(`Failed to update item ${item.id}`, updateError);
      }
    }

    const requestId = `REQ-${Date.now()}`;
    await sendEmailReport({ requestId, processedItems, parts });

    console.log("End-of-day update job completed.");
  } catch (err) {
    console.error("End-of-day job failed:", err);
  }
});
