interface IHeaders {
  [key: string]: string;
  Cookie: string;
  SecurityContext: string;
  ENO_CSRF_TOKEN: string;
  "Content-Type": string;
}
