// 1. imports express, bodyparser and cors packages
import "./src/utils/setup.alias";
import "./src/jobs"
import express from 'express';
// import * as MailDev from 'maildev';
import bodyParser from 'body-parser';

// For application logging
const fs = require('fs');
const winston = require('winston');

const cors = require('cors');
const helmet = require('helmet');

import { initControllers, rateLimiter } from './src/utils';

// 2 imports the AppController

import { router as logRouter } from './modules/logger/log.routes'
import { router as caAPIRouter } from './modules/APIServices/caDetails/caAPI.Routes';
import { router as flowDownCA } from './modules/flowDownCAAuto/flowDownCARoutes';
import { router as revFloatAPIRouter } from './modules/APIServices/revFloat/revFloatAPI.Routes';
import { router as plantAssignment } from './modules/plantAssignment/plantAssignmentRoutes';
import { router as bosAttribute } from './modules/bosAttribute/bosAttribute.routes';
import { router as UsersRouter } from './modules/users/users.routes';
import { jdiBomRoutes } from './modules/jdiBom/jdiBom.routes';
import { errorHandler } from "./src/middlewares/errorHandler.middleware";

import { combinedLogFilePath, errorLogFilePath, logger } from "./src/utils/logger";
import { configDotenv } from "dotenv";
import { EmailController } from "./modules/mailer/mailer.controller";


configDotenv()


// Check if error.log file exists, if not, create it

fs.stat(errorLogFilePath, (err, stats) => {
    if (err) {
        if (err.code === 'ENOENT') {
            // File does not exist
            fs.writeFile(errorLogFilePath, '', (err) => {
                if (err) {
                    //console.error('Error occurred while writing to file:');
                }
            });
        }
    }
})


fs.stat(combinedLogFilePath, (err, stats) => {
    if (err) {
        if (err.code === 'ENOENT') {
            // File does not exist
            fs.writeFile(combinedLogFilePath, '', (err) => {
                if (err) {
                    //console.error('Error occurred while writing to file:');
                }
            });
        }
    }
})



if (process.env.NODE_ENV !== 'production') {
    logger.add(new winston.transports.Console({
        format: winston.format.simple(),
    }));
}

// 3. an instance of the express and adding bodyParser and cors middlewares
const instance = express();

// Increase body-parser limits to 500kb
instance.use(bodyParser.json({ limit: '500kb' }));
instance.use(bodyParser.urlencoded({ limit: '500kb', extended: true }));

//Fo CORSs
instance.use(cors());
instance.use(rateLimiter);
try {
    instance.use(helmet({
        contentSecurityPolicy: {
            directives: {
                defaultSrc: ["'none'"],
                scriptSrc: ["'self'"],
                connectSrc: ["'self'"],
                imgSrc: ["'self'"],
                styleSrc: ["'self'"]
            }
        },
        hsts: {
            maxAge: 31536000,
            includeSubDomains: true
        },
        referrerPolicy: { policy: 'no-referrer' },
        noCache: true,
        xssFilter: true,
        hidePoweredBy: true
    }));

    instance.use((req, res, next) => {
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        res.setHeader('Content-Security-Policy', "default-src 'none'; script-src 'self'; connect-src 'self'; img-src 'self'; style-src 'self';");
        res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains;');
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.setHeader('X-XSS-Protection', '1; mode=block');
        res.setHeader('Referrer-Policy', 'no-referrer');
        next();
    });

    instance.use(express.static('downloads'))

    // middleware - authentication checks for all end points
    // Apply middleware globallyy
    instance.use(async (req, res, next) => {
      const pathsToMatch = [
        "/log",
        "/ca",
        "/flowDownCA",
        "/revFloat",
        "/plantAssignment",
        "/bosAttribute",
        "/users",
        "/jdiBom",
      ];

      const isMatched = pathsToMatch.some((path) => req.path.includes(path));

      if (!isMatched) {
        res.status(403).json({status:403, error: "Access denied: path not allowed." });
        return;
      }

      next("route");
    });

    
    instance.use('/log', logRouter);
    instance.use('/ca', caAPIRouter);
    instance.use('/flowDownCA', flowDownCA);
    instance.use('/users', UsersRouter);
   // Rev Float APIs
    instance.use('/revFloat', revFloatAPIRouter);
    instance.use('/plantAssignment', plantAssignment);

    //bosAttribute
    instance.use('/bosAttribute', bosAttribute);
    instance.use('/jdiBom', jdiBomRoutes);




    // 
    // const maildev = new MailDev({
    //     smtp: 1025 // incoming SMTP port - default is 1025
    // })

    // maildev.listen(function (err) {
    //     console.log('We can now sent emails to port 1025!')
    // })

    // // Print new emails to the console as they come in
    // maildev.on('new', function (email: any) {
    //     console.log('Received new email with subject: %s', email.subject)
    // })

    instance.use(errorHandler);
} catch (error) {
    logger.error('Something went wrong:', error);
}

const portNumber = process.env.PORT || 443;

instance.listen(portNumber, async () => {
  // Example of using the logger
  logger.info(`Application started - started on port ${portNumber}`);

  
  const emailController = new EmailController();
  
  
  emailController.sendEmail( 'vijsah68@gmail.com', 'Test Subject',  '<b>Test HTML</b>');
  
  await initControllers();
});