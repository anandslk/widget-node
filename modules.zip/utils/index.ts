const CryptoJS = require("crypto-js");

import {
    NODE_APP_MULESOFT_ENRYPT_KEY_VALUE,
    NODE_APP_MULESOFT_ENRYPT_INIT_VECTOR_VALUE,
} from "./../appconfig";

export const encryptByAES = (data) => {
    let SECRET_KEY = NODE_APP_MULESOFT_ENRYPT_KEY_VALUE;
    let keyHex = CryptoJS.enc.Utf8.parse(SECRET_KEY);
    let ivHex = CryptoJS.enc.Utf8.parse(NODE_APP_MULESOFT_ENRYPT_INIT_VECTOR_VALUE);
    let encrypted = CryptoJS.AES.encrypt(JSON.stringify(data), keyHex, {
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
        iv: ivHex
    });

    return encrypted.toString();
}
export const decryptByAES = (encryptedData) => {
    let SECRET_KEY = NODE_APP_MULESOFT_ENRYPT_KEY_VALUE;
    let keyHex = CryptoJS.enc.Utf8.parse(SECRET_KEY);
    let ivHex = CryptoJS.enc.Utf8.parse('encryptionIntVec');
    let bytes = CryptoJS.AES.decrypt(encryptedData, keyHex, {
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
        iv: ivHex
    });
    let decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));

    return decryptedData;
}