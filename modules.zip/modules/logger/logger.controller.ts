import { Request, Response } from "express";
import {
  Logger as WinstonLogger,
  createLogger,
  transports,
  format,
} from "winston";
import { NODE_APP_LIFECYCLEPROCESS_LOGS } from "../../appconfig";
import rateLimit from "express-rate-limit";

const he = require("he");
const fs = require("fs-extra");
const path = require("path");
let loggerConfig;
export class Logger {
  private loggerConfig: WinstonLogger;
  constructor() {}

  // Function to check if a directory exists
  async directoryExists(directory: string): Promise<boolean> {
    try {
      await fs.promises.access(directory, fs.constants.F_OK); // Check if the folder exists
      return true;
    } catch (err) {
      return false;
    }
  }

  // Function to create a directory if it doesn't exist
  async createDirectoryIfNotExists_bk(directory: string): Promise<void> {
    if (!(await this.directoryExists(directory))) {
      await fs.promises.mkdir(directory); // Create the directory
      console.log(`Directory created: ${directory}`);
    } else {
      console.log(`Directory already exists: ${directory}`);
    }
  }
  async ensureDirectoryExists(directoryPath: any, mcoName: any) {
    // Base directory to which all paths should be relative
    const baseDirectory = directoryPath;

    // Normalize the path to remove any relative components
    const normalizedPath = path
      .normalize(`${directoryPath}/${mcoName}`)
      .replace(/\\/g, "/");

    // Construct the absolute path to ensure it is within the base directory
    const absolutePath = path
      .join(baseDirectory, path.relative(baseDirectory, normalizedPath))
      .replace(/\\/g, "/");

    // Validate that the final path is indeed within the base directory
    if (!absolutePath.startsWith(baseDirectory)) {
      return false;
    }

    try {
      // Ensure the directory exists using fs-extra
      await fs.ensureDir(absolutePath);
      return true; // Directory existed or was created successfully
    } catch (err) {
      return false; // An error occurred while creating the directory
    }
  }
  // Define a function to generate dynamic filenames
  generateFilename(directory: string) {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = (currentDate.getMonth() + 1).toString().padStart(2, "0");
    const day = currentDate.getDate().toString().padStart(2, "0");
    return `${directory}_${year}-${month}-${day}.log`; // Example: info_2024-02-27.log
  }

  async addLogs(request: Request, response: Response): Promise<void> {
    const body: any = request.body;

    const returnVal = await this.addLogsInternal(body?.loginfo, body?.mcoName);

    let encodeData = he.encode(JSON.stringify({ data: returnVal }));
    const decodedRes = he.decode(encodeData);
    response.send(JSON.parse(decodedRes));
  }
  async addLogsInternal(logData: any, mcoName: any = null) {
    try {
      if (NODE_APP_LIFECYCLEPROCESS_LOGS?.toUpperCase() !== "YES") {
        return false;
      }
      if (!mcoName || mcoName === "") {
        return {
          status: "failed",
          msg: "MCO name was empty! please verify before try!",
        };
      }
      // Ensure directory exists
      const directory = "mcoLogs";
      // const mcoName = "1234567ABC";
      await this.ensureDirectoryExists(directory, mcoName);

      // Initialize logger configuration
      this.loggerConfig = createLogger({
        transports: [
          new transports.File({
            filename: `${directory}/${mcoName}/${this.generateFilename(
              directory
            )}`, // Putting logs inside "MVO" directory
            level: "info",
            format: format.combine(
              format.timestamp({
                format: "YYYY-MM-DD hh:mm:ss A", // 2022-01-25 03:23:10.350 PM
              }),
              format.json()
            ),
          }),
        ],
      });

      this.loggerConfig.info(logData);
      return {
        status: "success",
        msg: logData,
      };
    } catch (error) {
      return {
        status: "failed",
        msg: error.message,
      };
    }
  }
  async getMCOLogInfo(request: Request, response: Response) {
    try {
      const body: any = request.body;

      if (!body?.mcoName || body?.mcoName === "") {
        const respValue: any = {
          status: "failed",
          msg: "MCO name was empty! please verify before try!",
        };
        let encodeData = he.encode(JSON.stringify({ data: respValue }));
        const decodedRes = he.decode(encodeData);
        return response.send(JSON.parse(decodedRes));
      }

      // Ensure directory exists
      const directory = "mcoLogs";
      // const logFilePath = `${directory}/${body?.mcoName}/${body?.date}`;
      await this.ensureDirectoryExists(directory, body?.mcoName);
      const filePath = path.join(
        directory,
        body?.mcoName,
        `${directory}_${body?.date}.log`
      );

      const isExists = await fs.pathExists(filePath);
      if (!isExists) {
        const respValue: any = {
          status: "failed",
          msg: "No log data available for this date or mco",
        };
        let encodeData = he.encode(JSON.stringify({ data: respValue }));
        const decodedRes = he.decode(encodeData);
        return response.send(JSON.parse(decodedRes));
      }

      const allowedDirectory = path.resolve("mcoLogs");
      const resolvedPath = path.resolve(filePath);
      if (!resolvedPath.startsWith(allowedDirectory)) {
        return response
          .status(400)
          .send({ status: "error", msg: "Invalid file path." });
      }


      // const logFilePath = path.join('info.log'); // Adjust the path to your log file
      // response.download(filePath, 'logInfo.log', (err) => {
      //     if (err) {
      //         response.status(500).send('Error downloading the file');
      //     }
      // });

      console.log(`filePath, "=====filePath"`);
      await this.ensureFile(filePath);

      await fs.promises
        .readFile(resolvedPath, "utf8")
        .then((data) => {
          //replced with .json for xss issue
          response.json(data);
        })
        .catch((err) => {
          response.status(500).send("Error reading the file");
        });
    } catch (err) {
      const respValue: any = {
        status: "failed",
        msg: err?.message,
      };
      let encodeData = he.encode(JSON.stringify({ data: respValue }));
      const decodedRes = he.decode(encodeData);
      return response.send(JSON.parse(decodedRes));
    }
  }

  async getMCOLogFilesListInfo(request: Request, response: Response) {
    try {
      const body: any = request.body;

      if (!body?.mcoName || body?.mcoName === "") {
        const respValue: any = {
          status: "failed",
          msg: "MCO name was empty! please verify before try!",
        };
        let encodeData = he.encode(JSON.stringify({ data: respValue }));
        const decodedRes = he.decode(encodeData);
        return response.send(JSON.parse(decodedRes));
      }

      // Ensure directory exists
      const directory = "mcoLogs";
      const filePath = path.join(directory, body?.mcoName);

      await this.ensureDirectory(filePath);

      const allowedDirectory = path.resolve("mcoLogs");
      const resolvedPath = path.resolve(filePath);
      if (!resolvedPath.startsWith(allowedDirectory)) {
        return response
          .status(400)
          .send({ status: "error", msg: "Invalid file path." });
      }

      const files = await fs.promises.readdir(resolvedPath);
      console.log("Files in directory:", files);

      const respValue: any = {
        status: "success",
        files: files,
      };
      let encodeData = he.encode(JSON.stringify({ data: respValue }));
      const decodedRes = he.decode(encodeData);
      return response.send(JSON.parse(decodedRes));
    } catch (err) {
      console.error("Error reading directory:", err);
      const respValue: any = {
        status: "failed",
        msg: err?.message,
      };
      let encodeData = he.encode(JSON.stringify({ data: respValue }));
      const decodedRes = he.decode(encodeData);
      return response.send(JSON.parse(decodedRes));
    }
  }
  async getAllMCOLogFilesListInfo(request: Request, response: Response) {
    try {
      // Ensure directory exists
      const directory = "mcoLogs";
      const filePath = path.join(directory);

      const isExists = await fs.pathExists(filePath);
      if (!isExists) {
        const respValue: any = {
          status: "failed",
          msg: "log folder empty",
        };
        let encodeData = he.encode(JSON.stringify({ data: respValue }));
        const decodedRes = he.decode(encodeData);
        return response.send(JSON.parse(decodedRes));
      }

      await this.ensureDirectory(filePath);

      const files = await fs.promises.readdir(filePath);
      console.log("Files in directory:", files);

      const respValue: any = {
        status: "success",
        files: files,
      };
      let encodeData = he.encode(JSON.stringify({ data: respValue }));
      const decodedRes = he.decode(encodeData);
      return response.send(JSON.parse(decodedRes));
    } catch (err) {
      console.error("Error reading directory:", err);
      const respValue: any = {
        status: "failed",
        msg: err?.message,
      };
      let encodeData = he.encode(JSON.stringify({ data: respValue }));
      const decodedRes = he.decode(encodeData);
      return response.send(JSON.parse(decodedRes));
    }
  }
  async downloadInfoLogFile(request: Request, response: Response) {
    try {
      const logFilePath = path.join("info.log"); // Adjust the path to your log file
      // res.download(logFilePath, 'info.log', (err) => {
      //     if (err) {
      //         res.status(500).send('Error downloading the file');
      //     }
      // });

      console.log(logFilePath, "=====filePath");
      await this.ensureFile(logFilePath);

      await fs.promises
        .readFile(logFilePath, "utf8")
        .then((data) => {
          response.send(data);
        })
        .catch((err) => {
          response.status(500).send("Error reading the file");
        });
    } catch (err) {
      //replaced with json
      response.status(500).json(err.message);
    }
  }
  async ensureDirectory(directoryPath: any) {
    // Base directory to which all paths should be relative
    const baseDirectory = directoryPath;

    // Normalize the path to remove any relative components
    const normalizedPath = path
      .normalize(`${directoryPath}`)
      .replace(/\\/g, "/");

    // Construct the absolute path to ensure it is within the base directory
    const absolutePath = path
      .join(baseDirectory, path.relative(baseDirectory, normalizedPath))
      .replace(/\\/g, "/");

    // Validate that the final path is indeed within the base directory
    if (!absolutePath.startsWith(baseDirectory)) {
      console.error("Invalid directory path");
      return false;
    }

    try {
      // Ensure the directory exists using fs-extra
      await fs.ensureDir(absolutePath);
      console.log(`Directory ${absolutePath} created or already exists.`);
      return true; // Directory existed or was created successfully
    } catch (err) {
      console.error("Error creating directory:", err);
      return false; // An error occurred while creating the directory
    }
  }
  async ensureFile(filePath: any) {
    // Base directory to which all paths should be relative
    const baseDirectory = filePath;

    // Normalize the path to remove any relative components
    const normalizedPath = path.normalize(filePath).replace(/\\/g, "/");

    // Construct the absolute path to ensure it is within the base directory
    const absolutePath = path
      .join(baseDirectory, path.relative(baseDirectory, normalizedPath))
      .replace(/\\/g, "/");

    // Validate that the final path is indeed within the base directory
    if (!absolutePath.startsWith(baseDirectory)) {
      console.error("Invalid file path");
      return false;
    }

    try {
      // Ensure the file exists using fs-extra
      await fs.ensureFile(absolutePath);
      console.log(`File ${absolutePath} created or already exists.`);
      return true; // File existed or was created successfully
    } catch (err) {
      console.error("Error creating file:", err);
      return false; // An error occurred while creating the file
    }
  }
}
