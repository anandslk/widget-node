const express = require('express');
const path = require('path');
const fs = require('fs-extra');
const router = express.Router();
import { Logger } from "./logger.controller";

const logController = new Logger();

router.post('/addLogInfo', (req, res, next) => logController.addLogs(req, res).catch(next));
router.post('/getMCOLogInfo', (req, res, next) => logController.getMCOLogInfo(req, res).catch(next));
router.post('/getMCOLogFilesListInfo', (req, res, next) => logController.getMCOLogFilesListInfo(req, res).catch(next));
router.get('/getAllMCOLogFilesListInfo', (req, res, next) => logController.getAllMCOLogFilesListInfo(req, res).catch(next));
router.get('/downloadInfoLogFile', (req, res, next) => logController.downloadInfoLogFile(req, res).catch(next));

export { router };
