import { Container } from "@azure/cosmos";
import { CONTAINER } from "@/appconfig/config";
import { UsersItems } from "../datatypes";
import { database } from "@/db/dbConnection";

export class Users {
  private collectionId: string;
  private container: Container;

  constructor() {
    this.collectionId = CONTAINER.USERS;
  }

  async initContainer() {
    try {
      const db = await database;

      if (!db?.id) throw new Error("The specified database is not present");

      const responseContainer = await db.containers.createIfNotExists(
        { id: this.collectionId },
        { offerThroughput: 400 }
      );

      this.container = responseContainer.container;

      return this.container;
    } catch (error) {
      console.log("Error init container", error);
    }
  }

  async queryData() {
    const query = "SELECT * FROM root";
    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    const result = await this.container.items.query(query).fetchAll();
    return result.resources;
  }

  async getUserByEmail(email: string) {
    if (!this.container)
      throw new Error("The specified collection is not present");

    const querySpec = {
      query: "SELECT * FROM root r WHERE r.email = @email",
      parameters: [
        {
          name: "@email",
          value: email?.toLowerCase(),
        },
      ],
    };

    const result = await this.container.items.query(querySpec).fetchAll();
    return result.resources.length > 0 ? result.resources[0] : null;
  }

  // async getUserbyid(id: any, partitionKey: any) { //to be removed
  //     // get the document base on id parameter
  //     console.log(partitionKey, 'partitionKey');
  //     const record: any = await container.item(id, partitionKey).read() || null
  //     return record.resource;
  // }

  async addUser(product: UsersItems) {
    const resp: any = await this.container.items.create(product);
    return resp.resource;
  }

  async updateUser(id: any, partitionKey: string, product: any) {
    // get the document base on id parameter
    const record: any = await this.container.item(id, partitionKey).read();
    if (record?.resource) {
      let updated: any;
      // set the updated values
      record.resource.name = product.name;
      record.resource.userName = product.userName;
      record.resource.email = product.email;
      record.resource.updated_at = product.updated_at;
      record.resource.is_authorized = product.is_authorized;
      record.resource.email_verified = product.email_verified;
      record.resource.userinfo = product.userinfo;

      updated = await this.container
        .item(id, partitionKey)
        .replace(record.resource);
      return updated.resource;
    } else {
      return null;
    }
  }

  async deleteUser(id: any, partitionKey: string) {
    try {
      await this.container.item(id, partitionKey).delete();
    } catch (error) {
      console.log(error);
    }
  }

  async customQueryData(params: object) {
    let query = `select * from root r where 1=1`;

    let parameters: any = [];
    Object.keys(params).forEach((key, index) => {
      query += ` and r.${key} = @value${index + 1}`;
      parameters.push({
        name: `@value${index + 1}`,
        value: params[key],
      });
    });

    const querySpec = {
      query: query,
      parameters: parameters,
    };

    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    const result: any = await this.container.items.query(querySpec).fetchAll();

    return result.resources;
  }

  async customQueryDataWithOR(params: object) {
    let query = `select * from root r where 1=1 and (r.email = @value1 or r.email = @value2)`;
    let parameters: any = [
      {
        name: `@value1`,
        value: params["email"]?.toLowerCase(),
      },
      {
        name: `@value2`,
        value: params["email"],
      },
    ];

    const querySpec = {
      query: query,
      parameters: parameters,
    };

    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    const result: any = await this.container.items.query(querySpec).fetchAll();

    return result.resources;
  }
}
