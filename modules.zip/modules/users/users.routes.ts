import { UsersController } from "./users.controller";
import { serverMode } from "@/appconfig/config";

import multer from "multer";
import express from "express";

const router = express.Router();
const usersController = new UsersController();

export const initUC = async () => {
  try {
    await usersController.init();
    console.info("Container created users" + serverMode);
  } catch (error) {
    console.error("Container creation failed users" + serverMode);
    process.exit(1);
  }
};

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, "uploads/"),
  filename: (_req, file, cb) => cb(null, file.originalname),
});

const upload = multer({ storage: storage });

router.get("/getUsers", (req, res, next) =>
  usersController.getUsers(req, res).catch(next)
);

router.get("/getUserByEmail/:email", (req, res, next) =>
  usersController.getUserByEmail(req, res).catch(next)
);

router.post("/addUser", (req, res, next) =>
  usersController.addUser(req, res).catch(next)
);

router.put("/updateUser", (req, res, next) =>
  usersController.updateUser(req, res).catch(next)
);

router.delete("/deleteUser", (req, res, next) =>
  usersController.deleteUser(req, res).catch(next)
);

router.get("/validateUser", (req, res, next) =>
  usersController.validateUser(req, res).catch(next)
);

router.post("/requestForAccessApp", (req, res, next) =>
  usersController.requestForAccessApp(req, res).catch(next)
);

router.post("/bulkAddUser", upload.single("file"), (req, res, next) =>
  usersController.bulkAddUser(req, res).catch(next)
);

router.post("/bulkExportUser", (req, res, next) =>
  usersController.bulkExportUser(req, res).catch(next)
);

export { router };
