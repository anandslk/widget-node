import { Request, Response } from "express";

import { validate as validateEmail } from "email-validator";
import { UsersItems } from "../datatypes";
import { Users } from "./users.model";
import { EmailController } from "../mailer/mailer.controller";

import XLSX from "xlsx";
import fs from "fs-extra";
import path from "path";
import moment from "moment";

const emailController = new EmailController();

export class UsersController {
  private dao: Users;

  constructor() {
    this.dao = new Users();
  }

  async init() {
    await this.dao.initContainer();
  }

  async getUsers(_request: Request, response: Response) {
    const data = await this.dao.queryData();
    response.send({ data: data });
  }

  async getUserByEmail(request: Request, response: Response) {
    try {
      const { email } = request.params;

      if (!email) {
        response.status(400).json({
          status: 400,
          message: "Email is required",
        });
        return;
      }

      const user = await this.dao.getUserByEmail(email);

      if (!user) {
        response.status(404).json({
          status: 404,
          message: "User not found",
        });
        return;
      }

      response.status(200).json({
        status: 200,
        message: "User details found successfully",
        data: user,
      });
    } catch (error) {
      console.error("Error getUserByEmail", error);

      response.status(500).json({
        status: 500,
        message: "Internal server error",
      });
    }
  }

  async addUser(request: Request, response: Response) {
    try {
      const body: any = request.body.userData;
      // Sanitize the input before logging
      const userDetails = {
        ...body,
        email: body.email.replace(/[^a-zA-Z0-9@._-]/g, ""),
        userName: body.userName.replace(/[^a-zA-Z0-9-_]/g, ""),
        name: body.name.replace(/[^a-zA-Z0-9-_ ]/g, ""),
      };
      const getcurrTime = moment().format("YYYY-MM-DD HH:mm:ss A");
      const product = new UsersItems(
        userDetails.id,
        userDetails.id,
        userDetails.userName,
        userDetails.name,
        userDetails?.email?.toLowerCase(),
        userDetails.is_authorized,
        true,
        userDetails.userinfo,
        getcurrTime,
        getcurrTime
      );
      console.log(userDetails, "add user body");
      let attribute = await this.dao.customQueryDataWithOR({
        email: userDetails.email,
      });
      console.log(attribute, "attribute");
      if (attribute && attribute?.length > 0) {
        let res = {
          data: [],
          msg: "User already exist!",
          status: "error",
        };
        response.send(res);
      } else {
        let data = await this.dao.addUser(product);
        let res: any = {};
        if (data.id !== undefined) {
          (res.data = data),
            (res.msg = "User created successfully!"),
            (res.status = "success");
        } else {
          (res.data = {}),
            (res.msg =
              "Error while creating user, Please try after some time!"),
            (res.status = "error");
        }
        response.send(res);
      }
    } catch (error) {
      return error;
    }
  }

  async updateUser(request: Request, response: Response) {
    try {
      const body = request.body.userData;
      const id = body.id;
      const partitionKey = body.id;
      console.log(`Received Body ${JSON.stringify(body)}`);
      const getcurrTime = moment().format("YYYY-MM-DD HH:mm:ss A");
      const product = {
        id: body.id,
        userName: body.userName,
        name: body.name,
        email: body.email,
        is_authorized: body.is_authorized,
        email_verified: body.email_verified,
        userinfo: body.userinfo,
        updated_at: getcurrTime,
      };

      console.log(`updateusers ${JSON.stringify(product)}`);
      let data = await this.dao.updateUser(id, partitionKey, product);
      let res: any = {};
      if (data.id !== undefined) {
        (res.data = data),
          (res.msg = "User Updated successfully!"),
          (res.status = "success");
      } else {
        (res.data = {}),
          (res.msg = "Error while updating user, Please try after some time!"),
          (res.status = "error");
      }
      response.send(res);
    } catch (error) {
      return error;
    }
  }

  async deleteUser(request: Request, response: Response) {
    try {
      const body = request.body;
      //   console.log(body, "ids");
      Promise.all(
        body.ids.map(async (id: any) => {
          let partitionKey = id;
          // const user = await this.dao.getUserbyid(id, partitionKey);
          // if (user == undefined) {
          //     return res.send({ msg: "user does not exist for deletion" });
          // }
          await this.dao.deleteUser(id, partitionKey);
        })
      );
      response.send({ msg: "user(s) deleted successfully" });
    } catch (error) {
      return error;
    }
  }
  async validateUser(request: Request, response: Response) {
    try {
      const body = request.body;
      //   console.log(body, "request body 33333333");
      const Result = await this.dao.customQueryDataWithOR({
        email: body.email,
      });
      //need to add valid user checks here
      // console.log(Result, 'Result email')
      let res = {};
      if (Result.length === 0) {
        res = {
          status: "error",
          msg: "user not found in system",
        };
      } else if (Result[0]?.is_authorized === "Y") {
        res = {
          status: "success",
          msg: "user found",
          data: Result,
        };
      } else {
        res = {
          status: "error",
          msg: "user not authorized to access the application",
          data: Result,
        };
      }
      response.send(res);
    } catch (error) {
      return error;
    }
  }

  async requestForAccessApp(request: Request, response: Response) {
    try {
      const body = request.body;
      //commented the log because of medium snyk issue
      // console.log(body, 'request body')
      // const Result = 'code to send mail to admin'
      // const Result = await this.dao.customQueryData({email: body.email});

      const username = body?.userinfo?.username;
      const email = body?.userinfo?.email;

      const toMailAddress = "admin@admin.com";

      let dynamicContent =
        "Request for User Verification to Access Application";
      const htmlContent = `Hi there, 
           <br>
           <b>${dynamicContent}</b>
           <br/>
           <br/>
           <p>FYI:</p>
           <br/>
           <p>We are reaching out to request your assistance in verifying a user's access to our application. 
           <br/>As part of our security protocols, we require users to undergo a verification process before granting them access privileges.</p>
           <br/>
           <br/>
           <p>The user in question is ${username}, and their email address associated with the account is ${email}. 
           <br/>We kindly request that you verify their identity and approve their access to the application.</p>
           <br/>
           <br/>
           regards,
           EMR-PDH
           `;
      if (toMailAddress?.length) {
        await emailController.sendEmail(
          toMailAddress,
          dynamicContent,
          "Test plain text",
          htmlContent
        );
      }

      //need to add valid user checks here
      let res = {
        status: "success",
        msg: "Requested to admin",
        data: [],
      };
      // if(Result.length === 0){
      //     res = {
      //         status: "error",
      //         msg: "user not found in system",
      //     }
      // }else{
      //     res = {
      //         status: "success",
      //         msg: "user found",
      //         data: Result
      //     }
      // }
      response.send(res);
    } catch (error) {
      return error;
    }
  }

  removeFile(filePath: any) {
    const allowedDirectory = path.resolve("uploads");
    const resolvedPath = path.resolve(filePath);
    if (!resolvedPath.startsWith(allowedDirectory)) {
      console.log("Invalid file path:", resolvedPath);
      return;
    }
    fs.remove(resolvedPath, (err) => {
      if (err) {
        console.error("Error occurred while deleting file:", err);
      }
      console.log("File deleted successfully!");
    });
  }

  async bulkAddUser1(req, res) {
    try {
      const allowedDirectory = path.resolve("uploads");
      // Get the uploaded file path
      const filePath = req.file.path;
      // Sanitize and validate the file path
      const resolvedPath = path.resolve(filePath);
      if (!resolvedPath.startsWith(allowedDirectory)) {
        return res
          .status(400)
          .send({ status: "error", msg: "Invalid file path." });
      }
      // Process the sanitized file path
      const workbook = XLSX.readFile(resolvedPath);
      const sheet_name_list = workbook.SheetNames;
      const json_data = XLSX.utils.sheet_to_json(
        workbook.Sheets[sheet_name_list[0]]
      );

      // Schedule file removal after processing
      this.removeFile(filePath);

      if (!json_data || json_data.length === 0) {
        return res
          .status(400)
          .send({ status: "error", msg: "No data found in the uploaded file" });
      }

      // Query existing records from the database
      const existingRecords = await this.dao.queryData();
      const existingEmails = new Set(
        existingRecords.map((record) => record.email)
      );

      let errors: any = [];
      let newUsers: any = [];
      let errorInUsers: any = [];

      // Validate and check for duplicates
      json_data.forEach((obj, index) => {
        let rowErrors: any = [];
        if (
          !obj["User Name"] ||
          !obj["Name"] ||
          !obj["Email"] ||
          !obj["Is Authorized"] ||
          !obj["User Group"]
        ) {
          rowErrors.push("All fields are required");
        }
        if (obj["Email"] && !validateEmail(obj["Email"])) {
          rowErrors.push("Invalid email format");
        }
        if (existingEmails.has(obj["Email"])) {
          rowErrors.push("Duplicate email found in the database");
        }
        if (
          obj["Is Authorized"] &&
          !["Yes", "No"].includes(obj["Is Authorized"])
        ) {
          rowErrors.push("Is Authorized should be 'Yes' or 'No'");
        }
        if (obj["User Group"]) {
          const userGroups = obj["User Group"]
            .split(",")
            .map((group) => group.trim());
          const validGroups = ["Everyone", "Guest", "admin"];
          if (
            userGroups.length > 3 ||
            userGroups.some((group) => !validGroups.includes(group))
          ) {
            rowErrors.push(
              "User Group should only contain 'Everyone', 'Guest', 'admin' and be comma-separated"
            );
          }
        }
        // Check for duplicates within the Excel data itself
        if (
          json_data.filter((item) => item["Email"] === obj["Email"]).length > 1
        ) {
          rowErrors.push("Duplicate email found in the excel sheet");
        }

        if (rowErrors.length > 0) {
          errors.push({ row: index + 1, errors: rowErrors });
        } else {
          newUsers.push(obj);
        }
      });

      if (errors.length > 0) {
        return res.status(400).send({ status: "error", errors: errors });
      }

      const userPromise = newUsers.map(async (item) => {
        try {
          const userGroups = item["User Group"]
            .split(",")
            .map((group) => group.trim());
          const user: any = {
            id: Date.now().toString(),
            userId: Date.now().toString(),
            userName: item["User Name"],
            name: item["Name"],
            email: item["Email"],
            is_authorized: item["Is Authorized"],
            email_verfied: true,
            userinfo: userGroups,
            updated_at: moment().format("YYYY-MM-DD HH:mm:ss A"),
            created_at: moment().format("YYYY-MM-DD HH:mm:ss A"),
          };

          const result = await this.dao.addUser(user);
          return result;
        } catch (error) {
          console.error("Error adding user:", item, error);
          errorInUsers.push({ user: item, error: error.message });
          throw error;
        }
      });

      await Promise.all(userPromise)
        .then(() => {
          if (errorInUsers.length > 0) {
            res.status(400).send({ status: "error", errors: errorInUsers });
          } else {
            res.send({
              status: "success",
              msg: "Users added successfully",
              data: newUsers,
            });
          }
        })
        .catch((error) => {
          res.status(500).send({
            status: "error",
            msg: "An error occurred while adding users",
            error: error.message,
          });
        });
    } catch (error) {
      console.error(error, "catch Error");
      res.status(500).send({
        status: "error",
        msg: "Internal server error",
        error: error.message,
      });
    }
  }

  async bulkAddUser(req, res) {
    try {
      const allowedDirectory = path.resolve("uploads");
      // Get the uploaded file path
      const filePath = req.file.path;
      // Sanitize and validate the file path
      const resolvedPath = path.resolve(filePath);
      if (!resolvedPath.startsWith(allowedDirectory)) {
        return res
          .status(400)
          .send({ status: "error", msg: "Invalid file path." });
      }
      // Process the sanitized file path
      const workbook = XLSX.readFile(resolvedPath);
      const sheet_name_list = workbook.SheetNames;
      const json_data = XLSX.utils.sheet_to_json(
        workbook.Sheets[sheet_name_list[0]]
      );

      // Schedule file removal after processing
      this.removeFile(filePath);

      if (!json_data || json_data.length === 0) {
        return res
          .status(400)
          .send({ status: "error", msg: "No data found in the uploaded file" });
      }

      // Query existing records from the database
      const existingRecords = await this.dao.queryData();
      const existingEmails = new Set(
        existingRecords.map((record) => record.email)
      );

      let errors: any = [];
      let newUsers: any = [];
      let errorInUsers: any = [];

      // Validate and check for duplicates
      json_data.forEach((obj, index) => {
        let rowErrors: any = [];

        if (
          !obj["User Name"] ||
          !obj["Name"] ||
          !obj["Email"] ||
          !obj["Is Authorized"] ||
          !obj["User Group"]
        ) {
          rowErrors.push("All fields are required");
        }
        if (obj["Email"] && !validateEmail(obj["Email"])) {
          rowErrors.push("Invalid email format");
        }
        if (existingEmails.has(obj["Email"])) {
          rowErrors.push(
            `Duplicate email found in the database: ${obj["Email"]}`
          );
        }
        if (
          obj["Is Authorized"] &&
          !["Yes", "No"].includes(obj["Is Authorized"])
        ) {
          rowErrors.push("Is Authorized should be 'Yes' or 'No'");
        }
        if (obj["User Group"]) {
          const userGroups = obj["User Group"]
            .split(",")
            .map((group) => group.trim());
          const validGroups = ["Everyone", "Guest", "admin"];
          if (
            userGroups.length > 3 ||
            userGroups.some((group) => !validGroups.includes(group))
          ) {
            rowErrors.push(
              "User Group should only contain 'Everyone', 'Guest', 'admin' and be comma-separated"
            );
          }
        }
        // Check for duplicates within the Excel data itself
        const duplicateEmails = json_data
          .filter((item) => item["Email"] === obj["Email"])
          .map((item) => item["Email"]);
        if (duplicateEmails.length > 1) {
          rowErrors.push(
            `Duplicate email found in the excel sheet: ${duplicateEmails.join(
              ", "
            )}`
          );
        }

        if (rowErrors.length > 0) {
          errors.push({ row: index + 1, errors: rowErrors });
        } else {
          newUsers.push(obj);
        }
      });

      if (errors.length > 0) {
        return res.status(400).send({ status: "error", errors: errors });
      }

      // Function to add user with delay
      const addUserWithDelay = async (user, delay) => {
        return new Promise((resolve, reject) => {
          setTimeout(async () => {
            try {
              const result = await this.dao.addUser(user);
              resolve(result);
            } catch (error) {
              reject(error);
            }
          }, delay);
        });
      };

      // Counter for ensuring unique ID generation
      let idCounter = 0;

      // Adding users with delay
      for (const item of newUsers) {
        try {
          const userGroups = item["User Group"]
            .split(",")
            .map((group) => group.trim());
          const uniqueId = `${Date.now().toString()}-${idCounter++}`;
          const user: any = {
            id: uniqueId, // Generate unique ID
            userId: uniqueId, // Generate unique userId
            userName: item["User Name"],
            name: item["Name"],
            email: item["Email"],
            is_authorized: item["Is Authorized"],
            email_verfied: true,
            userinfo: userGroups,
            updated_at: moment().format("YYYY-MM-DD HH:mm:ss A"),
            created_at: moment().format("YYYY-MM-DD HH:mm:ss A"),
          };

          await addUserWithDelay(user, 1);
        } catch (error) {
          if (error.code === 409) {
            // Handle conflict error
            console.error("Conflict error - user already exists:", item, error);
            errorInUsers.push({
              user: item,
              error: "User already exists in the system",
            });
          } else {
            console.error("Error adding user:", item, error);
            errorInUsers.push({ user: item, error: error.message });
          }
        }
      }

      if (errorInUsers.length > 0) {
        res.status(400).send({ status: "error", errors: errorInUsers });
      } else {
        res.send({
          status: "success",
          msg: "Users added successfully",
        });
      }
    } catch (error) {
      console.error(error, "catch Error");
      res.status(500).send({
        status: "error",
        msg: "Internal server error",
        error: error.message,
      });
    }
  }

  async bulkExportUser(req: any, res: any) {
    let result = await this.bulkUserExportInternal(
      req.body?.data,
      req.body?.sheet_name
    );
    setTimeout(() => {
      this.removeFile(`downloads/${result.filePath}`);
    }, 10000);
    //updated with json
    res.json(result);
  }
  async bulkUserExportInternal(data: any, sheetName: string) {
    try {
      let json_data = data;
      let sheet_name = sheetName;
      const workBook = XLSX.utils.book_new();
      const workSheet = XLSX.utils.json_to_sheet(json_data);
      XLSX.utils.book_append_sheet(workBook, workSheet, sheet_name);
      // Generate buffer
      XLSX.write(workBook, { bookType: "xlsx", type: "buffer" });
      // Binary String
      XLSX.write(workBook, { bookType: "xlsx", type: "binary" });
      let fileName =
        sheet_name.replace(/\s+/g, "") +
        "_" +
        new Date().toISOString().split("T")[0] +
        "_" +
        Date.now().toString();
      XLSX.writeFile(workBook, `downloads/${fileName}.xlsx`);
      return {
        status: "success",
        msg: `file downloaded with name ${fileName}.xlsx`,
        filePath: `${fileName}.xlsx`,
      };
    } catch (error) {
      return error;
    }
  }
}
