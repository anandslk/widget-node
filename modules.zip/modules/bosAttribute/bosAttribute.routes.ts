import { BOSAttributeController } from './bosAttribute.controller';
import { serverMode } from '../../appconfig/config';
const express = require('express');
const router = express.Router();

const bosAttributeController = new BOSAttributeController();
setTimeout(async () => {
    await bosAttributeController.init().then(() => {
        console.log('Container created for Bos Attribute' + ((serverMode)));
    }).catch((err) => {
        console.log('Container creation failed');
        process.exit(1);
    });
}, 5000)

// (async () => {
//     await bosAttributeController.init().then(() => {
//         console.log('Container created for Bos Attribute' + ((serverMode)));
//     }).catch((err) => {
//         console.log('Container creation failed');
//         process.exit(1);
//     });
// })();


router.post('/getSpecDetails',
 (req, res, next) => {
    console.log('Received request for /getSpecDetails with body:', req.body);
        bosAttributeController.getSpecDetails(req, res).catch(next);
});

router.post('/createORupdateDetails',
(req, res, next) => {
    console.log('Received request for /createORupdateDetails with body:', req.body);
    bosAttributeController.createORupdateDetails(req, res).catch(next);
});
    
router.post('/getLatestItemSpecDetails',
(req, res, next) => {
    bosAttributeController.getLatestItemSpecDetails(req, res).catch(next);
});

router.post('/getLatestSpecItemDetails',
(req, res, next) => {
    bosAttributeController.getLatestSpecItemDetails(req, res).catch(next);
});

router.post('/processItem',
(req, res, next) => {
    bosAttributeController.processItem(req, res).catch(next);
});

export { router };


