import { Request, Response } from "express";
import AuthService from "../authentication/authService";
import API_CONFIG from "../config/APIConfig";
import axios from "axios";
import { urlConfig } from "../config/urlConfig";

const https = require("https");
import { configurations } from "../config/configurations";

const agent = new https.Agent({
  rejectUnauthorized: false,
});

interface FutureRequestHeaders {
  Cookie: string | undefined;
  SecurityContext: string;
  ENO_CSRF_TOKEN: string;
  "Content-Type": string;
}
class CAService {
  // const userInfo = {// Optional to pass this object
  //     username: authConfig.username,
  //     password: authConfig.password,
  //     securityContext: authConfig.SecurityContext
  // };
  async getAuthenticationToken(
    userInfo: any = {}
  ): Promise<FutureRequestHeaders> {
    const authService = new AuthService();
    const csrfToken = await authService.authenticateUser(userInfo);

    return csrfToken;
  }

  public async getCADetails(req: Request, res: Response): Promise<void> {
    try {
      const {
        caUrlParams,
        caUrlParamsForBasicdata,
        mfgItemUrlParams,
        mfgChildItemURLParams,
        mfgChildItemReqBody,
        mfgParentItemReqBody,
        engClassificationURLParams,
        engClassificationTitleURLParams,
        mfgParentItemURLParams,
        itemSpecURLParams,
        engItemUrlParams,
      } = API_CONFIG;
      const {
        caDetailsURL,
        mfgItemURL,
        mfgChildItemURL,
        engClassificationTitleURL,
        engClassificationURL,
        mfgParentItemURL,
        itemSpecURL,
        baseURL,
        engItemURL,
      } = urlConfig;
      console.log('queryParams', req.query);
      const csrfTokenAndHeaders = await this.getAuthenticationToken();
      const queryParams = req.query;
      const caId = queryParams?.caId;
      const caParam = queryParams?.isBasics || "";
      const caHeaderParams = caParam ? caUrlParamsForBasicdata : caUrlParams;
      const headers: IHeaders = {
        Cookie: csrfTokenAndHeaders.Cookie,
        SecurityContext: csrfTokenAndHeaders.SecurityContext,
        ENO_CSRF_TOKEN: csrfTokenAndHeaders.ENO_CSRF_TOKEN,
        "Content-Type": csrfTokenAndHeaders["Content-Type"],
      };
      // Make an axios GET request with the caId, query parameters, and headers
      const caRawResponse = await axios.get(`${caDetailsURL}/${caId}`, {
        params: caHeaderParams,
        headers,
        httpsAgent: agent,
      });

      const caResponseData = caRawResponse?.data;
      const tenantId = process.env.NODE_API_TENANT_ID;
      caResponseData.source = { url: tenantId };
      //assign plant name to ca Response
      const plantName = await this.assignPlantInfo(
        caResponseData?.organization,
        headers
      );
      caResponseData.plantName = plantName;
      if (caResponseData?.proposedChanges)
        delete caResponseData.proposedChanges;

      if (
        caResponseData?.isFlowedDownIn &&
        caResponseData?.isFlowedDownIn?.length > 0
      ) {
        res.send(caRawResponse.data);
        return;
      }

      const proposedItems =
        caResponseData?.realizedChanges?.map(
          (item: any) => item.where.identifier
        ) || [];

      const manufacturingItemsData: any = [];
      for (const mfgItem of proposedItems) {
        const manufacturingItemData = {};
        // Make API request for each item
        const mfgItemBasicResponse = await axios.get(
          `${mfgItemURL}/${mfgItem}`,
          {
            params: mfgItemUrlParams,
            headers,
            httpsAgent: agent,
          }
        );
        delete mfgItemBasicResponse.data.nlsLabel;
        //make or buy updates to manufacturing items
        const mfgItemBasicData = mfgItemBasicResponse?.data?.member[0];
        if (
          mfgItemBasicData &&
          configurations.MAKETYPES.includes(mfgItemBasicData?.type)
        ) {
          mfgItemBasicData.makeBuy = "make";
        } else if (
          mfgItemBasicData &&
          configurations.BUYTYPES.includes(mfgItemBasicData?.type)
        ) {
          mfgItemBasicData.makeBuy = "buy";
        }
        manufacturingItemData["basicInfo"] = mfgItemBasicResponse.data;

        const scopeEngItem =
          mfgItemBasicResponse?.data?.member[0]?.ScopeEngItem?.identifier;
        //getting parent details
        mfgParentItemReqBody.objectReferences[0].identifier = mfgItem;
        const mfgItemParentDetails = await axios.post(
          `${mfgParentItemURL}`,
          mfgParentItemReqBody,
          {
            params: mfgParentItemURLParams,
            headers,
            httpsAgent: agent,
          }
        );
        const parentsData = mfgItemParentDetails?.data?.member[0]?.[
          "dsmfg:MfgItemInstance"
        ].member.map((item: any) => item.parentObject.identifier);
        const requestedPromises = parentsData.map(async (parentId: any) => {
          const parentBasicResponse = await axios.get(
            `${mfgItemURL}/${parentId}`,
            {
              params: mfgItemUrlParams,
              headers,
              httpsAgent: agent,
            }
          );
          delete parentBasicResponse.data.nlsLabel;
          return parentBasicResponse.data;
        });
        const parentData = await Promise.all(requestedPromises);

        manufacturingItemData["parentDetails"] = parentData;

        //getting child details
        const mfgItemChildDetails = await axios.post(
          `${mfgChildItemURL}/${mfgItem}/expand`,
          mfgChildItemReqBody,
          {
            params: mfgChildItemURLParams,
            headers,
            httpsAgent: agent,
          }
        );
        const childData = mfgItemChildDetails?.data?.member?.filter(
          (item: any) => {
            if (
              item?.id !== mfgItem &&
              item?.type !== "DELFmiFunctionIdentifiedInstance"
            ) {
              return item;
            }
          }
        );
        manufacturingItemData["childDetails"] = childData || [];
        //getting engineering item details
        if (scopeEngItem) {
          https: console.log("scope link", `${engItemURL}/${scopeEngItem}`);
          const engDataBasic = await axios.get(
            `${engItemURL}/${scopeEngItem}`,
            {
              params: engItemUrlParams,
              headers,
              httpsAgent: agent,
            }
          );
          delete engDataBasic.data.nlsLabel;
          manufacturingItemData["engItemBasicInfo"] = engDataBasic.data;
          //getting classification details
          console.log("scope link", `${engClassificationURL}/${scopeEngItem}`);
          const clsDataEngItem = await axios.get(
            `${engClassificationURL}/${scopeEngItem}`,
            {
              params: engClassificationURLParams,
              headers,
              httpsAgent: agent,
            }
          );
          delete clsDataEngItem.data.nlsLabel;
          manufacturingItemData["classificationInfo"] = clsDataEngItem.data;

          //processing classification data
          const classificationData =
            clsDataEngItem?.data?.member[0]?.ClassificationAttributes?.member;
          const classIds =
            classificationData?.map((item: any) => item?.ClassID) || [];
          const partTypesClass =
            classificationData?.filter((item: any) =>
              item?.Attributes?.some(
                (attr: any) => attr.name === "PartTypesClass"
              )
            ) || [];
          const plantAssignmentClass =
            classificationData?.filter((item: any) =>
              item?.Attributes?.some(
                (attr: any) => attr.name === "PlantAssignmentClass"
              )
            ) || [];
          const ProductHierarchyClass =
            classificationData?.filter((item: any) =>
              item?.Attributes?.some(
                (attr: any) => attr.name === "ProductHierarchyClass"
              )
            ) || [];
          //getting class titles
          const requestedPromisesForClassTitle = classIds.map(
            async (classId: any) => {
              const classTitleData = await axios.get(
                `${engClassificationTitleURL}/${classId}`,
                {
                  params: engClassificationTitleURLParams,
                  headers,
                  httpsAgent: agent,
                }
              );
              delete classTitleData.data.nlsLabel;
              delete classTitleData.data.member[0].ParentClassification;
              return classTitleData?.data?.member[0];
            }
          );
          const classTitleData = await Promise.all(
            requestedPromisesForClassTitle
          );

          // Add titles to ProductHierarchyClassData
          ProductHierarchyClass.forEach((item) => {
            const matchingTitle = classTitleData.find(
              (titleItem) => titleItem.id === item.ClassID
            );
            if (matchingTitle) {
              item.title = matchingTitle.title;
            }
          });

          // Add titles to PlantAssignmentClassData
          plantAssignmentClass.forEach((item) => {
            const matchingTitle = classTitleData.find(
              (titleItem) => titleItem.id === item.ClassID
            );
            if (matchingTitle) {
              item.title = matchingTitle.title;
            }
          });

          // Add titles to PartTypesClassData
          partTypesClass.forEach((item) => {
            const matchingTitle = classTitleData.find(
              (titleItem) => titleItem.id === item.ClassID
            );
            if (matchingTitle) {
              item.title = matchingTitle.title;
            }
          });

          const displayType = partTypesClass.map((item) => item.title);

          const manufacturingResponsibility = plantAssignmentClass.map(
            (item) => item.title
          );
          const engItemBasicInfo =
            manufacturingItemData["engItemBasicInfo"]?.member[0];
          if (engItemBasicInfo)
            engItemBasicInfo.displayType =
              displayType && displayType.length > 0 ? displayType[0] : "";
          if (engItemBasicInfo)
            engItemBasicInfo.manufacturingResponsibility =
              manufacturingResponsibility;

          const specDataEngItem = await axios.get(
            `${itemSpecURL}/${scopeEngItem}`,
            {
              params: itemSpecURLParams,
              headers,
              httpsAgent: agent,
            }
          );

          const specFilterData = specDataEngItem?.data?.data?.map(
            (item: any) => item.dataelements
          );
          manufacturingItemData["specData"] = specFilterData;
        }
        manufacturingItemsData.push(manufacturingItemData);
      }
      caResponseData.proposedItems = manufacturingItemsData;
      delete caResponseData.realizedChanges;
      res.send(caRawResponse.data);
    } catch (error) {
      console.log("Exception in CA details", error);
    }
  }

  private async assignPlantInfo(
    organizationName: any,
    headers: IHeaders
  ): Promise<void> {
    const { companyUrlParams, companyPlantsUrlParams } = API_CONFIG;
    const { companyUrl, companyPlantsUrl } = urlConfig;
    //get company
    const companyData = await axios.get(`${companyUrl}`, {
      params: companyUrlParams,
      headers,
      httpsAgent: agent,
    });
    const companyId = companyData?.data?.data[0]?.id;
    //get Plants
    const plantsData = await axios.get(
      `${companyPlantsUrl}/${companyId}/plants`,
      {
        params: companyPlantsUrlParams,
        headers,
        httpsAgent: agent,
      }
    );

    const plantData = plantsData.data.data;
    const foundPlant =
      plantData && plantData.find((item) => item.name === organizationName);
    return foundPlant?.title || "";
  }

  public async createCA(req: Request, res: Response): Promise<void> {
    try {
      //  res.send("hello")
      // Your code for creating a new CA in the controller
    } catch (error) {
      // Handle error
    }
  }

  public async updateCA(req: Request, res: Response): Promise<void> {
    try {
      // Your code for updating a CA in the controller
    } catch (error) {
      // Handle error
    }
  }

  public async deleteCA(req: Request, res: Response): Promise<void> {
    try {
      // Your code for deleting a CA in the controller
    } catch (error) {
      // Handle error
    }
  }

  public async mrAutomation(req: Request, res: Response): Promise<void> {
    try {
      const { mfgItemURL, getPhysicalProductInfoURL, getInstanceURL, expandProductURL, getMfgItemByScopeURL, caDetailsURL, connectMbomItemToFdcaURL, promoteFdcaToAnyStateURL, getGraphURL, getRawMaterialDetailsURL, getRawMaterialDetailsByInstanceURL, updateOwnerURL, removeMfgInstanceURL, baseURL, mfgParentItemURL } = urlConfig;
      const { expandChildItemReqBody, caUrlParams, expandMfgItemReqBody, mfgParentItemURLParams, mfgParentItemReqBody, mfgItemUrlParams } = API_CONFIG;

      // Get authentication token only once
      const csrfTokenAndHeaders = await this.getAuthenticationToken();
      const headers: IHeaders = {
        Cookie: csrfTokenAndHeaders.Cookie,
        SecurityContext: csrfTokenAndHeaders.SecurityContext,
        ENO_CSRF_TOKEN: csrfTokenAndHeaders.ENO_CSRF_TOKEN,
        "Content-Type": csrfTokenAndHeaders["Content-Type"]
      };

      interface Product {
        id: string;
        RealizedChange: {
          where: {
            type: string;
          };
          operations: string[];
        };
        Mbom?: boolean;
        childDetails?: any[];
      }

      interface ProductDetails {
        ProductDetails: Product[];
        PlantName: string;
        FlowdownCAID: string;
        Owner: string
      }

      const productDetails: ProductDetails = req.body;
      const manufacturingItemsData: any[] = [];

      if (!Array.isArray(productDetails?.ProductDetails)) {
        throw new Error("Invalid ProductDetails format");
      }
      const getPlantName: any = await this.getPlantInfo(productDetails?.PlantName, headers);
      const expandProduct = productDetails.ProductDetails.map(async (product: Product) => {
        try {
          if (product?.RealizedChange?.where?.type == "Raw_Material") {
            const manufacturingItemData = {
              ...product,
              childDetails: []
            };

            return manufacturingItemData;
          }
          else {
            const mfgItemChildDetails = await axios.post(
              `${expandProductURL}/${product?.id}/expand`,
              expandChildItemReqBody,
              {
                headers,
                httpsAgent: agent,
              }
            );

            const childData = mfgItemChildDetails?.data.member
              .filter((item: any) => item?.Path && item.Path.length === 3)
              .map((child: any) => ({
                instanceId: child.Path[1],
                childProductId: child.Path[2]
              }));

            const manufacturingItemData = {
              ...product,
              childDetails: childData.length > 0 ? childData : []
            };

            return manufacturingItemData;
          }

        } catch (error) {
          console.error(`Error processing product ${product?.id}:`, error?.response?.data);
          throw error; // Return null to continue processing other products
        }
      });

      const expandProductData = await Promise.all(expandProduct);
      manufacturingItemsData.push(...expandProductData.filter(item => item !== null));

      const createMfgItemsPromises = manufacturingItemsData.map(async (product) => {
        try {
          let mfgItemId: any;
          let oldEngItemId: any;
          let oldEngChildData: any;
          const payload = {
            "data": [
              {
                id: product?.id,
                identifier: product?.id,
                type: product?.RealizedChange?.where?.type,
                source: baseURL,
                relativePath: `/resources/v1/modeler/dseng/dseng:EngItem/${product?.id}`
              }
            ]
          }
          if (product?.RealizedChange?.operations.includes('NewVersion')) {
            const getEgnItem = await axios.post(
              `${getGraphURL}`,
              payload,
              {
                headers,
                httpsAgent: agent,
              }
            );
            let filterEngItem = getEgnItem?.data?.results[0]?.versions?.filter((item: any) => item?.id == product?.id);
            oldEngItemId = filterEngItem[0]?.ancestors?.[0]?.id;
            if (filterEngItem[0]?.ancestors?.[0]?.id) {
              const mfgItemChildDetails = await axios.post(
                `${expandProductURL}/${filterEngItem[0]?.ancestors?.[0]?.id}/expand`,
                expandChildItemReqBody,
                {
                  headers,
                  httpsAgent: agent,
                }
              );
              oldEngChildData = mfgItemChildDetails?.data.member
                .filter((item: any) => item?.Path && item.Path.length === 3)
                .map((child: any) => ({
                  instanceId: child.Path[1],
                  childProductId: child.Path[2]
                }));
            }

            // Get MfgItem by Scope
            const getMfgItem = await axios.post(
              `${getMfgItemByScopeURL}`,
              [oldEngItemId],
              {
                params: { "$mask": "dsmfg:MfgItem.NavigateMask.utc" },
                headers,
                httpsAgent: agent,
              }
            );

            let filterScopeLink: any[] = [];
            await Promise.all(getMfgItem?.data?.member?.map(async (item: any) => {
              const response = await axios.get(`${mfgItemURL}/${item.mfgItemId}`, { headers, httpsAgent: agent });
              filterScopeLink.push(...response.data.member);
            }));
            console.log("filterScopeLink", filterScopeLink)
            const filteredItems = filterScopeLink.filter((el: any) => el.organization == getPlantName && el.type == (product?.Mbom ? 'CreateAssembly' : 'Provide') && el.state == 'RELEASED');
            mfgItemId = filteredItems[0]?.id;
            console.log("check product deatils with new version==>", product?.id, mfgItemId)
          } else {
            if (product?.RealizedChange?.where?.type == "Raw_Material") {
              const instanceId = await this.getInstanceId(manufacturingItemsData, product?.id);
              mfgItemId = await this.processItemForRawMaterial(product, headers, productDetails?.PlantName, instanceId, { mfgItemURL, getRawMaterialDetailsURL, getRawMaterialDetailsByInstanceURL });
              headers.SecurityContext = csrfTokenAndHeaders.SecurityContext;
              await this.createScopeLinkInitial(mfgItemId, headers, product?.id, mfgItemURL, product?.RealizedChange?.where?.type);
            }
            else {
              // Get MfgItem by Scope
              const getMfgItem = await axios.post(
                `${getMfgItemByScopeURL}`,
                [product?.id],
                {
                  params: { "$mask": "dsmfg:MfgItem.NavigateMask.utc" },
                  headers,
                  httpsAgent: agent,
                }
              );

              let filterScopeLink: any[] = [];
              await Promise.all(getMfgItem?.data?.member?.map(async (item: any) => {
                const response = await axios.get(`${mfgItemURL}/${item.mfgItemId}`, { headers, httpsAgent: agent });
                filterScopeLink.push(...response.data.member);
              }));
              const filteredItems = filterScopeLink.filter((el: any) => el.organization == getPlantName && el.type == (product?.Mbom ? 'CreateAssembly' : 'Provide') && el.state == 'IN_WORK');
              mfgItemId = filteredItems[0]?.id;
              if (mfgItemId) {
                console.log("mfg item id", mfgItemId, product?.id)
                const checkScopeLick = await this.getScopeLink(mfgItemId, headers, mfgItemURL);
                if (checkScopeLick?.ScopeEngItem?.identifier != product?.id) {
                  console.log("create scope link", product?.id)
                  await this.createScopeLinkInitial(mfgItemId, headers, product?.id, mfgItemURL, product?.RealizedChange?.where?.type);
                }
              }
              else {
                console.log("create new item")
                mfgItemId = await this.processItem(product, headers, productDetails?.PlantName, { mfgItemURL, getPhysicalProductInfoURL });
                headers.SecurityContext = csrfTokenAndHeaders.SecurityContext;
                await this.createScopeLinkInitial(mfgItemId, headers, product?.id, mfgItemURL, product?.RealizedChange?.where?.type);
              }
            }
          }
          return {
            ...product,
            mfgItemId,
            oldEngItemId,
            oldEngChildData
          };
        } catch (error) {
          // console.error(`Error processing product ${product?.id}:`, error);
          throw error;
          // return null; // Return null to continue processing other products
        }
      });

      const manufacturingItems = await Promise.all(createMfgItemsPromises);

      const uniqueManufacturingItems = manufacturingItems.filter(item => item !== null);

      const output = uniqueManufacturingItems.map(product => {
        if (product.childDetails.length > 0) {
          product.childDetails = product.childDetails.map(child => {
            const matchingChild = uniqueManufacturingItems.find(item => item.id === child.childProductId);
            return {
              ...child,
              mfgItemId: matchingChild ? matchingChild.mfgItemId : null,
              type: matchingChild ? matchingChild?.RealizedChange?.where?.type : null,
              Mbom: matchingChild ? matchingChild?.Mbom : null
            };
          });
        }
        return product;
      });

      const filterData = output?.filter((item: any) => item?.oldEngItemId);
      if (filterData?.length > 0) {
        filterData?.forEach(item => {
          if (item?.oldEngItemId) {
            const childDetailsIds = new Set(item.childDetails.map(child => child.childProductId));
            const oldEngChildDataIds = new Set(item.oldEngChildData.map(child => child.childProductId));
            // Add action as Cut in oldEngChildData's object when data is not found in childDetails
            item?.oldEngChildData.forEach(async(oldChild) => {
              const payloadOldChild = {
                "data": [
                  {
                    id: oldChild.childProductId,
                    identifier: oldChild.childProductId,
                    type: 'VPMReference',
                    source: baseURL,
                    relativePath: `/resources/v1/modeler/dseng/dseng:EngItem/${oldChild.childProductId}`
                  }
                ]
              }
              const getEgnItem = await axios.post(
                `${getGraphURL}`,
                payloadOldChild,
                {
                  headers,
                  httpsAgent: agent,
                }
              );
              const findAncestors = getEgnItem?.data?.results[0]?.versions?.filter((item: any) => item?.ancestors);
             // console.log("findAncestors",findAncestors[0]?.id)
              if (!childDetailsIds.has(findAncestors[0]?.id)) {
                console.log("yes cut")
                oldChild.action = 'Cut';
              }
            });

            // // // Add action as Add in childDetails's object when data is not found in oldEngChildData
            item.childDetails.forEach(async(newChild) => {
              const payloadNewChild = {
                "data": [
                  {
                    id: newChild.childProductId,
                    identifier: newChild.childProductId,
                    type: 'VPMReference',
                    source: baseURL,
                    relativePath: `/resources/v1/modeler/dseng/dseng:EngItem/${newChild.childProductId}`
                  }
                ]
              }
              const getEgnItem = await axios.post(
                `${getGraphURL}`,
                payloadNewChild,
                {
                  headers,
                  httpsAgent: agent,
                }
              );
              const findAncestors1 = getEgnItem?.data?.results[0]?.versions?.filter((item: any) => item?.ancestors);
            //  console.log("findAncestors1",findAncestors1[0]?.ancestors?.[0]?.id)
              if (!oldEngChildDataIds.has(findAncestors1[0]?.ancestors?.[0]?.id)) {
                console.log("yes add")
                newChild.action = 'Add';
              }
            });
          }
        });


        await Promise.all(filterData.map(async (filterItem: any) => {
          const expandOldMfgItem = await axios.post(
            `${mfgItemURL}/${filterItem?.mfgItemId}/expand`,
            expandMfgItemReqBody,
            {
              headers,
              httpsAgent: agent,
            }
          );

          const filteredData = expandOldMfgItem.data?.member?.filter(item => item.path && item.path.length === 3);
          const array: { childProductId: string | undefined, childMfgItemId: string | undefined, childMfgInstanceId: string | undefined }[] = [];

          await Promise.all(filteredData.map(async (item: { path: string[] }) => {
            const getScope = await this.getScopeLink(item.path[2], headers, mfgItemURL);
            array.push({
              childProductId: getScope?.ScopeEngItem?.identifier,
              childMfgItemId: getScope?.id,
              childMfgInstanceId: item.path[1]
            });
          }));
          if (filterItem?.oldEngChildData?.length > 0) {
            filterItem.oldEngChildData.forEach(dataItem => {
              const matchingArrayItem = array.find(arrayItem => arrayItem.childProductId === dataItem.childProductId);
              if (matchingArrayItem) {
                dataItem.childMfgItemId = matchingArrayItem.childMfgItemId;
                dataItem.childMfgInstanceId = matchingArrayItem.childMfgInstanceId;
              }
            });
          }
        }));

      }

      const getFdcaDetails = await this.fetchCaDetails(productDetails?.FlowdownCAID, headers, caDetailsURL, caUrlParams);
      const { cestamp: getCestamp, proposedChanges, state } = getFdcaDetails || {};
      const connectMbomItem = async (item: any, headers: any, getCestamp: string, connectMbomItemToFdcaURL: string, baseURL: string) => {
        try {
          const target = item?.RealizedChange?.operations?.includes('NewVersion')
            ? 'NewVersion'
            : 'CurrentVersion';
          const what = item?.RealizedChange?.operations?.includes('NewVersion') ? 'Modify' :'ChangeMaturityRelease';
          let type: string = '';
          if (item?.RealizedChange?.where?.type == "Raw_Material") {
            type = item.Mbom ? 'ProcessContinuousCreateMaterial' : 'ProcessContinuousProvide';
          } else {
            type = item.Mbom ? 'CreateAssembly' : 'Provide';
          }
          await this.connectMbomItemToFdca(productDetails?.FlowdownCAID, item.mfgItemId, type, headers, getCestamp, connectMbomItemToFdcaURL, target, what, baseURL);
        } catch (error) {
          console.log(`---Error for call flow data ca ${item.mfgItemId}: ${error}`);
          throw error;

        }
        return true
      };
     // console.log("proposedChanges", JSON.stringify(output))
      if (proposedChanges && proposedChanges.length > 0) {

        const result = await Promise.all(output.map(async (item) => {
          console.log("check proposed changes", item?.mfgItemId);
          const checkProposedChanges = proposedChanges.filter((proposedItem: any) => proposedItem?.where?.identifier === item?.mfgItemId);
          console.log("checkProposedChanges",checkProposedChanges)
          if (checkProposedChanges.length === 0) {
            console.log("create new proposed changes");
            return connectMbomItem(item, headers, getCestamp, connectMbomItemToFdcaURL, baseURL);
          }
          return true;
        }));

        if (result.every(success => success) && state == 'Prepare') {
          await this.promoteFdcaToInWork(productDetails?.FlowdownCAID, headers, promoteFdcaToAnyStateURL, 'In Work');
        }
      } else {
        console.log("create proposed changes");
        const fdcaDetailsPromises = await Promise.all(output.map(item => connectMbomItem(item, headers, getCestamp, connectMbomItemToFdcaURL, baseURL)));

        if (fdcaDetailsPromises.every(success => success)) {
          await this.promoteFdcaToInWork(productDetails?.FlowdownCAID, headers, promoteFdcaToAnyStateURL, 'In Work');
        } else {
          console.log('Not all mfgItemId connections were successful. Skipping promotion to "In Work".');
        }
      }

      const getRealizedData = await this.fetchCaDetails(productDetails?.FlowdownCAID, headers, caDetailsURL, { $fields: "realizedChanges" });
      const getRealizedDataArray = getRealizedData?.realizedChanges;
      console.log("getRealizedDataArray", getRealizedDataArray)

      if (getRealizedDataArray?.length > 0) {
        await Promise.all(getRealizedDataArray.map(async (item: any) => {
          if (item?.operations.includes("NewVersion")) {
            const getScopeLinkData = await this.getScopeLink(item?.where?.identifier, headers, mfgItemURL);
            console.log("check scope link data", getScopeLinkData?.ScopeEngItem?.identifier, item?.where?.identifier)
            const outputFilterData = output.filter((outputItem: any) => outputItem?.oldEngItemId === getScopeLinkData?.ScopeEngItem?.identifier);
            console.log("outputFilterData", JSON.stringify(outputFilterData))
            if(outputFilterData.length>0){
              // Remove the scope link
              console.log("Remove the scope link====>", item?.where?.identifier, outputFilterData[0]?.oldEngItemId);
              await this.removeScopeLink(item?.where?.identifier, headers, outputFilterData[0]?.oldEngItemId, mfgItemURL, productDetails?.FlowdownCAID);
              const createScopeLink = await this.createScopeLink(item?.where?.identifier, headers, outputFilterData[0]?.id, mfgItemURL, productDetails?.FlowdownCAID);
              if (createScopeLink.status === 200) {
                console.log("Scope link created successfully", item?.where?.identifier);
                const objectToUpdate = output.find(outputItem => outputItem.id === outputFilterData[0]?.id);
                if (objectToUpdate) {
                  objectToUpdate.mfgItemId = item?.where?.identifier;
                }
              }
            }
            else
            {
              console.log("check ====>")
              const objectToUpdate = output.find(outputItem => outputItem.id === getScopeLinkData?.ScopeEngItem?.identifier);
              if (objectToUpdate) {
                objectToUpdate.mfgItemId = item?.where?.identifier;
              }
            }
          }
        }));
      }

       const result = output.map(product => {
        if (product?.childDetails?.length > 0) {
          product.childDetails = product.childDetails.map((child: any) => {
            const matchingChild = output.find(item => item.id === child.childProductId);
            if(matchingChild)
            {
              return {
                ...child,
                mfgItemId: matchingChild ? matchingChild.mfgItemId : null,
              };
            }else{
              return child;
            }
           
          });
        }
        return product;
      });
      const newOutput = result.map(product => {
        if (product?.oldEngChildData?.length > 0) {
          product.oldEngChildData = product.oldEngChildData.map((child: any) => {
            const matchingChild = result.find(item => item.oldEngItemId === child.childProductId);
            if(matchingChild){
              return {
                ...child,
                childMfgItemId: matchingChild ? matchingChild.mfgItemId : null,
              };
            }
            else{
              return child;
            }
           
          });
        }
        return product;
      });
      // create MBOM for physical product and raw material 
       await Promise.all(newOutput.map(async (parent: any) => {
        try {
          const shouldProcessChildDetails = parent?.RealizedChange?.operations?.includes('NewVersion')
            ? parent?.RealizedChange?.operations?.includes('Add')
            : true;

          if (shouldProcessChildDetails) {
            await this.processChildDetails(parent, headers, productDetails, mfgItemURL, getInstanceURL, baseURL, mfgParentItemURL, mfgParentItemReqBody, mfgParentItemURLParams);
          }
        } catch (error) {
          console.error("Error processing parent", parent.id, error?.response?.data);
          throw error;
        }
      }));

       const filtersData = newOutput?.filter((item: any) => item?.oldEngItemId && item?.oldEngChildData?.length > 0); 
       console.log("filtersData", JSON.stringify(filtersData))

        await Promise.all(filtersData.map(async (item: any) => {
          for (const child of item.oldEngChildData) {
              if (child.action === 'Cut' && child.childMfgItemId) {
                 mfgParentItemReqBody.objectReferences[0].identifier = child.childMfgItemId;
                  console.log("mfgParentItemReqBody", JSON.stringify(mfgParentItemReqBody));
                  const mfgItemParentDetails = await axios.post(
                      `${mfgParentItemURL}`,
                      mfgParentItemReqBody,
                      {
                          params: mfgParentItemURLParams,
                          headers,
                          httpsAgent: agent,
                      }
                  );

                  const parentsData = mfgItemParentDetails?.data?.member[0]?.['dsmfg:MfgItemInstance'].member.filter(items => items.parentObject.identifier === item.mfgItemId);
                 console.log("parentsData====>", JSON.stringify(parentsData));

                  if (parentsData?.length > 0) {
                      await this.removeMfgInstance(parentsData[0].id, headers, removeMfgInstanceURL, productDetails?.FlowdownCAID);
                  }
              }
          }
      }));

       
  // Transfer ownership of FDCA to plant
      if(getRealizedData?.owner!=productDetails?.Owner){
        await this.transferOwnership(productDetails, headers, updateOwnerURL, getPlantName);
      }
     
      let dataArray: { id: any }[] = [];
      await Promise.all(newOutput.map(async (parent: any) => {
        try {
          const mfgItemBasicResponse = await axios.get(
            `${mfgItemURL}/${parent?.mfgItemId}`,
            {
              params: mfgItemUrlParams,
              headers,
              httpsAgent: agent,
            }
          );
          delete mfgItemBasicResponse.data.nlsLabel;
          //make or buy updates to manufacturing items
          const mfgItemBasicData = mfgItemBasicResponse?.data?.member[0];
          if(mfgItemBasicData?.owner != productDetails?.Owner){
            dataArray.push({ id: parent?.mfgItemId });
          }
        } catch (error) {
          console.error("Error processing parent", parent.mfgItemId);
          throw error;
        }
      }));

      console.log("dataArray", dataArray);

      if(dataArray.length > 0){
        await this.transferOwnershipForMfg(productDetails, headers, updateOwnerURL, getPlantName, dataArray);
      }
      res.status(200).send({
        success: true,
        message: "MR Automation has been successful",
        output: newOutput
      });
    } catch (error) {
      console.error("error=====>", error?.response?.data);
      res.status(200).send({
        success: false,
        message: "MR Automation has been failed",
      });
    }
  }



  private async getInstanceId(productDetails: any, productId: string): Promise<any> {
    try {
      let instanceId: string = '';
      productDetails?.forEach((item: any) => {
        if (item.childDetails?.length > 0) {
          item.childDetails?.forEach((child: any) => {
            if (child.childProductId == productId) {
              instanceId = child.instanceId;
            }
          });
        }
      });
      return instanceId;
    } catch (error) {
      console.error(`Error creating manufacturing item for product ${productId}:`, error?.response?.data);
      throw error;
    }
  }

  private async processChildDetails(parent: any, headers: IHeaders, productDetails: any, mfgItemURL: string, getInstanceURL: string, baseURL: string, mfgParentItemURL: string, mfgParentItemReqBody: any, mfgParentItemURLParams: any): Promise<void> {
    if (parent.childDetails && parent.childDetails.length > 0) {
      console.log(`---Processing child details for parent ${parent.id}-${parent.mfgItemId}`);
      await Promise.all(parent.childDetails.map(async (child: any) => {
        try {
          // when product is make then need to create MBOM
          if (parent.Mbom && child.mfgItemId != null) {
            mfgParentItemReqBody.objectReferences[0].identifier = child.mfgItemId;
            const mfgItemParentDetails = await axios.post(
              `${mfgParentItemURL}`,
              mfgParentItemReqBody,
              {
                params: mfgParentItemURLParams,
                headers,
                httpsAgent: agent,
              }
            );
            const parentsData = mfgItemParentDetails?.data?.member[0]?.['dsmfg:MfgItemInstance'].member.filter(items => items.parentObject.identifier === parent.mfgItemId);
            console.log("parentsData", parentsData);
            let reqBody: any;
            if (parentsData?.length > 0) {
              child.mbomData = parentsData[0];
              if (child.type == "Raw_Material") {
                const response = await axios.get(`${mfgItemURL}/${parent.mfgItemId}/dsmfg:MfgItemInstance/${child?.mbomData?.id}`, {
                  params: {
                    "$mask": "dsmfg:MfgItemInstanceMask.Details",
                    "$fields": "dsmveno:CustomerAttributes"
                  },
                  headers,
                  httpsAgent: agent
                });
                reqBody = {
                  "cestamp": child.mbomData?.cestamp,
                  "quantity": {
                    "inputValue": response?.data?.member[0]?.quantity.value,
                    "magnitude": response?.data?.member[0]?.quantity.magnitude,
                    "inputUnit": response?.data?.member[0]?.quantity.unit
                  },
                };
              } else {
                const responseEngIstance = await axios.get(`${getInstanceURL}/${parent.id}/dseng:EngInstance/${child?.instanceId}`, {
                  params: {
                    "$mask": "dsmveng:EngInstanceMask.Filterable",
                    "$fields": "dsmveno:CustomerAttributes,dsmvcfg:attribute.hasConfiguredInstance,dsmvxcad:attribute.XCADGenericInstExtension.FindNumber"
                  },
                  headers,
                  httpsAgent: agent
                });
                const responseMfgInstance = await axios.get(`${mfgItemURL}/${parent.mfgItemId}/dsmfg:MfgItemInstance/${child?.mbomData?.id}`, {
                  params: {
                    "$mask": "dsmfg:MfgItemInstanceMask.Details",
                    "$fields": "dsmveno:CustomerAttributes"
                  },
                  headers,
                  httpsAgent: agent
                });
                for (let key in responseEngIstance?.data?.member[0]?.customerAttributes) {
                  if (key.startsWith("MBOMAttributes__")) {
                    let mbomAttributes = responseEngIstance?.data?.member[0]?.customerAttributes[key];
                    for (let attrKey in mbomAttributes) {
                      if (attrKey.includes("MBOMReferenceDesignator")) {
                        mbomAttributes[attrKey] = responseEngIstance?.data?.member[0]?.name;
                      }
                    }
                  }
                }
                const engKey = Object.keys(responseEngIstance?.data?.member[0]?.customerAttributes).find(key => key.startsWith('MBOMAttributes__'));
                const mfgKey = Object.keys(responseMfgInstance?.data?.member[0]?.customerAttributes).find(key => key.startsWith('MBOMAttributes__'));
                if (engKey && mfgKey) {
                  const engAttributes = responseEngIstance?.data?.member[0]?.customerAttributes[engKey];
                  const mfgAttributes = responseMfgInstance?.data?.member[0]?.customerAttributes[mfgKey];

                  const areEqual = Object.keys(engAttributes).every(key => engAttributes[key] === mfgAttributes[key]);

                  console.log(`Are MBOMAttributes equal? ${areEqual}`);
                } else {
                  reqBody = {
                    "cestamp": child.mbomData?.cestamp,
                    "customerAttributes": responseEngIstance?.data?.member[0]?.customerAttributes,
                  };
                  const modifiedHeaders = { ...headers, 'DS-Change-Authoring-Context': `pid:${productDetails?.FlowdownCAID}` };
                  await axios.patch(`${mfgItemURL}/${parent.mfgItemId}/dsmfg:MfgItemInstance/${child.mbomData?.id}`, reqBody, { headers: modifiedHeaders, httpsAgent: agent });
                }
              }
            } else {
              console.log("create mbom data")
              const result = await this.createMBOM(parent.mfgItemId, headers, child.mfgItemId, mfgItemURL, child.type, child.Mbom, productDetails.FlowdownCAID, baseURL);
              child.mbomData = result?.member[0];

              if (child.type == "Raw_Material") {
                const response = await axios.get(`${mfgItemURL}/${parent.mfgItemId}/dsmfg:MfgItemInstance/${child?.mbomData?.id}`, {
                  params: {
                    "$mask": "dsmfg:MfgItemInstanceMask.Details",
                    "$fields": "dsmveno:CustomerAttributes"
                  },
                  headers,
                  httpsAgent: agent
                });
                reqBody = {
                  "cestamp": child.mbomData?.cestamp,
                  "quantity": {
                    "inputValue": response?.data?.member[0]?.quantity.value,
                    "magnitude": response?.data?.member[0]?.quantity.magnitude,
                    "inputUnit": response?.data?.member[0]?.quantity.unit
                  },
                };
              } else {
                const response = await axios.get(`${getInstanceURL}/${parent.id}/dseng:EngInstance/${child?.instanceId}`, {
                  params: {
                    "$mask": "dsmveng:EngInstanceMask.Filterable",
                    "$fields": "dsmveno:CustomerAttributes,dsmvcfg:attribute.hasConfiguredInstance,dsmvxcad:attribute.XCADGenericInstExtension.FindNumber"
                  },
                  headers,
                  httpsAgent: agent
                });
                for (let key in response?.data?.member[0]?.customerAttributes) {
                  if (key.startsWith("MBOMAttributes__")) {
                    let mbomAttributes = response?.data?.member[0]?.customerAttributes[key];
                    for (let attrKey in mbomAttributes) {
                      if (attrKey.includes("MBOMReferenceDesignator")) {
                        mbomAttributes[attrKey] = response?.data?.member[0]?.name;
                      }
                    }
                  }
                }
                reqBody = {
                  "cestamp": child.mbomData?.cestamp,
                  "customerAttributes": response?.data?.member[0]?.customerAttributes,
                };
              }
              const modifiedHeaders = { ...headers, 'DS-Change-Authoring-Context': `pid:${productDetails?.FlowdownCAID}` };
              await axios.patch(`${mfgItemURL}/${parent.mfgItemId}/dsmfg:MfgItemInstance/${child.mbomData?.id}`, reqBody, { headers: modifiedHeaders, httpsAgent: agent });
            }
          }
        } catch (error) {
          console.error(`Error processing child ${child.instanceId} of ${parent?.id}: ${error?.response?.data}`);
          throw error;
        }
      }));
    }
  }



  private async connectMbomItemToFdca(getFdcaId: any, getManufacturingItemId: any, getManufacturingItemType: any, headers: IHeaders, getCestamp: any, getConnectMbomItemToFdcaURL: string, target: string, what: string, baseURL: string): Promise<any> {
    try {
      const payload = {
        cestamp: getCestamp,
        add: [
          {
            proposedChanges: [
              {
                where: {
                  source: baseURL,
                  type: getManufacturingItemType,
                  identifier: getManufacturingItemId,
                  relativePath: `/resources/v1/modeler/dsmfg/dsmfg:MfgItem/${getManufacturingItemId}`,
                },
                target: target,
                whats: [
                  {
                    what: what,
                    why: ""
                  }
                ]
              },
            ],
          },
        ],
      };
      console.log(`---payload of connectMbomItemToFdca: ${JSON.stringify(payload)}`);
      //  console.log("headers",headers)
      const response = await axios.patch(`${getConnectMbomItemToFdcaURL}/${getFdcaId}`,
        payload,
        {
          headers,
          httpsAgent: agent,
        }
      );
      //  console.log("---response of connectMbomItemToFdca", response.data);
      return response.data;
    } catch (error) {
      const errorMessage = error.response.data.errorMessage;
      console.error(`Connect Flow down error message: ${errorMessage},${getManufacturingItemId}`);
      throw error;
    }
  }

  private async transferOwnership(productDetails: any, headers: IHeaders, updateOwnerURL: string, plantName: string): Promise<any> {
    try {
      const payload = {
        "owner": productDetails?.Owner,
        "organization": plantName,
        "collabspace": productDetails?.CollabSpace,
        "data": [
          {
            "id": productDetails?.FlowdownCAID,
          }
        ]
      }
      const response = await axios.post(`${updateOwnerURL}`, payload, {
        headers,
        httpsAgent: agent,
      });
      return response.data;
    } catch (error) {
      const errorMessage = error?.response?.data?.errorMessage;
      console.error(`Error while transfer ownership for flow down CA : ${errorMessage},${productDetails?.FlowdownCAID}`);
      throw error;

    }
  }

  private async transferOwnershipForMfg(productDetails: any, headers: IHeaders, updateOwnerURL: string, plantName: string, dataArray: any): Promise<any> {
    try {
      const payload = {
        "owner": productDetails?.Owner,
        "organization": plantName,
        "collabspace": productDetails?.CollabSpace,
        "data": dataArray
      }
      console.log("payload", JSON.stringify(payload));
      const response = await axios.post(`${updateOwnerURL}`, payload, {
        headers,
        httpsAgent: agent,
      });

      console.log("response=====>", JSON.stringify(response.data));
      return response.data;
    } catch (error) {
      const errorMessage = error?.response?.data;
      console.error(`Error while transfer ownership for mfg: ${JSON.stringify(errorMessage)}`);
      throw error;
    }
  }
  private async promoteFdcaToInWork(getFdcaId: any, headers: IHeaders, getUpdateFdcaToInWorkURL: string, state: string): Promise<any> {
    try {
      const payload = {
        data: [
          {
            id: getFdcaId,
            nextState: state
          },
        ],
      };
      const response = await axios.post(`${getUpdateFdcaToInWorkURL}`, payload, {
        headers,
        httpsAgent: agent,
      });
      console.log("response", JSON.stringify(response.data))
      return response.data;

    } catch (error) {
      const errorMessage = error?.response?.data?.errorMessage;
      console.error(`Error while promoting FDCA to In-Work for flowDownCA : ${errorMessage},${getFdcaId}`);
      throw error;

    }
  }

  private async fetchCaDetails(caId: any, headers: IHeaders, caDetailsURL: string, caUrlParams: any): Promise<any> {
    try {
      const response = await axios.get(`${caDetailsURL}/${caId}`,
        {
          params: caUrlParams,
          headers,
          httpsAgent: agent,
        });
      return response.data;
    } catch (error) {
      const errorMessage = error?.response?.data?.errorMessage;
      console.error(`Error fetching CA details for ID ${caId}: ${errorMessage}`);
      throw error;
    }
  }

  private async processItem(product: any, headers: IHeaders, plantName: string, urls: any): Promise<any> {
    try {
      const type = product.Mbom ? 'CreateAssembly' : 'Provide';
      const getMembers = await this.getProductDetails(product.id, headers, urls.getPhysicalProductInfoURL);
      const collabspace = getMembers[0]?.collabspace;
      const items = {
        title: getMembers[0]?.title,
        description: getMembers[0]?.description,
        ...(getMembers[0]?.['dseng:EnterpriseReference']?.['partNumber'] && {
          "dsmfg:EnterpriseReference": getMembers[0]?.['dseng:EnterpriseReference']
        }),
        ...(product.Mbom && {
          isLotNumberRequired: true,
          isSerialNumberRequired: true,
          outsourced: "Yes",
          planningRequired: "Yes",
          targetReleaseDate: this.generateFormattedDate(),
          spareManufacturedItem: true
        })
      };
      const result = await this.createMfgItem(urls.mfgItemURL, items, headers, type, collabspace, product.id, plantName, product.Operations);
      return result;
    } catch (error) {
      console.error(`Error processing item ${product.id}:`, error?.response?.data);
      throw error;
    }
  }


  private async processItemForRawMaterial(product: any, headers: IHeaders, plantName: string, instanceId: string, urls: any): Promise<any> {
    try {
      const type = product.Mbom ? 'ProcessContinuousCreateMaterial' : 'ProcessContinuousProvide';
      const getMembers = await this.getProductDetailsForRawMaterial(product.id, headers, urls.getRawMaterialDetailsURL);
      const getRawMaterailDetails = await this.getProductDetailsForRawMaterialByInstance(product.id, headers, urls.getRawMaterialDetailsByInstanceURL, instanceId);
      const collabspace = getMembers[0]?.collabspace;
      const items = {
        title: getMembers[0]?.title,
        description: getMembers[0]?.description,
        magnitude: getRawMaterailDetails[0]?.dimensionType,
        ...product.Mbom && {
          refQuantity: {
            inputUnit: getRawMaterailDetails[0]?.quantityUOM?.dbName,
            inputValue: getRawMaterailDetails[0]?.quantity,
            magnitude: getRawMaterailDetails[0]?.dimensionType
          },
        },
        ...(getMembers[0]?.['dseng:EnterpriseReference']?.['partNumber'] && {
          "dsmfg:EnterpriseReference": getMembers[0]?.['dseng:EnterpriseReference']
        }),

      };
      const result = await this.createMfgItem(urls.mfgItemURL, items, headers, type, collabspace, product?.id, plantName, product?.operations);
      return result;
    } catch (error) {
      console.error(`Error processing item ${product.id}:`, error?.response?.data);
      throw error;
    }
  }
  private async createScopeLink(mfgItemId: string, headers: IHeaders, productId: string, mfgItemURL: string, flowDownCAId: string): Promise<any> {
    console.log("Creating scope link for", mfgItemId, productId);
    try {
      const payload = {
        "identifier": productId,
        "source": "https://oi000186152-us1-acspace.3dexperience.3ds.com/3DSpace",
        "relativePath": `/resources/v1/modeler/dseng/dseng:EngItem/${productId}`,
        "type": "VPMReference",
        "syncEIN": true
      };
      const modifiedHeaders = { ...headers, 'DS-Change-Authoring-Context': `pid:${flowDownCAId}` };
      const response = await axios.post(`${mfgItemURL}/${mfgItemId}/dsmfg:ScopeEngItem/attach`, payload, { headers: modifiedHeaders, httpsAgent: agent });
      console.log("Created new scope link", response?.data);
      return response?.data;
    } catch (error) {
      console.error(`Error creating scope link for ${mfgItemId}:`, error?.response?.data);
      throw error;
    }
  }

  private async createScopeLinkInitial(mfgItemId: string, headers: IHeaders, productId: string, mfgItemURL: string, type: string): Promise<any> {
    try {
      const payload = {
        "identifier": productId,
        "source": "https://oi000186152-us1-acspace.3dexperience.3ds.com/3DSpace",
        "relativePath": `/resources/v1/modeler/dseng/dseng:EngItem/${productId}`,
        "type": type,
        "syncEIN": true
      };
      console.log("payload of createScopeLinkInitial", JSON.stringify(payload))
      const response = await axios.post(`${mfgItemURL}/${mfgItemId}/dsmfg:ScopeEngItem/attach`, payload, { headers, httpsAgent: agent });
      console.log(`---Scope link created for ${response?.data}`);
      return response?.data;

    } catch (error) {
      console.error(`Error creating scope link for initial ${mfgItemId}:`, error?.response?.data);
      throw error;
    }
  }

  private async removeScopeLink(mfgItemId: string, headers: IHeaders, productId: string, mfgItemURL: string, flowDownCAId: string): Promise<any> {
    try {
      const payload = {
        "identifier": productId,
        "source": "https://oi000186152-us1-acspace.3dexperience.3ds.com/3DSpace",
        "relativePath": `/resources/v1/modeler/dseng/dseng:EngItem/${productId}`,
        "type": "VPMReference",
        "syncEIN": true
      };
      const modifiedHeaders = { ...headers, 'DS-Change-Authoring-Context': `pid:${flowDownCAId}` };
      const response = await axios.post(`${mfgItemURL}/${mfgItemId}/dsmfg:ScopeEngItem/detach`, payload, { headers: modifiedHeaders, httpsAgent: agent });
      console.log("response for remove scope link", response?.data);
      return response?.data;
    } catch (error) {
      const errorMessage = error?.response?.data?.message;
      console.error(`Error remove scope link for ID ${mfgItemId}: ${errorMessage}`);
      throw error;
    }
  }

  private async removeMfgInstance(mfgItemInstanceId: string, headers: IHeaders, removeMfgInstanceURL: string, flowDownCAId: string): Promise<any> {
    try {
      console.log("Removing mfg Instance link for", mfgItemInstanceId);
      const modifiedHeaders = { ...headers, 'DS-Change-Authoring-Context': `pid:${flowDownCAId}` };
      const response = await axios.post(`${removeMfgInstanceURL}`, [mfgItemInstanceId], { headers: modifiedHeaders, httpsAgent: agent });
      console.log("response for remove mfg Instance link", response?.data);
      return response?.data;
    } catch (error) {
      const errorMessage = error?.response?.data?.message;
      console.error(`Error remove mfg Instance link for ID ${mfgItemInstanceId}: ${errorMessage}`);
      throw error;
    }
  }

  private async getScopeLink(mfgItemId: string, headers: IHeaders, mfgItemURL: string): Promise<any> {
    try {
      const response = await axios.get(`${mfgItemURL}/${mfgItemId}/dsmfg:ScopeEngItem`, { headers, httpsAgent: agent });
      return response?.data?.member?.[0];
    } catch (error) {
      console.error(`Error get scope link for ${mfgItemId}:`, error?.response?.data);
      throw error;
    }
  }

  private async createMBOM(mfgItemId: string, headers: IHeaders, mfgChildItemId: string, mfgItemURL: string, type: string, Mbom: string, flowDownCAId: string, baseURL: string): Promise<any> {
    try {
      let payload: any;
      if (type == "Raw_Material") {
        payload = {
          "instances": [
            {
              "referencedObject": {
                "identifier": mfgChildItemId,
                "source": baseURL,
                "relativePath": `/resources/v1/modeler/dsmfg/dsmfg:MfgItem/${mfgChildItemId}`,
                "type": Mbom ? 'ProcessContinuousCreateMaterial' : 'ProcessContinuousProvide'
              }
            }
          ]
        };
      }
      else {
        payload = {
          "instances": [
            {
              "referencedObject": {
                "identifier": mfgChildItemId,
                "source": baseURL,
                "relativePath": `/resources/v1/modeler/dsmfg/dsmfg:MfgItem/${mfgChildItemId}`,
                "type": Mbom ? 'CreateAssembly' : 'Provide'
              }
            }
          ]
        };
      }

      const modifiedHeaders = { ...headers, 'DS-Change-Authoring-Context': `pid:${flowDownCAId}` };
      const response = await axios.post(`${mfgItemURL}/${mfgItemId}/dsmfg:MfgItemInstance`, payload, { headers: modifiedHeaders, httpsAgent: agent });
      return response?.data;
    } catch (error) {
      console.error(`Error creating MBOM for ${mfgItemId}:`, error?.response?.data);
      throw error;

    }
  }

  private async getProductDetails(productId: string, headers: IHeaders, getPhysicalProductInfoURL: string): Promise<any> {
    try {
      const response = await axios.get(`${getPhysicalProductInfoURL}/${productId}`, { params: { "$mask": "dsmveng:EngItemMask.Details" }, headers, httpsAgent: agent });
      return response?.data?.member;
    } catch (error) {
      console.error(`Error getting product details for ${productId}:`, error?.response?.data);
      throw error;
    }
  }

  private async getProductDetailsForRawMaterialByInstance(productId: string, headers: IHeaders, getRawMaterialDetailsByInstanceURL: string, instanceId: string): Promise<any> {
    try {
      const payload = { instanceIds: [instanceId] };
      const response = await axios.post(`${getRawMaterialDetailsByInstanceURL}`, payload, { params: { "tenant": "OI000186152", "SecurityContext": headers.SecurityContext }, headers, httpsAgent: agent });
      return response?.data?.result;
    } catch (error) {
      console.error(`Error getting product details for ${productId}:`, error?.response?.data);
      throw error;
    }
  }


  private async getProductDetailsForRawMaterial(productId: string, headers: IHeaders, getRawMaterialDetailsURL: string): Promise<any> {
    try {
      const response = await axios.get(`${getRawMaterialDetailsURL}/${productId}`, { params: {}, headers, httpsAgent: agent });
      return response?.data?.member;
    } catch (error) {
      console.error(`Error getting product details for ${productId}:`, error?.response?.data);
      throw error;
    }
  }
  private generateFormattedDate(): string {
    let today = new Date();
    today.setDate(today.getDate() + 5);
    const pad = (num: number) => num.toString().padStart(2, '0');
    return `${today.getFullYear()}/${pad(today.getMonth() + 1)}/${pad(today.getDate())}@${pad(today.getHours())}:${pad(today.getMinutes())}:${pad(today.getSeconds())}:GMT`;
  }

  private async createMfgItem(mfgItemURL: string, items: any, headers: IHeaders, type: string, collabspace: string, productId: string, plantName: string, operations: string): Promise<any> {
    try {
      const reqBody = { "items": [{ "type": type, "attributes": items }] };
      const getPlantName = await this.getPlantInfo(plantName, headers);
      headers.SecurityContext = headers.SecurityContext.replace(headers.SecurityContext?.split('.')[1], getPlantName);
      headers.SecurityContext = headers.SecurityContext.replace(headers.SecurityContext?.split('.')[2], collabspace);
      console.log("check create mfg item payload", JSON.stringify(reqBody))
      const response = await axios.post(mfgItemURL, reqBody, { headers, httpsAgent: agent });
      console.log("check create mfg item response", JSON.stringify(response?.data))

      let mfgItemId = response?.data?.member[0].id;
      return mfgItemId;
    } catch (error) {
      console.error(`Error creating manufacturing item for product ${productId}:`, error?.response?.data);
      throw error;
    }
  }


  private async getPlantInfo(plantName: any, headers: IHeaders): Promise<string> {
    const { companyUrlParams, companyPlantsUrlParams } = API_CONFIG;
    const { companyUrl, companyPlantsUrl } = urlConfig;
    //get company
    const companyData = await axios.get(`${companyUrl}`, {
      params: companyUrlParams,
      headers,
      httpsAgent: agent,
    });
    const companyId = companyData?.data?.data[0]?.id;
    //get Plants
    const plantsData = await axios.get(
      `${companyPlantsUrl}/${companyId}/plants`,
      {
        params: companyPlantsUrlParams,
        headers,
        httpsAgent: agent,
      }
    );

    const plantData = plantsData.data.data;
    const foundPlant = plantData && plantData.find((item) => item.title === plantName);
    return foundPlant?.name || "";
  }
}

export default CAService;
