const express = require('express');
const router = express.Router();
import caDataController from './caController';

const controller = new caDataController();
console.log('Received GET request for /ca/getDetails with query:');
router.get('/getCADetails', (req, res, next) => controller.getCADetails(req, res).catch(next));

router.post('/mrAutomation', (req, res, next) => controller.mrAutomation(req, res).catch(next));




export { router };