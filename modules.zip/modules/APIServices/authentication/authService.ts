import axios, {AxiosHeaders, AxiosResponse} from 'axios';
import authConfig from '../config/authConfig';
const https = require('https');

const agent = new https.Agent({  
  rejectUnauthorized: false
});

interface FutureRequestHeaders {
    Cookie: string|undefined;
    SecurityContext: string;
    ENO_CSRF_TOKEN: string;
    'Content-Type': string;
}

class AuthService {
    async authenticateUser(userData:any): Promise<FutureRequestHeaders> {
        try {
            const {AuthURL, AuthParamURL, CSRFURL, username, password, SecurityContext} = authConfig;

            // Make a request to the 3rd party API using Axios
            const response: AxiosResponse<any, any> = await axios.get(AuthParamURL,  { httpsAgent: agent });
            console.log(response?.data?.lt);
            const LoginToken = response?.data?.lt;
            let AuthURLComplete = `${AuthURL}lt=${LoginToken}&username=${username}&password=${password}&service=${CSRFURL}`;
            const loginCookies = response.headers['set-cookie'];
            const csrfTockenURLResponse: AxiosResponse<any, any> = await axios.post(AuthURLComplete, null, {
                httpsAgent: new https.Agent({  
                  rejectUnauthorized: false
                }),
                headers: {
                    'Cookie': loginCookies?.join('; '),
                    'Content-Type': response.headers['Content-Type'],
                    'User-Agent': 'test'
                }
            });
            const afterLogInCookies = csrfTockenURLResponse.headers['set-cookie'];
            const csrfValue = csrfTockenURLResponse?.data?.csrf.value;

            

            const partialHeaders: Partial<FutureRequestHeaders> = {
            Cookie: afterLogInCookies?.join("; "),
            ENO_CSRF_TOKEN: csrfValue,
            // 'SecurityContext': SecurityContext,
            "Content-Type": "application/json",
            };

            const defaultSecContext = await this.getDefaultSecurityContext(partialHeaders);
            partialHeaders.SecurityContext = defaultSecContext;

            const headersForFutureRequests = partialHeaders as FutureRequestHeaders;


            // Return the authentication token
            return headersForFutureRequests;
        } catch (error) {
            console.log(error)
            // Handle any errors that occur during the request
            throw new Error('Failed to authenticate user');
        }
    }

    async getDefaultSecurityContext(headersForFutureRequests:Partial<FutureRequestHeaders>): Promise<string> {
        try {

            const headers: IHeaders = {
                Cookie: headersForFutureRequests.Cookie,
                SecurityContext: headersForFutureRequests.SecurityContext,
                ENO_CSRF_TOKEN: headersForFutureRequests.ENO_CSRF_TOKEN,
                "Content-Type": headersForFutureRequests["Content-Type"],
              };
            const currentUserContextURL = authConfig.currentUserContextURL;
            const securityContextResponse: AxiosResponse<any, any> = await axios.get(currentUserContextURL,  { 
                headers,
                httpsAgent: agent,
                 
            });

            const firstCollabSpaceDetails =  securityContextResponse?.data?.collabspaces[0];
            const defaultSecContext = `${firstCollabSpaceDetails?.couples[0]?.role?.name}.${firstCollabSpaceDetails?.couples[0]?.organization?.name}.${firstCollabSpaceDetails?.name}`;
            return defaultSecContext;
        } catch (error) {
            console.log(error)
            // Handle any errors that occur during the request
            throw new Error('Failed to get default security context');
        }
    }
}

export default AuthService;