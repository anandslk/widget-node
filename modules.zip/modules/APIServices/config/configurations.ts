export const configurations = {
  BUYTYPES: ["Provide"],
  MAKETYPES: ["CreateAssembly"],
};
