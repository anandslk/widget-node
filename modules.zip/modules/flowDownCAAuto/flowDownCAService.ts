import { Request, Response } from "express";
import AuthService from "../APIServices/authentication/authService";
import API_CONFIG from "../APIServices/config/APIConfig";
import axios, { AxiosHeaders } from "axios";
import { urlConfig } from "../APIServices/config/urlConfig";
import authConfig, {
  securityContextConfig
} from "../APIServices/config/authConfig";
import { Console, error } from "console";
const https = require("https");

const agent = new https.Agent({
  rejectUnauthorized: false,
});

interface FutureRequestHeaders {
  Cookie: string | undefined;
  SecurityContext: string;
  ENO_CSRF_TOKEN: string;
  "Content-Type": string;
}

interface updateMRInput {
  productPhysicalId: string;
  changeID: string;
  ChangeName: string;
  productName: string;
  productType: string;
  productPlantName: string;
  productProductionTypeChanged: boolean;
  productLatestProductionValue: string;
  productMaterialType: string;
  isMaterialTypeInOptional: boolean;
  isMaterialTypeInNotOptional: boolean;
}
class getFlowDownCAService {
  // const userInfo = {// Optional to pass this object
  //     username: authConfig.username,
  //     password: authConfig.password,
  //     securityContext: authConfig.SecurityContext
  // };
  async getAuthenticationToken(
    userInfo: any = {}
  ): Promise<FutureRequestHeaders> {
    const authService = new AuthService();
    const csrfToken = await authService.authenticateUser(userInfo);
    console.log(`csrfToken: ${JSON.stringify(csrfToken)}`);
    return csrfToken;
  }

  private async fetchCaDetails(
    caId: any,
    headers: IHeaders
  ): Promise<any> {
    try {
      const { caDetailsURL } = urlConfig;
      const { caUrlParams } = API_CONFIG;
      console.log(`====headers: ${JSON.stringify(headers)}`);
      const response = await axios.get(`${caDetailsURL}/${caId}`, {
        params: caUrlParams,
        headers,
        httpsAgent: agent,
      });
      return response.data;
    } catch (error) {
      if (error.response && error.response.data && error.response.data.errorMessage) {
        console.error(`Error fetching CA details for ID ${caId}: ${error.response.data.errorMessage}`);
      } else {
        console.error("An unknown error occurred:", error);
      }
      throw error;
    }
  }

  private async fetchClassificationAttribute(
    realizedItem: any,
    headers: IHeaders,
  ): Promise<any> {
    try {
      const { engClassificationURL } = urlConfig;
      const { engClassificationURLParams } = API_CONFIG
      const response = await axios.get(`${engClassificationURL}/${realizedItem}`,
        {
          params: engClassificationURLParams,
          headers,
          httpsAgent: agent,
        }
      );
      return response.data;
    } catch (error) {
      console.error(`Error fetching Classification Attribute details for item ${realizedItem}:`,error);
      return null;
    }
  }

  private async fetchClassName(
    realizedClassId: any,
    headers: IHeaders,
  ): Promise<any> {
    try {
      const { engClassificationIdURL } = urlConfig;
      const response = await axios.get(`${engClassificationIdURL}/${realizedClassId}`,
        {
          headers,
          httpsAgent: agent,
        }
      );
      return response.data;
    } catch (error) {
      console.error(`Error fetching ClassName for item: ${realizedClassId}:`,error);
      return "";
    }
  }

  private async getPlantInfo(
    plantName: any,
    headers: IHeaders
  ): Promise<string> {
    try {
      const { companyUrlParams, companyPlantsUrlParams } = API_CONFIG;
      const { companyUrl, companyPlantsUrl } = urlConfig;
      //get company
      const companyData = await axios.get(`${companyUrl}`, {
        params: companyUrlParams,
        headers,
        httpsAgent: agent,
      });
      const companyId = companyData?.data?.data[0]?.id;
      //get Plants
      const plantsData = await axios.get(`${companyPlantsUrl}/${companyId}/plants`,
        {
          params: companyPlantsUrlParams,
          headers,
          httpsAgent: agent,
        }
      );
      const plantData = plantsData.data.data;
      const foundPlant = plantData && plantData.find((item) => item.title === plantName);
      return foundPlant?.name || "";
    } catch(error) {
        console.error(`Error fetching PlantInfo for item: ${plantName}: `,error);
        throw error;
    }
  }

  private async createFlowDownCA(
    headers: IHeaders,
    getName: string,
    getKey: string,
    getCollabSpace: string,
    getDesc: string,
    getSeverity: string
  ): Promise<any> {
    try {
      const { createCAURL } = urlConfig;
      const payload = {
        policy: "Change Action",
        description: getDesc,
        type: "Change Action",
        title: getName,
        name: getName,
        severity: getSeverity,
      };
      console.log(`---CreateFDCAPayload: ${JSON.stringify(payload)}`);
      console.log(`---CreateFDCAHeader: ${JSON.stringify(headers)}`);

      const getPlantNumber = await this.getPlantInfo(getKey, headers);
      const parts = headers.SecurityContext?.split(".");
      if (parts && parts.length === 3) {
        parts[1] = getPlantNumber
        headers.SecurityContext = parts.join(".");
      }

      headers.SecurityContext = headers.SecurityContext.replace(headers.SecurityContext?.split(".")[2],getCollabSpace);
    
      console.log(`---CreateFDCAHeaderAfterModification: ${JSON.stringify(headers)}`);

      const response = await axios.post(`${createCAURL}`, payload, {
        headers,
        httpsAgent: agent,
      });
      return response.data;
    } catch (error) {
      if (error.response && error.response.data && error.response.data.errorMessage) {
        console.error(`Error while creating FDCA for plant ${getName}: ${error.response.data.errorMessage}`);
      } else {
        console.error("An unknown error occurred:", error);
      }
      throw error;
    }
  }

  private async createFlowDownCANew(
    headers: IHeaders,
    getName: string,
    getOrganization: string,
    getCollabSpace: string,
    getDesc: string,
    getSeverity: string
  ): Promise<any> {
    try {
      const { createCAURL } = urlConfig;
      const payload = {
        policy: "Change Action",
        description: getDesc,
        type: "Change Action",
        title: getName,
        name: getName,
        severity: getSeverity,
      };
      console.log(`---CreateFDCAPayload: ${JSON.stringify(payload)}`);
      console.log(`---CreateFDCAHeader: ${JSON.stringify(headers)}`);

      //const getPlantNumber = await this.getPlantInfo(getKey, headers);
      headers.SecurityContext = headers.SecurityContext.replace(headers.SecurityContext?.split(".")[0],securityContextConfig.LeaderCredential);
      headers.SecurityContext = headers.SecurityContext.replace(headers.SecurityContext?.split(".")[1],getOrganization);
      headers.SecurityContext = headers.SecurityContext.replace(headers.SecurityContext?.split(".")[2],getCollabSpace);

      console.log(`---CreateFDCAHeaderAfterModification: ${JSON.stringify(headers)}`);

      const response = await axios.post(`${createCAURL}`, payload, {
        headers,
        httpsAgent: agent,
      });
      return response.data;
    } catch (error) {
      if (error.response && error.response.data && error.response.data.errorMessage) {
        console.error(`Error while creating FDCA for plant ${getName}: ${error.response.data.errorMessage}`);
      } else {
        console.error("An unknown error occurred:", error);
      }
      throw error;
    }
  }

  private async fetchPhysicalProductDetails(getPhysicalProductId: any, headers: IHeaders): Promise<any> {
    try {
      console.log(`----Headers of fetchPhysicalProductDetails: ${JSON.stringify(headers)}`);
      const { getPhysicalProductInfoURL } = urlConfig;
      const response = await axios.get(`${getPhysicalProductInfoURL}/${getPhysicalProductId}`,
        { params: { "$mask": "dsmveng:EngItemMask.Details" },
          headers,
          httpsAgent: agent,
        }
      );
      return response.data;
    } catch (error) {
      console.error(`Error while fetching Physical Product details for ID ${getPhysicalProductId}: ${error}`);
      throw error;
    }
  }

  private async modifyCA(
    modifyCAURL: string,
    headers: IHeaders,
    cestamp: any,
    upstreamCaId: any,
    flowdownCaId: any
  ): Promise<any> {
    try {
      const payload = {
        cestamp: cestamp,
        add: [
          {
            isFlowDownOf: [
              {
                type: "Change Action",
                identifier: flowdownCaId,
                relativePath: `/resources/v1/modeler/dslc/changeaction/${flowdownCaId}`,
              },
            ],
          },
        ],
      };
      const response = await axios.patch(`${modifyCAURL}/${upstreamCaId}`,
        payload,
        {
          headers,
          httpsAgent: agent,
        }
      );
      return response.data;
    } catch (error) {
      console.error(`Error while modifying CA for flowDownCA: ${flowdownCaId}:`,error);
      return null;
    }
  }

  private async addingOwnerAsApprover(
    getFdcaId: string,
    headers: IHeaders,
    upstreamCaId: any,
  ): Promise<any> {
    try {
      const { modifyCaURL, caDetailsURL } = urlConfig;
      const { caUrlParams } = API_CONFIG;
      const fdcaDetailsResponse = await axios.get(`${caDetailsURL}/${getFdcaId}`, {
        params: caUrlParams,
        headers,
        httpsAgent: agent,
      });
      const payload = {
        cestamp: fdcaDetailsResponse.data.cestamp,
        "add": [
            {
                "members": [
                    {
                        "reviewers": [
                            "e1331143" //Here it should be replaced by Upstream CA owner
                        ]
                    }
                ]
            }
        ],
        "remove": [
            {
                "members": [
                    {
                        "followers": [
                          fdcaDetailsResponse.data.owner
                        ]
                    }
                ]
            }
        ]
      };
      const response = await axios.patch(`${modifyCaURL}/${upstreamCaId}`,
        payload,
        {
          headers,
          httpsAgent: agent,
        }
      );
      return response.data;
    } catch (error) {
      console.error(`Error while adding owner as approver for: ${getFdcaId}:`,error);
      return null;
    }
  }

  private async modifyCAPrivate(
    headers: IHeaders,
    upstreamCaId: any,
    flowdownCaId: any
  ): Promise<any> {
    try {
      const { modifyCaPrivateURL } = urlConfig;
      const payload = {
        originChangeActionId: `pid:${upstreamCaId}`,
        receivingChangeActionId: `pid:${flowdownCaId}`,
      };
      const response = await axios.put(`${modifyCaPrivateURL}`, payload, {
        headers,
        httpsAgent: agent,
      });
      return response.data;
    } catch (error) {
      console.error(`Error while connecting Upstream CA with flowDownCA: ${flowdownCaId}:`,error.message);
      throw error;
    }
  }

  private async callMrAutomation(
    headers: IHeaders,
    getMrAutomationBody: any
  ): Promise<any> {
    try {
      const { mrAutomationURL } = urlConfig;
      const payload = getMrAutomationBody;
      const response = await axios.post(`${mrAutomationURL}`, payload, {
        headers,
        httpsAgent: agent,
      });

      return response.data;
    } catch (error) {
      console.log(`Error from the MR Automation: ${error}`);
      throw error;
    }
  }

  private async connectMbomItemToFdca(
    getFdcaId: any,
    getManufacturingItemId: any,
    getManufacturingItemType: any,
    headers: IHeaders,
    getCestamp: any,
    getConnectMbomItemToFdcaURL: string
  ): Promise<any> {
    try {
      const payload = {
        cestamp: getCestamp,
        add: [
          {
            proposedChanges: [
              {
                where: {
                  source:
                    "https://OI000186152-us1-space.3dexperience.3ds.com/enovia",
                  type: getManufacturingItemType,
                  identifier: getManufacturingItemId,
                  relativePath: `/resources/v1/modeler/dsmfg/dsmfg:MfgItem/${getManufacturingItemId}`,
                },
                target: "CurrentVersion",
              },
            ],
          },
        ],
      };
      console.log(`---payload of connectMbomItemToFdca: ${JSON.stringify(payload)}`);
      const response = await axios.patch(`${getConnectMbomItemToFdcaURL}/${getFdcaId}`,
        payload,
        {
          headers,
          httpsAgent: agent,
        }
      );
      return response.data;
    } catch (error) {
      if (
        error.response && error.response.data && error.response.data.errorMessage) {
        const errorMessage = error.response.data.errorMessage;
        console.error(`ConnectMbomItemToFdca error message: ${errorMessage}`);
      } else {
        console.error("An unknown error occurred:", error);
      }
      return null;
    }
  }

  private async promoteFdcaToInWork(
    getFdcaId: any,
    headers: IHeaders,
    getUpdateFdcaToInWorkURL: string
  ): Promise<any> {
    try {
      const payload = {
        data: [
          {
            id: getFdcaId,
            nextState: "In Work",
          },
        ],
      };
      const response = await axios.post(`${getUpdateFdcaToInWorkURL}`,
        payload,
        {
          headers,
          httpsAgent: agent,
        }
      );
      return response.data;
    } catch (error) {
      console.error(`Error while promoting FDCA to In-Work for flowDownCA: ${getFdcaId}: `,error);
      return null;
    }
  }

  private async updateFdcaStatusAsIgnored(
    getFdcaId: any,
    headers: IHeaders,
    getUpdateFdcaAsIgnored: string
  ): Promise<any> {
    try {
      const payload = {};
      const response = await axios.post(`${getUpdateFdcaAsIgnored}`, payload, {
        headers,
        httpsAgent: agent,
      });
      return response.data;
    } catch (error) {
      console.error(`Error while updating FDCA status as Ignored for flowDownCA: ${getFdcaId}: `,error);
      return null;
    }
  }

  public async updatePartPlantMRData(
    req: Request,
    res: Response
  ): Promise<boolean> {
    try {
      const requestData = req.body;
      console.log("updatePartPlantMRData");
      //logic to update the part plant MR data
      res.send(true);
    } catch (error) {}
    return true;
  }

  public async getFlowDownCADetails(req: Request, res: Response): Promise<void> {
    try {
      const {searchCaURL, getPhysicalProductInfoURL}=urlConfig;
      const csrfTokenAndHeaders = await this.getAuthenticationToken();
      const headers: IHeaders = {
        Cookie: csrfTokenAndHeaders.Cookie,
        SecurityContext: csrfTokenAndHeaders.SecurityContext,
        ENO_CSRF_TOKEN: csrfTokenAndHeaders.ENO_CSRF_TOKEN,
        "Content-Type": csrfTokenAndHeaders["Content-Type"],
      };

      interface MulesoftData {
        CAID: string;
        CABussinessGroup: string;
        CAState: string;
        CADescription: string;
        CAOwner: string;
      }

      interface UpstreamCAData {
        name: string;
        title: string;
        description: string;
        severity: string;
        owner: string;
        organization: string;
        collabSpace: string;
      }

      //create an object to store realizedItems and thier classification attributes details
      //Here one physical product can assigned to multiple plants(Class) like MMB,MMC,MVO,ISV plants. Here 'key' is pysical product Id
      const realizedItemsDetails: {
        [key: string]: {
          classificationAttributes: {
            ClassId: string;
            MbomValue: boolean;
            RealizedChange: any;
            ClassName: string;
          }[];
        };
      } = {};

      const mulesoftData: MulesoftData = req.body;
      console.log(`---RECIEVED request from MuleSoft: CAId: ${mulesoftData.CAID}:: Timestamp: ${new Date().toLocaleString()}`);
      const caDetailsResponse = await this.fetchCaDetails(mulesoftData.CAID, headers);

      const { name, title, description, severity, owner, organization, collabSpace } = caDetailsResponse;
      const upstreamCaData: UpstreamCAData = { name, title, description, severity, owner, organization, collabSpace };
      const connectedFdcaId = caDetailsResponse.isFlowedDownIn[0]?.identifier;

      const framedFdcaName = `MCO-${upstreamCaData.name.slice(-8)}*`;
      const searchCaResponse = await axios.get(`${searchCaURL}?`, {params:{'$searchStr':`name:${framedFdcaName}`}, headers, httpsAgent: agent });
      console.log(`========searchCaResponse: ${JSON.stringify(searchCaResponse.data)}`);
      const createdFdcaId = searchCaResponse.data.changeAction[0]?.identifier;
      console.log(`========createdFdcaId: ${createdFdcaId}`);
        
      //Fetch and store all realizedChange Items from caDetailsResponse, the result will stored in an array (realizedChangeItems)
      const realizedChangeItems = caDetailsResponse?.proposedChanges?.map(
        (item: any) => ({
          identifier: item.where.identifier,
          realizedChange: item,
        })
      );

      let foundValidClassificationAttribute = false;

      //Loop through all realisedItem and store thier classification attribute properties into 'realizedItemsDetails'
      for (const rcItem of realizedChangeItems) {
        const realizedItem = rcItem.identifier;
        const classificationAttrRes = await this.fetchClassificationAttribute(realizedItem,headers);
        if (!classificationAttrRes) {
          continue; // Skip to the iteration if no data found
        }
        const classificationAttributes = classificationAttrRes?.member?.[0]?.ClassificationAttributes;
        if (classificationAttributes?.totalItems <= 0) {
          console.log(`No classificationAttributes found for realizedItem: ${realizedItem}`);
          continue; // Skip to the next iteration if ClassificationAttribute is undefined
        }

        foundValidClassificationAttribute = true;

        //Array of objects to store classification Attribute data of each RealizedChange items
        const classificationAttributeData: {
          ClassId: string;
          MbomValue: boolean;
          RealizedChange: any;
          ClassName: string; // Add an optional ClassName property
        }[] = [];

        //To fetch whether Mbom(isManufacturable) is true or false
        const physicalProductDetailsResponse = await this.fetchPhysicalProductDetails(realizedItem, headers);
        classificationAttributes.member.forEach((member: any) => {
          const mbomValue = physicalProductDetailsResponse.member[0]?.isManufacturable;
          classificationAttributeData.push({
            ClassId: member.ClassID,
            MbomValue: mbomValue,
            RealizedChange: rcItem.realizedChange,
            ClassName: ''
          });
        });

        const fetchClassNamePromises = classificationAttributeData.map(async (item) => {
          if (item.ClassId) {
            try {
              const classNameResponse = await this.fetchClassName(item.ClassId, headers);
              const className = classNameResponse?.member?.[0]?.title.replace(/^Plant\s*/, "");
              if (className) {
                item.ClassName = className; // Update the item with ClassName
              } else {
                console.log(`ClassName not found for ClassID: ${item.ClassId}`);
              }
            } catch (error) {
              console.error(`Error fetching ClassName for ClassID ${item.ClassId}:`, error);
              throw error;
            }
          }
        });
        
        await Promise.all(fetchClassNamePromises);
        
        if (classificationAttributeData.every(item => item.ClassName === '')) {
          console.log(`ClassName not found for any ClassID`);
          throw error;
        }
      
        //Store all realized item data into realizedItemsDetails object
        realizedItemsDetails[realizedItem] = {
          classificationAttributes: classificationAttributeData,
        };
      }

      console.log(`=====realizedItemsDetails: ${JSON.stringify(realizedItemsDetails)}`);

      if(!foundValidClassificationAttribute) {
        console.log(`No classificationAttributes found for any realizedItem`);
        throw error;
      }

      interface OutputData {
        id: string;
        PlantName: string;
        Mbom: boolean;
        ProposedChange: any;
      }
      const output: OutputData[] = [];

      for (const key in realizedItemsDetails) {
        if (realizedItemsDetails.hasOwnProperty(key)) {
            output.push({
                id: key,
                PlantName: realizedItemsDetails[key].classificationAttributes.map(attr => attr.ClassName).join(", "),
                Mbom: realizedItemsDetails[key].classificationAttributes[0].MbomValue,
                ProposedChange: realizedItemsDetails[key].classificationAttributes[0].RealizedChange
            });
        }
      }

      console.log(`====output: ${JSON.stringify(output)}\nTimestamp: ${new Date().toLocaleString()}`);

      const plantNames: string[] = Array.from(new Set(output.flatMap(item => item.PlantName.split(',').map(name => name.trim()))));
      console.log(`=====plantNames: ${plantNames}`);

      if(!upstreamCaData.description) {
        upstreamCaData.description = `FlowDownCA for CA-${upstreamCaData.name.slice(-8)}`;
      }
      const fdcaName = `MCO-${upstreamCaData.name.slice(-8)}`;
      console.log(`---REQUEST the createFlowDownCA function to create FlowDownCA:: Timestamp: ${new Date().toLocaleString()}`);
      if(!createdFdcaId) {
        const createFdcaResponse: any = await this.createFlowDownCANew(headers,fdcaName,upstreamCaData.organization,upstreamCaData.collabSpace,upstreamCaData.description,upstreamCaData.severity);
        console.log(`---RESPONSE of createFlowDownCAResponse function with retry:: Timestamp: ${new Date().toLocaleString()}\n${JSON.stringify(createFdcaResponse)}`);
        var { id: getFdCaId, name: getFdcaName } = createFdcaResponse || {};
      } else {
        const fdcaDetails = await this.fetchCaDetails(createdFdcaId, headers);
        var { id: getFdCaId, name: getFdcaName } = fdcaDetails;
      }

      //Update Classification Attribute to each physical product of thier respective flowdownCA
      for (const physicalProductItem of output) {
        let keyToPass: any = "";
        const physicalProductId = physicalProductItem.id;
        const physicalProductInfoResponse: any = await this.fetchPhysicalProductDetails(physicalProductId, headers);
        if (physicalProductInfoResponse) {
          console.log(`====PhysicalProductId: ${physicalProductId}`); 
          const ppCestamp = physicalProductInfoResponse?.member?.[0]?.cestamp;
          const result: { [key: string]: string } = {
            cestamp: ppCestamp
          };
          const classNameArray = physicalProductItem.PlantName.split(',')
          .map(item => item.trim())
          .forEach((className) => { 
            if (/^\d/.test(className)) {
              keyToPass = "FlowDownCA" + className;
            } else {
              keyToPass = className + "FlowDownCA";
            }
            result[keyToPass] = className;
          });
          const updateAttributeToPPResponse: any = await updateClassAttrToPhysicalProduct(headers,physicalProductId,result);
        }
      }

      if(!connectedFdcaId){
        const modifyCaResponse = await this.modifyCAPrivate(headers,mulesoftData.CAID,getFdCaId);
        console.log(`---RESPONSE of modifyCAPrivate function: ${JSON.stringify(modifyCaResponse)}`);
      } /* else if(connectedFdcaId !== getFdCaId) {
        console.log(`The created flowdown CA and the connected flowdown CA are different. Please check!`);
        throw error;
      } */

      //To create a Routes for each Plants
      /* for(const item of plantNames) {
        const createRouteResponse = await this.createRoute(headers, upstreamCaData, item, getFdCaId);
        console.log(`---RESPONSE of CreateRoute: ${JSON.stringify(createRouteResponse)}`);
      } */

      //Create an object to store input data to MR_Automation
      const inputAttributeToMrAutomation: {
        UpstreamCAID: string;
        FlowdownCAID: string;
        FlowdownCAName: string;
        Owner: string;
        Organization: string;
        CollabSpace: string;
        ProductDetails: any;
      } = {
        UpstreamCAID: mulesoftData.CAID,
        FlowdownCAID: getFdCaId,
        FlowdownCAName: getFdcaName,
        Owner: upstreamCaData.owner,
        Organization: upstreamCaData.organization,
        CollabSpace: upstreamCaData.collabSpace,
        ProductDetails: output,
      };

      console.log(`---REQUEST to MRAutomation: ${JSON.stringify(inputAttributeToMrAutomation)}`);
      const mrAutomationResponse = await this.callMrAutomation(headers, inputAttributeToMrAutomation);
      console.log(`---RESPONSE of MRAutomation: ${JSON.stringify(mrAutomationResponse)}`);
      if (mrAutomationResponse && mrAutomationResponse.success) {
        console.log(`MR automation completed successfully`);
      } else {
        console.error(`MR automation failed with message: ${mrAutomationResponse.message}`);
        throw error;
      }
      res.status(200).json({status: `success`, msg: `ObsoletePart Creation request is successfull`});
    } catch (error) {
      res.status(200).json({status: `failed`, msg: `ObsoletePart Creation request failed` });
    }
  }

  public async reverseAutomationProcess(req: Request, res: Response): Promise<void> {
    try {
      const {searchCaURL, expandProductURL}=urlConfig;
      const { expandChildItemReqBody, caUrlParams, expandMfgItemReqBody, mfgParentItemURLParams,mfgParentItemReqBody} = API_CONFIG;

      const csrfTokenAndHeaders = await this.getAuthenticationToken();
      const headers: IHeaders = {
        Cookie: csrfTokenAndHeaders.Cookie,
        SecurityContext: csrfTokenAndHeaders.SecurityContext,
        ENO_CSRF_TOKEN: csrfTokenAndHeaders.ENO_CSRF_TOKEN,
        "Content-Type": csrfTokenAndHeaders["Content-Type"],
      };


      interface MulesoftData {
        CAID: string;
        CABussinessGroup: string;
        CAState: string;
        CADescription: string;
        CAOwner: string;
      }

      interface UpstreamCAData {
        name: string;
        title: string;
        description: string;
        severity: string;
        owner: string;
        organization: string;
        collabSpace: string;
      }

      const mulesoftData: MulesoftData = req.body;
      console.log(`---RECIEVED request from MuleSoft: CAId: ${mulesoftData.CAID}`);
      const caDetailsResponse = await this.fetchCaDetails(mulesoftData.CAID, headers);

      const { name, title, description, severity, owner, organization, collabSpace } = caDetailsResponse;
      const upstreamCaData: UpstreamCAData = { name, title, description, severity, owner, organization, collabSpace };
      const connectedFdcaId = caDetailsResponse.isFlowedDownIn[0]?.identifier;
      const proposedChanges = caDetailsResponse.proposedChanges;
      const realizedChanges = caDetailsResponse.realizedChanges;
      console.log(`===proposedChanges: ${JSON.stringify(proposedChanges)}`);
      console.log(`===realisedChanges: ${JSON.stringify(realizedChanges)}`);
      //process.exit(1);

      const engineeringItemsData: any[] = [];

      const expandProduct = proposedChanges.map(async (product) => {
        try {
          if (product?.where?.type == "Raw_Material") {
            const manufacturingItemData = {
              ...product,
              childDetails: []
            };

            return manufacturingItemData;
          }
          else {
            const mfgItemChildDetails = await axios.post(
              `${expandProductURL}/${product?.where?.identifier}/expand`,
              expandChildItemReqBody,
              {
                headers,
                httpsAgent: agent,
              }
            );

            const childData = mfgItemChildDetails?.data.member
              .filter((item: any) => item?.Path && item.Path.length === 3)
              .map((child: any) => ({
                instanceId: child.Path[1],
                childProductId: child.Path[2]
              }));

            const manufacturingItemData = {
              ...product,
              childDetails: childData.length > 0 ? childData : []
            };

            return manufacturingItemData;
          }

        } catch (error) {
          console.error(`Error processing product ${product?.where?.identifier}:`, error?.response?.data);
          //throw error; // Return null to continue processing other products
          return null;
        }
      });

      const expandProductData = await Promise.all(expandProduct);
      engineeringItemsData.push(...expandProductData.filter(item => item !== null));
      console.log(`======expandProduct: ${JSON.stringify(engineeringItemsData)}`);

      res.status(200).json({status: `success`, msg: `Reverse automation is successfull`});
    } catch (error) {
      res.status(200).json({status: `failed`, msg: `Reverse automation failed` });
    }
  }
}

export default getFlowDownCAService;

export async function updateClassAttrToPhysicalProduct(
  headers: IHeaders,
  getPhysicalProdId: any,
  getPayload: any
): Promise<any> {
  try {
    console.log(`====updateClassAttrToPhysicalProduct_Payload: ${JSON.stringify(getPayload)}`);
    const { updateClassAttributeForPhysicalProdURL } = urlConfig;
    const payload = getPayload
    const iterationHeaders = new AxiosHeaders({
      ...headers, // Copy the original headers
      SecurityContext: securityContextConfig.SecurityContext, // Modify SecurityContext
    });

    const response = await axios.patch(`${updateClassAttributeForPhysicalProdURL}/${getPhysicalProdId}`,
      payload,
      {
        headers: iterationHeaders,
        httpsAgent: agent,
      }
    );
    return response.data;
  } catch (error) {
    console.error(`Error while updating classification attribute to physical product: ${getPhysicalProdId}:`,error);
    throw error;
  }

}
