import { Request, Response } from "express";
import flowDownCAService from "./flowDownCAService";

class flowDownCAController {
  private flowDownCAServiceInstance: flowDownCAService;

  constructor() {
    this.flowDownCAServiceInstance = new flowDownCAService();
  }

  async getFlowDownCADetails(req: Request, res: Response) {
    console.log("came here");
    await this.flowDownCAServiceInstance.getFlowDownCADetails(req, res);
  }

  async reverseAutomationProcess(req: Request, res: Response) {
    await this.flowDownCAServiceInstance.reverseAutomationProcess(req, res);
  }

  async updatePartPlantMRData(req: Request, res: Response) {
    console.log("updatePartPlantMRData");
    await this.flowDownCAServiceInstance.updatePartPlantMRData(req, res);
  }
}

export default flowDownCAController;
