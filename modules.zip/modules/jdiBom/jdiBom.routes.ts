import { serverMode } from "@/appconfig/config";
import { JdiBomController } from "./jdiBom.controller";

import express from "express";

const router = express.Router();
const jdiBomController = new JdiBomController();

export const initJC = async () => {
  try {
    await jdiBomController.init();
    console.info("Container created JDIBOM" + serverMode);
  } catch (error) {
    console.error("Container creation failed JDIBOM" + serverMode);
    process.exit(1);
  }
};

router
  .route("/")
  .get((req, res, next) => jdiBomController.fetchJdiBoms(req, res).catch(next))
  .post((req, res, next) => jdiBomController.createJDI(req, res).catch(next))
  .delete((req, res, next) => jdiBomController.deleteAll(req, res).catch(next));

router
  .route("/:id")
  .get((req, res, next) => jdiBomController.getJDI(req, res).catch(next))
  .patch((req, res, next) => jdiBomController.updateJDI(req, res).catch(next))
  .delete((req, res, next) => jdiBomController.deleteJDI(req, res).catch(next));

export { router as jdiBomRoutes };
