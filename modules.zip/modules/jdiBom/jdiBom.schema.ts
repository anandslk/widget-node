import { z } from "zod";
import { JdiBomItem } from "./jdiBom.model";

const validStatuses = ["In Process", "Completed", "Failed"] as const;
const queryStatuses = [...validStatuses, "All"] as const;

export const queryOptionsSchema = z.object({
  userId: z
    .string({
      invalid_type_error: "User ID must be a string",
    })
    .min(1, { message: "User ID cannot be empty" })
    .optional(),

  status: z
    .enum(queryStatuses, {
      errorMap: () => ({
        message:
          "Status must be one of: Pending, Processing, Completed, Failed, or All",
      }),
    })
    .optional(),

  timestampFrom: z
    .string()
    .datetime("timestampFrom must be a valid ISO datetime string")
    .optional(),

  timestampTo: z
    .string()
    .datetime("timestampTo must be a valid ISO datetime string")
    .optional(),

  search: z.string().optional(),

  sortField: z.string().optional(),

  sortOrder: z
    .enum(["ASC", "DESC"], {
      errorMap: () => ({
        message: "Sort order must be either 'ASC' or 'DESC'",
      }),
    })
    .optional(),

  pageSize: z.coerce
    .number({
      invalid_type_error: "Page size must be a number",
    })
    .optional(),

  pageNumber: z.coerce
    .number({
      invalid_type_error: "Page number must be a number",
    })
    .optional(),
});

// jdiBom.schema.ts

export const jdiBomUpdateSchema = z.object({
  status: z
    .enum(validStatuses, {
      errorMap: () => ({
        message: "Status must be one of: In Process, Completed, or Failed",
      }),
    })
    .optional(),

  sourceOrg: z
    .string({
      invalid_type_error: "Source organization must be a string",
    })
    .min(1, { message: "Source organization cannot be empty" })
    .optional(),

  processedItems: z
    .array(
      z.object({
        Title: z.string({
          required_error: "Title is required",
          invalid_type_error: "Title must be a string",
        }),
        Type: z.string({
          required_error: "Type is required",
          invalid_type_error: "Type must be a string",
        }),
        "Maturity State": z.string({
          required_error: "Maturity State is required",
          invalid_type_error: "Maturity State must be a string",
        }),
        Owner: z.string({
          required_error: "Owner is required",
          invalid_type_error: "Owner must be a string",
        }),
        "Collaborative Space": z.string({
          required_error: "Collaborative Space is required",
          invalid_type_error: "Collaborative Space must be a string",
        }),
        "Collaborative Space Title": z.string({
          required_error: "Collaborative Space Title is required",
          invalid_type_error: "Collaborative Space Title must be a string",
        }),
        Description: z.string({
          required_error: "Description is required",
          invalid_type_error: "Description must be a string",
        }),
        "Dropped Revision": z.string({
          required_error: "Dropped Revision is required",
          invalid_type_error: "Dropped Revision must be a string",
        }),
        "Dropped Revision ID": z.string({
          required_error: "Dropped Revision ID is required",
          invalid_type_error: "Dropped Revision ID must be a string",
        }),
        "Latest Released Revision": z.string({
          required_error: "Latest Released Revision is required",
          invalid_type_error: "Latest Released Revision must be a string",
        }),
        "Latest Released Revision ID": z.string({
          required_error: "Latest Released Revision ID is required",
          invalid_type_error: "Latest Released Revision ID must be a string",
        }),
        EIN: z.string({
          required_error: "EIN is required",
          invalid_type_error: "EIN must be a string",
        }),
        "CAD Format": z.string({
          required_error: "CAD Format is required",
          invalid_type_error: "CAD Format must be a string",
        }),
        imageURL: z.string({
          required_error: "imageURL is required",
          invalid_type_error: "imageURL must be a string",
        }),
        relativePath: z.string({
          required_error: "relativePath is required",
          invalid_type_error: "relativePath must be a string",
        }),
        Name: z.string({
          required_error: "Name is required",
          invalid_type_error: "Name must be a string",
        }),
        organization: z.string({
          required_error: "organization is required",
          invalid_type_error: "organization must be a string",
        }),
        "Latest Revision": z.string({
          required_error: "Latest Revision is required",
          invalid_type_error: "Latest Revision must be a string",
        }),
        MFGCA: z.boolean({
          required_error: "MFGCA is required",
          invalid_type_error: "MFGCA must be a boolean",
        }),
      })
    )
    .min(1, { message: "At least one processed item is required" })
    .optional(),

  targetOrgs: z
    .array(
      z.string({
        invalid_type_error: "Each target organization must be a string",
      })
    )
    .min(1, { message: "At least one target organization is required" })
    .optional(),
});

export type CreateJdiBomDto = Omit<JdiBomItem, "timestamp">;

export const jdiBomCreateSchema = z.object({
  id: z
    .string({
      invalid_type_error: "Request ID must be a string",
      required_error: "Request ID is required",
    })
    .min(1, { message: "Request ID cannot be empty" }),

  status: z.enum(validStatuses, {
    errorMap: () => ({
      message:
        "Status must be one of: Pending, Processing, Completed, or Failed",
    }),
  }),

  sourceOrg: z
    .string({
      required_error: "Source organization is required",
      invalid_type_error: "Source organization must be a string",
    })
    .min(1, { message: "Source organization is required" }),

  processedItems: z
    .array(
      z.object({
        Title: z.string({
          required_error: "Title is required",
          invalid_type_error: "Title must be a string",
        }),
        Type: z.string({
          required_error: "Type is required",
          invalid_type_error: "Type must be a string",
        }),
        "Maturity State": z.string({
          required_error: "Maturity State is required",
          invalid_type_error: "Maturity State must be a string",
        }),
        Owner: z.string({
          required_error: "Owner is required",
          invalid_type_error: "Owner must be a string",
        }),
        "Collaborative Space": z.string({
          required_error: "Collaborative Space is required",
          invalid_type_error: "Collaborative Space must be a string",
        }),
        "Collaborative Space Title": z.string({
          required_error: "Collaborative Space Title is required",
          invalid_type_error: "Collaborative Space Title must be a string",
        }),
        Description: z.string({
          required_error: "Description is required",
          invalid_type_error: "Description must be a string",
        }),
        "Dropped Revision": z.string({
          required_error: "Dropped Revision is required",
          invalid_type_error: "Dropped Revision must be a string",
        }),
        "Dropped Revision ID": z.string({
          required_error: "Dropped Revision ID is required",
          invalid_type_error: "Dropped Revision ID must be a string",
        }),
        "Latest Released Revision": z.string({
          required_error: "Latest Released Revision is required",
          invalid_type_error: "Latest Released Revision must be a string",
        }),
        "Latest Released Revision ID": z.string({
          required_error: "Latest Released Revision ID is required",
          invalid_type_error: "Latest Released Revision ID must be a string",
        }),
        EIN: z.string({
          required_error: "EIN is required",
          invalid_type_error: "EIN must be a string",
        }),
        "CAD Format": z.string({
          required_error: "CAD Format is required",
          invalid_type_error: "CAD Format must be a string",
        }),
        imageURL: z.string({
          required_error: "imageURL is required",
          invalid_type_error: "imageURL must be a string",
        }),
        relativePath: z.string({
          required_error: "relativePath is required",
          invalid_type_error: "relativePath must be a string",
        }),
        Name: z.string({
          required_error: "Name is required",
          invalid_type_error: "Name must be a string",
        }),
        organization: z.string({
          required_error: "organization is required",
          invalid_type_error: "organization must be a string",
        }),
        "Latest Revision": z.string({
          required_error: "Latest Revision is required",
          invalid_type_error: "Latest Revision must be a string",
        }),
        MFGCA: z
          .boolean({
            required_error: "MFGCA is required",
            invalid_type_error: "MFGCA must be a boolean",
          })
          .optional(),
      }),

      {
        required_error: "Processed items are required",
        invalid_type_error: "Processed items must be an array of objects",
      }
    )
    .min(1, { message: "At least one processed item is required" }),

  targetOrgs: z
    .array(
      z.string({
        required_error: "Each target organization must be a string",
      }),
      {
        required_error: "Target organizations are required",
        invalid_type_error: "Target organizations must be an array of strings",
      }
    )
    .min(1, { message: "At least one target organization is required" }),

  userId: z
    .string({
      required_error: "User ID is required",
      invalid_type_error: "User ID must be a string",
    })
    .min(1, { message: "User ID is required" }),

  userEmail: z
    .string({
      required_error: "User email is required",
      invalid_type_error: "User email must be a string",
    })
    .email({ message: "Invalid email format" }),
}) as z.ZodType<CreateJdiBomDto>;
