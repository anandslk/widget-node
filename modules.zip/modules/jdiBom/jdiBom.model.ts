import { Container } from "@azure/cosmos";
import { CONTAINER } from "@/appconfig/config";
import { database } from "@/db/dbConnection";

export class JdiBom {
  private collectionId: string;
  private container?: Container;

  constructor() {
    this.collectionId = CONTAINER.JDI_BOM;
  }

  async initContainer(): Promise<Container> {
    try {
      const db = await database;

      if (!db?.id) throw new Error("The specified database is not present");

      const { container } = await db.containers.createIfNotExists(
        { id: this.collectionId },
        { offerThroughput: 400 }
      );

      this.container = container;

      return this.container;
    } catch (error) {
      console.error("Error init container", error);
    }
  }

  async queryData(options: QueryOptions = {}) {
    const {
      userId,
      status: sV,
      timestampFrom,
      timestampTo,
      search,
      sortField = "timestamp",
      sortOrder = "DESC",
      pageSize: PS = 10,
      pageNumber: PN = 1,
    } = options;

    const status = sV !== "All" ? sV : undefined;

    const pageSize = isNaN(Number(PS)) ? 10 : Number(PS);
    const pageNumber = isNaN(Number(PN)) ? 1 : Number(PN);

    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    const filters: string[] = [];
    const parameters: any[] = [];

    if (userId) {
      filters.push("c.userId = @userId");
      parameters.push({ name: "@userId", value: userId });
    }

    if (status && status !== "All") {
      filters.push("c.status = @status");
      parameters.push({ name: "@status", value: status });
    }

    if (timestampFrom) {
      filters.push("c.timestamp >= @timestampFrom");
      parameters.push({ name: "@timestampFrom", value: timestampFrom });
    }

    if (timestampTo) {
      filters.push("c.timestamp <= @timestampTo");
      parameters.push({ name: "@timestampTo", value: timestampTo });
    }

    if (search) {
      filters.push(`
    (
      CONTAINS(LOWER(c.id), @search) OR
      EXISTS(
        SELECT VALUE item
        FROM item IN c.processedItems
        WHERE CONTAINS(LOWER(item["Collaborative Space"]), @search)
      )
    )
  `);

      parameters.push({ name: "@search", value: search.toLowerCase() });
    }

    const whereClause =
      filters.length > 0 ? `WHERE ${filters.join(" AND ")}` : "";

    // Count query
    const countQuery = `SELECT VALUE COUNT(1) FROM c ${whereClause}`;
    const countResult = await this.container.items
      .query({ query: countQuery, parameters })
      .fetchAll();

    const total = countResult.resources[0] || 0;

    // Data query with pagination
    const offset = (pageNumber - 1) * pageSize;
    const dataQuery = `
        SELECT * FROM c
        ${whereClause}
        ORDER BY c.${sortField} ${sortOrder}
        OFFSET ${offset} LIMIT ${pageSize}
      `;

    const result = await this.container.items
      .query({ query: dataQuery, parameters })
      .fetchAll();

    return {
      data: result.resources,
      total,
    };
  }

  async getItemById(id: string): Promise<JdiBomItem | null> {
    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    try {
      const { resource } = await this.container.item(id).read<JdiBomItem>();
      return resource || null;
    } catch (error) {
      console.error(`Failed to fetch item with id ${id}:`, error);
      return null;
    }
  }

  async getNextId(): Promise<string> {
    const query = {
      query:
        "SELECT TOP 1 c.id FROM c WHERE STARTSWITH(c.id, 'REQ') ORDER BY c.timestamp DESC",
    };

    const { resources } = await this.container.items.query(query).fetchAll();

    if (resources.length > 0) {
      const lastId = resources[0].id;
      const lastNum = parseInt(lastId.replace("REQ", ""), 10);
      return `REQ${lastNum + 1}`;
    } else {
      return "REQ11917";
    }
  }

  async createItem(data: Omit<JdiBomItem, "timestamp">): Promise<JdiBomItem> {
    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    // const newId = await this.getNextId();

    const newItem: JdiBomItem = {
      ...data,
      // id: newId,
      timestamp: new Date().toISOString(),
    };

    const { resource } = await this.container.items.create(newItem);
    return resource as JdiBomItem;
  }

  async updateItem(
    id: string,
    updates: Partial<Omit<JdiBomItem, "id" | "timestamp">>
  ): Promise<JdiBomItem> {
    if (!this.container) {
      throw new Error("The specified collection is not present");
    }
    try {
      const { resource: existingItem } = await this.container
        .item(id)
        .read<JdiBomItem>();
      if (!existingItem) throw new Error(`Item with id ${id} not found`);

      const updatedItem: JdiBomItem = {
        ...existingItem,
        ...updates,
        timestamp: new Date().toISOString(),
      };

      const { resource: replaced } = await this.container
        .item(id)
        .replace(updatedItem);

      return replaced as JdiBomItem;
    } catch (error) {
      console.error(`Failed to update item with id ${id}:`, error);
      throw error;
    }
  }

  async deleteItem(id: string): Promise<void> {
    if (!this.container) {
      throw new Error("The specified collection is not present");
    }
    await this.container.item(id).delete();

    console.error(`Failed to delete item with id ${id}:`);
  }

  async deleteAll(): Promise<void> {
    if (!this.container) {
      throw new Error("The specified collection is not present");
    }

    try {
      const query = `SELECT c.id FROM c`;
      const result = await this.container.items.query({ query }).fetchAll();
      const items = result.resources;

      for (const item of items) {
        await this.container.item(item.id).delete();
      }
    } catch (error) {
      console.error("Failed to delete all items:", error);
      throw error;
    }
  }
}

interface QueryOptions {
  userId?: string;
  status?: string;
  timestampFrom?: string;
  timestampTo?: string;
  search?: string;
  sortField?: string;
  sortOrder?: "ASC" | "DESC";
  pageSize?: number;
  pageNumber?: number;
}

interface IProductInfo {
  Title?: string;
  Type?: string;
  "Maturity State"?: string;
  Owner?: string;
  "Collaborative Space"?: string;
  "Collaborative Space Title"?: string;
  Description?: string;
  "Dropped Revision"?: string;
  "Dropped Revision ID"?: string;
  "Latest Released Revision"?: string;
  "Latest Released Revision ID"?: string;
  EIN?: string;
  "CAD Format"?: string;
  imageURL?: string;
  relativePath?: string;
  Name?: string;
  organization?: string;
  "Latest Revision"?: string;
  MFGCA?: boolean;
}

export interface JdiBomItem {
  id: string;
  status: "In Process" | "Completed" | "Failed";
  timestamp: string;
  sourceOrg: string;
  processedItems: IProductInfo[];
  targetOrgs: string[];
  userId: string;
  userEmail: string;
}
