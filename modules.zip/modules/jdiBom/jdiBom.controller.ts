import { Request, Response } from "express";
import { JdiBom } from "./jdiBom.model";
import {
  queryOptionsSchema,
  jdiBomCreateSchema,
  jdiBomUpdateSchema,
} from "./jdiBom.schema";
import { BaseController } from "@/src/utils/baseController";

export class JdiBomController extends BaseController {
  private dao: JdiBom;

  constructor() {
    super();
    this.dao = new JdiBom();
  }

  async init() {
    await this.dao.initContainer();
  }

  async fetchJdiBoms(req: Request, res: Response) {
    const parsed = queryOptionsSchema.parse(req.query);
    const data = await this.dao.queryData(parsed);

    this.sendSuccess({
      res,
      message: "JDI found successfully",
      data: data.data,
      total: data.total,
    });
  }

  async createJDI(req: Request, res: Response) {
    const parsed = jdiBomCreateSchema.parse(req.body);
    const created = await this.dao.createItem(parsed);

    this.sendSuccess({
      res,
      status: 201,
      message: "JDI created successfully",
      data: created,
    });
  }

  async getJDI(req: Request, res: Response) {
    const { id } = req.params;

    if (!id) {
      this.sendError({
        res,
        status: 400,
        message: "ID is required",
      });
    }

    const data = await this.dao.getItemById(id);

    this.sendSuccess({
      res,
      status: 200,
      message: "JDI found successfully",
      data: data,
    });
  }

  async updateJDI(req: Request, res: Response) {
    const { id } = req.params;

    if (!id) {
      this.sendError({
        res,
        status: 400,
        message: "ID is required",
      });
    }

    const updates = jdiBomUpdateSchema.parse(req.body);

    const updated = await this.dao.updateItem(id, updates);

    this.sendSuccess({
      res,
      status: 200,
      message: "JDI updated successfully",
      data: updated,
    });
  }

  async deleteJDI(req: Request, res: Response) {
    const { id } = req.params;

    if (!id) {
      this.sendError({
        res,
        status: 400,
        message: "ID is required",
      });
    }

    const created = await this.dao.deleteItem(id);

    this.sendSuccess({
      res,
      status: 200,
      message: "JDI deleted successfully",
      data: created,
    });
  }

  async deleteAll(_req: Request, res: Response) {
    const created = await this.dao.deleteAll();

    this.sendSuccess({
      res,
      status: 200,
      message: "All deleted successfully",
      data: created,
    });
  }
}
