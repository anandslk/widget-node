import { EmailController } from './mailer.controller';

const express = require('express');
const router = express.Router();
const emailController = new EmailController();

router.get('/sentEmail', (req, res, next) => {
    emailController.sendEmail(['a.selvamani@slkgroup.com', 'tuttupu.varaprasad@slkgroup.com'], 'Test Subject', 'Test plain text', '<b>Test HTML</b>').catch(next);
    res.send({ data: "successfully sent" });
});

export { router };


