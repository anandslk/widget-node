import nodemailer from "nodemailer";

export class EmailController {
  private transporter: nodemailer.Transporter;

  constructor() {
    let serverMode = process.env.SERVER_MODE_ENV ?? "dev";
    // Create a transporter object using SMTP
    if (serverMode === "dev") {

        console.log('ttttttttttttttttttttt')
        console.log('process.env.SMTP_HOST', process.env.SMTP_HOST)
        console.log('process.env.SMTP_PORT', process.env.SMTP_PORT)
        console.log('process.env.SMTP_EMAIL', process.env.SMTP_EMAIL)
        console.log('process.env.SMTP_PASSWORD', process.env.SMTP_PASSWORD)
      this.transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT!, 10),
        secure: false,

        auth: {
          user: process.env.SMTP_EMAIL,
          pass: process.env.SMTP_PASSWORD,
        },
      });
      // this.transporter = nodemailer.createTransport({
      //     // service: 'gmail',
      //     // auth: {
      //     //     user: 'your_email@gmail.com', // Your email address
      //     //     pass: 'your_pass' // Your pass for Gmail
      //     // }
      //     host: 'localhost',
      //     port: 1025, // MailDev default SMTP port
      //     //host: 'inetmail.emrsn.net',
      //     //port: 25, // MailDev default SMTP port
      //     ignoreTLS: true
      // });
    } else {
      this.transporter = nodemailer.createTransport({
        // service: 'gmail',
        // auth: {
        //     user: 'your_email@gmail.com', // Your email address
        //     pass: 'your_pass' // Your pass for Gmail
        // }
        host: "localhost",
        port: 1025, // MailDev default SMTP port
        ignoreTLS: true,
      });
    }
  }

  async sendEmail(
    to: string | string[],
    subject: string,
    html: string
  ): Promise<boolean> {
    console.log('jjjjjjjjjjjjjjjjjjjjjjjjjjjj')
    try {
        console.log('444444444444444444444')
      const info = await this.transporter.sendMail({
        from: process.env.SMTP_EMAIL,
        to,
        subject,
        html,
        //   attachments: [
        //     {
        //       filename: "otp.png",
        //       path: __dirname + "/otp.png",
        //       cid: "otp",
        //     },

        //     {
        //       filename: "credentials.png",
        //       path: __dirname + "/credentials.png",
        //       cid: "credentials",
        //     },
        //   ],
      });

      console.info("Message sent: %s", info);

      return info;
    } catch (error) {
      console.error("Error occurred while sending email:", error);
      return error;
    }
  }
}
