import { Request, Response } from "express";
import AuthService from "../APIServices/authentication/authService";
import API_CONFIG from "../APIServices/config/APIConfig";
import axios, { AxiosHeaders } from "axios";
import { json } from "body-parser";
import { urlConfig } from "../APIServices/config/urlConfig";
import authConfig, {securityContextConfig} from "../APIServices/config/authConfig";
import { send } from "process";
// import { Attributes } from "../mco/attributes.model";
import { Agent } from "http";
import { Console, error } from "console";
import { promises } from "dns";
const https = require("https");

const agent = new https.Agent({
  rejectUnauthorized: false,
});

interface FutureRequestHeaders {
  Cookie: string | undefined;
  SecurityContext: string;
  ENO_CSRF_TOKEN: string;
  "Content-Type": string;
}

class getPlantAssignmentService {
  
  async getAuthenticationToken(
    userInfo: any = {}
  ): Promise<FutureRequestHeaders> {
    const authService = new AuthService();
    const csrfToken = await authService.authenticateUser(userInfo);
    return csrfToken;
  }

  public async getPlantAssignmentDetails(req: Request, res: Response): Promise<void> {
    try {
      const { classifyProdToClassURL, baseURL } = urlConfig;
      const csrfTokenAndHeaders = await this.getAuthenticationToken();
      const headers: IHeaders = {
        Cookie: csrfTokenAndHeaders.Cookie,
        SecurityContext: csrfTokenAndHeaders.SecurityContext,
        ENO_CSRF_TOKEN: csrfTokenAndHeaders.ENO_CSRF_TOKEN,
        "Content-Type": csrfTokenAndHeaders["Content-Type"],
      };

      const requestBody: any = req.body;  // Type the body
      const { id: productId, classes: classIds = [], type, childs: childIds = [], mode } = requestBody;

      if (!productId || !Array.isArray(classIds) || classIds.length === 0) {
        res.status(400).json({ message: "Missing or invalid product ID or classes." });
        return;
      }

      let ObjectsToClassify: any[] = [];
      if (mode ==="classifyParent"){  
        ObjectsToClassify.push({
          source: baseURL,
          type: type === "Raw_Material" ? "Raw_Material" : "VPMReference",
          identifier: productId,
          relativePath: `/resources/v1/modeler/${
            type === "Raw_Material"
              ? "dsrm/dsrm:RawMaterial"
              : "dseng/dseng:EngItem"
          }/${productId}`,
        });
      } else {
        childIds.forEach((prod) => {
          ObjectsToClassify.push({
            source: baseURL,
            identifier: prod.id,
            type: prod.type,
            relativePath: `/resources/v1/modeler/${
              prod.type === "VPMReference"
                ? "dseng/dseng:EngItem"
                : "dsrm/dsrm:RawMaterial"
            }/${prod.id}`,
          });
        });
      }

      const classificationPromises = classIds.map((classId) => {
        const body = {
          ClassID: classId,
          ObjectsToClassify : ObjectsToClassify, 
        };
        
        return axios.post(`${classifyProdToClassURL}`, body, {
          headers,
          httpsAgent: agent,
        });
      });

      const classificationResponses = await Promise.all(classificationPromises);
      res.status(200).json({ message: "Classes successfully classified" });

    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        res.status(500).json({ error: error.response.data });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  }

  public async getClassificationAtrribute(req: Request, res: Response): Promise<void> {
    try {
      const { classificationAttrUpdateURL } = urlConfig;
      const csrfTokenAndHeaders = await this.getAuthenticationToken();

      const objectId: any = req.query.id;
      const payload: any = req.body;
      const headers: IHeaders = {
        Cookie: csrfTokenAndHeaders.Cookie,
        SecurityContext: csrfTokenAndHeaders.SecurityContext,
        ENO_CSRF_TOKEN: csrfTokenAndHeaders.ENO_CSRF_TOKEN,
        "Content-Type": csrfTokenAndHeaders["Content-Type"],
      };

      const iterationHeaders = new AxiosHeaders({
        ...headers, // Copy the original headers
        SecurityContext: securityContextConfig.SecurityContext // Modify SecurityContext
      });

      if(objectId){
        const classificationAttrRawResponse: any = await axios.patch(`${classificationAttrUpdateURL}/${objectId}`, payload, {
          headers: iterationHeaders,
          httpsAgent: agent,
        });
        res.status(200).json(classificationAttrRawResponse.data);
      } else {
        res.status(500).json({status: 500, message: 'Object Id not found'});
      }

    } catch (error) {
      res.status(500).json(error.response.data);
    }
  }

  public async declassifyItem(req: Request, res: Response): Promise<void> {
    try {
      const { declassifyProdToClassURL,baseURL } = urlConfig;
      const csrfTokenAndHeaders = await this.getAuthenticationToken();
      const headers = {
        Cookie: csrfTokenAndHeaders.Cookie,
        SecurityContext: csrfTokenAndHeaders.SecurityContext,
        ENO_CSRF_TOKEN: csrfTokenAndHeaders.ENO_CSRF_TOKEN,
        "Content-Type": csrfTokenAndHeaders["Content-Type"],
      };

      const requestBody: any = req.body;  // Type the body
      const { id: productId, classes: classIds, type } = requestBody;

      if (!productId || !Array.isArray(classIds) || classIds.length === 0) {
        res.status(400).json({ message: "Missing or invalid product ID or classes." });
        return;
      }
      const staticBody = {
        ObjectsToDeclassify: [
          {
            source: baseURL,
            type: type === "Raw_Material" ? "Raw_Material" : "VPMReference",
            identifier: productId,
            relativePath: `/resources/v1/modeler/${
              type === "Raw_Material"
                ? "dsrm/dsrm:RawMaterial"
                : "dseng/dseng:EngItem"
            }/${productId}`,
          },
        ],
      };
      const classificationPromises = classIds.map((classId) => {
        const body = {
          ClassID: classId,
          ...staticBody, 
        };
        
        return axios.post(`${declassifyProdToClassURL}`, body, {
          headers,
          httpsAgent: agent,
        });
      });

      const classificationResponses = await Promise.all(classificationPromises);
      res.status(200).json({ message: "Classes successfully De classified" });
      
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        res.status(500).json({ error: error.response.data });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  }
}

export default getPlantAssignmentService;
