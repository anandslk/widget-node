export class ProductDetails {
    constructor(
        public ProductId: number,
        public ProductName: string,
        public CategoryName: string,
        public SubCategory: string,
        public Description: string,
        public Manufacturer: string,
        public Price: number
    ) { }
}

export class AttributesDetails {
    constructor(
        public id: any,
        public mcoItems: string,
        public uniquePartId: string,
        public mcoaffectedItem: any,
        public mcoProperties: object,
        public source: any,
        public target: any,
        public clientReleaseDate: any,
        public ERPstatus: any,
        public ERPErrorDescription: any,
        public serverReleaseDate: any,
    ) { }
}
export class ItemDetails {
    constructor(
        public id: any,
        public ItemAck: string,
        public details: string,
        public lastUpdate: string,
    ) { }
}

export class BomDetails {
    constructor(
        public id: any,
        public bomAck: string,
        public details: string,
        public lastUpdate: string,
    ) { }
}

export class SpecDetails {
    constructor(
        public id: any,
        public bosAck: string,
        public details: string,
        public lastUpdate: string,
    ) { }
}

export class PlantDetails {
    constructor(
        public id: any,
        public plants: string,
        public plantName: string,
        public ERPType: string,
        public orgId: string,
        public material_master: string,
        public instance: string,
        public ConnectivityDetails: any,
        public SalesOrg: string,
        public aliasPlant: string,
        public ECN_required: string,
        public bomusage: string,
        public exportToERP: string,
        // public BU: any

    ) { }
}
export class TemplateDetails {
    constructor(
        public id: any,
        public templates: any,
        public templateName: string,
        public desc: string,
        public instance: string,
        public ERPType: string,
        public plantId: string,
        public plantName: string,
        public url: string,
        public username: string,
        public password: string,
        public authkey: string,
        public port: string,
        public attributes: any,
        public SalesOrg: string,
        public material_master: string,
        public BU: any,
        public ECN_required: string,
        public bomusage: string,
        // public exportToERP: string,
        // public existInOracle: string,
        // public notOwningDivision: string,
        public plants: any
    ) { }
}

export class SourceDetails {
    constructor(
        public id: any,
        public sourceList: any,
        public instance: string,
        public source: string,
        public environment: string,
        public ERPType: string
    ) { }
}

export class BusinessUnitDetails {
    constructor(
        public id: any,
        public businessUnit: any,
        public buName: string,
        public exportToERPdisabled: string,
        public contextDEF: string,
        public EMRDivisionORGValue: string,
        public productHierarchy: string,
        public exportToERPbyPassed: string,
        public enableBOSTransfer: string,
        public plants: any,
        public doNotSendToERP: any,
        public oracleExisting: any,
        public makeWithoutBOMList: any,
        public notOwningDivisionList: any,
    ) { }
}

export class MappingsDetails {
    constructor(
        public id: any,
        public mappings: any,
        public Name: any,
        public List: any,
        public ERPType: any,
    ) { }
}

export class ORGAllowedTemplate {
    constructor(
        public id: any,
        public templateMappings: any,
        public BUID: any,
        public ALLOWABLE_ORG_TEMPLATES_ID: any,
        public ALLOWABLE_ORG_TEMPLATES: any,
        public Has_MBOM: any,
        public On_MBOM: any,
        public EBOM_Allowed: any,
        public Optional: any,
        public PO_Org_Exist_Check: any,
        public Plants: any,
    ) { }
}

export class TemplateMappingsTypes {
    constructor(
        public id: any,
        public templateMappings: any,
        public BUID: any,
        public MappingType: any,
        // public version: number,
        public details: any
    ) { }
}

export class DraftChangesItems {
    constructor(
        public id: any,
        public draftId: any,
        public userName: string,
        public userId: any,
        public version: number,
        public MappingType: string,
        public BUID: string,
        public changes: any,
        public createdDateTime: any,
        public modifiedDateTime: any
    ) { }
}
export class HistoryVersionItems {
    constructor(
        public id: any,
        public versionId: any,
        public BUID: string,
        public MappingType: string,
        public version: number,
        public userId: string,
        public isHavingDraft: boolean,
    ) { }
}

export class MappingHistoryItems {
    constructor(
        public id: any,
        public historyId: any,
        public userId: string,
        public userName: string,
        public dateTime: any,
        public reason: string,
        public BUID: string,
        public MappingType: string,
        public version: number
    ) { }
}

export class MRRelatedDetails {
    constructor(
        public id: any,
        public MRRelDetails: any,
        public partAndPlant: string,
        public partName: string,
        public plantName: string,
        public revision: string,
        public mcoId: string,
        public mcoName: string,
        public sequence: Number,
        public additionalSequence: Number,
        public status: string,
        public ERPStatus: string,
        public makeOrBuy: string,
        public template: string,
        public createDate: string,
        public modifiedeDate: string,
        // public template: {
        //     templateId: string,
        //     templateName: string,
        // }[],
    ) { }
}

export class ParamType {
    constructor(
        public partAndPlant: [],
    ) { }
}

export class UsersItems {
    constructor(
        public id: any,
        public userId: string,
        public userName: string,
        public name: string,
        public email: string,
        public is_authorized: boolean,
        public email_verified: boolean,
        public userinfo: any,
        public updated_at: string,
        public created_at: string
    ) { }
}

export class LifeCycleStatusItems {
    constructor(
        public id: any,
        public mcoId: string,
        public systemType: string,
        public itemStatus: string,
        public itemMessage: string,
        public itemPayload: any,
        public itemInitiatedDateTime: string,
        public bosStatus: string,
        public bosMessage: string,
        public bosPayload: any,
        public bosInitiatedDateTime: string,
        public bomStatus: string,
        public bomMessage: string,
        public bomPayload: any,
        public bomInitiatedDateTime: string,
        public releaseStatus: string,
        public releaseMessage: string,
        public releasePayload: any,
        public releaseInitiatedDateTime: string,
        public promoted: string,
        public created_user: any,
        public updated_user: any,
        public updated_at: string,
        public created_at: string
    ) { }
}

export class SpecCreationItem {
    constructor(
        public id: any,
        public specificationCreation: string,
        public BOSSpecs: any,
        public specName: string,
        public type: string,
        public bosStatus: string,
        public bosMessage: string,
        public bosInitiatedDateTime: string,
        public createdDateTime: string
    ) { }
}
export class ObsoletePartItem {
    constructor(
        public id: any,
        public obsoletePart: string,
        public obsoletePartData: any,
        public obsoleteStatus: string,
        public obsoleteMessage: string,
        public obsoleteInitiatedDateTime: string,
        public createdDateTime: string
    ) { }
}
export class MassDesUpdateItem {
    constructor(
        public id: any,
        public massDesUpdate: any,
        public ownerEmail: any,
        public massDesStatus: string,
        public massDesOracleStatus: string,
        public massDesMessage: string,
        public massDesInitiatedDateTime: string,
        public createdDateTime: string
    ) { }
}
export class SystemSettingsItems {
    constructor(
        public id: any,
        public systemId: any,
        public ERPType: string,
        public instance: string,
        public file1: string,
        public file2: string,
        public createdBy: string,
        public createdDateTime: string,
        public modifiedBy: string,
        public modifiedDateTime: string
    ) { }
}
export class McoHistoryItems {
    constructor(
        public id: any,
        public historyId: any,
        public mcoName: string,
        public actionUserDetails: any,
        public actionType: string,
        public state: string,
        public description: string,
        public createdBy: string,
        public createdDateTime: string,
    ) { }
}

export class BosAttributeDetails {
    constructor(
        public ItemType: string,
        public ItemName: string,
        public ItemRevision: any,
        public SpecType: string,
        public SpecName: string,
        public SpecRevision: any,
        public PrintOnPurchaseOrderRequired: string,
        public PrintOnWorkOrderRequired: string,
        public WorkOrderDocumentRequired: string,
        public PrintOnReportOrderRequired: string,
        public SAPJDE: string,
    ) { }
}